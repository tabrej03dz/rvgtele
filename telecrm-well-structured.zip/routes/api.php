<?php

use App\Http\Controllers\Api\AuthController;
use App\Http\Controllers\Api\DeviceTokenController;
use App\Http\Controllers\Api\LeadApiController;
use Illuminate\Support\Facades\Route;
use App\Http\Controllers\Api\WhatsappMessageTemplateController;
use App\Http\Controllers\Api\DashboardController;
use App\Http\Controllers\Api\FollowUpApiController;
use App\Http\Controllers\Api\CallDispositionApiController;
use App\Http\Controllers\Api\CallingCrmController;
use App\Http\Controllers\Api\CallingSettingController;
use App\Http\Controllers\Api\DemoCityController;
use App\Http\Controllers\Api\DeviceCallLogController;
use App\Http\Controllers\Api\MobileApkController;

Route::post('/login', [AuthController::class, 'login']);

Route::middleware('auth:sanctum')->group(function () {
      Route::get('/dashboard', [DashboardController::class, 'index']);
        Route::get('/user', [AuthController::class, 'user']);
        Route::post('/logout', [AuthController::class, 'logout']);
        Route::get(
        '/leads/{lead}/communication-history',
        [LeadApiController::class, 'communicationHistory']
    );


    Route::get('lead-contacts', [CallingCrmController::class, 'index']);
    Route::post('lead-contacts/call_status/{lead_contact}', [CallingCrmController::class, 'callStatus']);
    Route::get('/lead-contacts/{id}/check_status', [CallingCrmController::class, 'checkCallStatus']);

    Route::get('categories', [\App\Http\Controllers\Api\CategoryController::class, 'index']);


    Route::get(
        '/mobile-apk/latest',
        [MobileApkController::class, 'latest']
    );


     /*
    |--------------------------------------------------------------------------
    | Demo Categories
    |--------------------------------------------------------------------------
    */

    Route::get(
        'categories',
        [DemoCityController::class, 'categories']
    );


    /*
    |--------------------------------------------------------------------------
    | Demo Cities
    |--------------------------------------------------------------------------
    */

    Route::get(
        '/demo-cities',
        [DemoCityController::class, 'index']
    );


    Route::post(
        '/demo-cities',
        [DemoCityController::class, 'store']
    );


    Route::get(
        '/demo-cities/{demoCity}',
        [DemoCityController::class, 'show']
    );


    /*
    |--------------------------------------------------------------------------
    | Update
    |--------------------------------------------------------------------------
    |
    | POST ko bhi rakha hai because multipart file upload ke saath
    | mobile/Postman me POST easiest/reliable rahega.
    |
    */

    Route::match(
        ['put', 'patch', 'post'],
        '/demo-cities/{demoCity}/update',
        [DemoCityController::class, 'update']
    );


    /*
    |--------------------------------------------------------------------------
    | Upload Multiple Files
    |--------------------------------------------------------------------------
    */

    Route::post(
        '/demo-cities/{demoCity}/media',
        [DemoCityController::class, 'uploadMedia']
    );


    /*
    |--------------------------------------------------------------------------
    | Upload ZIP
    |--------------------------------------------------------------------------
    */

    Route::post(
        '/demo-cities/{demoCity}/zip',
        [DemoCityController::class, 'uploadZip']
    );


    /*
    |--------------------------------------------------------------------------
    | Single Media Download
    |--------------------------------------------------------------------------
    */

    Route::get(
        '/demo-cities/{demoCity}/media/{mediaId}/download',
        [DemoCityController::class, 'downloadMedia']
    )
        ->name(
            'api.demo-cities.media.download'
        );


    /*
    |--------------------------------------------------------------------------
    | Delete Single Media
    |--------------------------------------------------------------------------
    */

    Route::delete(
        '/demo-cities/{demoCity}/media/{mediaId}',
        [DemoCityController::class, 'destroyMedia']
    );


    /*
    |--------------------------------------------------------------------------
    | Download Complete City ZIP
    |--------------------------------------------------------------------------
    */

    Route::get(
        '/demo-cities/{demoCity}/download-all',
        [DemoCityController::class, 'downloadAll']
    )
        ->name(
            'api.demo-cities.download-all'
        );


    /*
    |--------------------------------------------------------------------------
    | Delete Complete City
    |--------------------------------------------------------------------------
    */

    Route::delete(
        '/demo-cities/{demoCity}',
        [DemoCityController::class, 'destroy']
    );


  /*
    |--------------------------------------------------------------------------
    | Employee Work SIM
    |--------------------------------------------------------------------------
    */

    Route::get(
        '/calling-settings',
        [CallingSettingController::class, 'show']
    );

    Route::post(
        '/calling-settings',
        [CallingSettingController::class, 'store']
    );

    /*
    |--------------------------------------------------------------------------
    | Device Call Logs
    |--------------------------------------------------------------------------
    */

    Route::post(
        '/leads/{lead}/device-call-log',
        [DeviceCallLogController::class, 'store']
    );

    Route::put(
        '/call-logs/{callLog}',
        [DeviceCallLogController::class, 'update']
    );

    Route::get(
        '/leads/{lead}/call-history',
        [DeviceCallLogController::class, 'history']
    );





/*
|--------------------------------------------------------------------------
| Call Disposition APIs
|--------------------------------------------------------------------------
*/

Route::get(
    '/call-dispositions',
    [CallDispositionApiController::class, 'index']
);

Route::get(
    '/call-dispositions/{callDisposition}',
    [CallDispositionApiController::class, 'show']
);


/*
|--------------------------------------------------------------------------
| Follow-up APIs
|--------------------------------------------------------------------------
*/
Route::get('follow-ups/category/{category?}', [FollowUpApiController::class, 'followUpsByCategory']);
Route::prefix('follow-ups')
    ->controller(FollowUpApiController::class)
    ->group(function () {
        Route::get('/', 'index');
        Route::get('/summary', 'summary');
        Route::get('/reminders', 'reminders');
        Route::get('/nearest', 'nearest');

        Route::get('/{followUp}', 'show');

        Route::patch('/{followUp}/complete', 'complete');
        Route::patch('/{followUp}/snooze', 'snooze');
        Route::patch('/{followUp}/reschedule', 'reschedule');
        Route::patch('/{followUp}/cancel', 'cancel');

        

    });


 /*
    |--------------------------------------------------------------------------
    | WhatsApp Templates
    |--------------------------------------------------------------------------
    */

    Route::get(
        '/whatsapp-templates',
        [WhatsappMessageTemplateController::class, 'index']
    );

    Route::post(
        '/whatsapp-templates',
        [WhatsappMessageTemplateController::class, 'store']
    );

    Route::get(
        '/whatsapp-templates/users',
        [WhatsappMessageTemplateController::class, 'users']
    );

    Route::get(
        '/whatsapp-templates/{whatsappTemplate}',
        [WhatsappMessageTemplateController::class, 'show']
    );

    Route::put(
        '/whatsapp-templates/{whatsappTemplate}',
        [WhatsappMessageTemplateController::class, 'update']
    );

    Route::patch(
        '/whatsapp-templates/{whatsappTemplate}',
        [WhatsappMessageTemplateController::class, 'update']
    );

    Route::delete(
        '/whatsapp-templates/{whatsappTemplate}',
        [WhatsappMessageTemplateController::class, 'destroy']
    );


    /*
    |--------------------------------------------------------------------------
    | Lead WhatsApp
    |--------------------------------------------------------------------------
    */

    Route::get(
        '/leads/{lead}/whatsapp-templates',
        [WhatsappMessageTemplateController::class, 'selectable']
    );

    Route::post(
        '/leads/{lead}/whatsapp-message/render',
        [WhatsappMessageTemplateController::class, 'render']
    );





Route::get(
    '/firebase/health',
    [DeviceTokenController::class, 'firebaseHealth']
);

   Route::post(
        '/leads/{lead}/call-on-mobile',
        [LeadApiController::class, 'callOnMobile']
    );

    Route::prefix('leads')->controller(LeadApiController::class)->group(function () {
        Route::get('/options', 'options');
        Route::get('/', 'index');
        Route::post('/', 'store');
        Route::get('/{lead}', 'show');
        Route::put('/{lead}', 'update');
        Route::patch('/{lead}', 'update');
        Route::delete('/{lead}', 'destroy');

        Route::post('/{lead}/assign', 'assign');
        Route::post('/bulk-assign', 'bulkAssign');
        Route::post('/{lead}/notes', 'addNote');

        Route::post('/labels', 'storeLabel');
        Route::delete('/labels/{label}', 'destroyLabel');
        Route::post('/{lead}/labels', 'addLabel');
        Route::delete('/{lead}/labels/{label}', 'removeLabel');

        Route::post(
    '/{lead}/call-result',
    'saveCallResult'
);

    });



    Route::prefix('device-tokens')
    ->controller(DeviceTokenController::class)
    ->group(function () {
        Route::get('/', 'index');
        Route::post('/', 'store');
        Route::delete('/', 'destroy');
        Route::delete('/all', 'destroyAll');
        Route::post('/test-notification', 'test');
    });

});
