<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8">

    <meta
        name="viewport"
        content="width=device-width, initial-scale=1"
    >

    <meta
        name="csrf-token"
        content="{{ csrf_token() }}"
    >

    <title>
        @yield('title', 'TeleCRM')
    </title>

    @vite([
        'resources/css/app.css',
        'resources/js/app.js'
    ])

    <script src="https://cdn.jsdelivr.net/npm/@tailwindcss/browser@4"></script>
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700;800&display=swap" rel="stylesheet">
    <script src="https://unpkg.com/lucide@0.468.0/dist/umd/lucide.min.js"></script>

    <style>

    /*
    |--------------------------------------------------------------------------
    | Sidebar Follow-up Blink
    |--------------------------------------------------------------------------
    */

    @keyframes sidebar-followup-blink {

        0%,
        100% {
            opacity: 1;
            transform: scale(1);
        }

        50% {
            opacity: .45;
            transform: scale(.96);
        }
    }


    @keyframes sidebar-followup-dot-blink {

        0%,
        100% {
            opacity: 1;
            transform: scale(1);
        }

        50% {
            opacity: .25;
            transform: scale(.6);
        }
    }


    .sidebar-followup-reminder {

        animation:
            sidebar-followup-blink
            1.2s
            infinite;
    }


    .sidebar-followup-dot {

        animation:
            sidebar-followup-dot-blink
            .7s
            infinite;
    }

    :root {
        --crm-navy: #081343;
        --crm-navy-deep: #050b2c;
        --crm-blue: #2563eb;
        --crm-violet: #7c3aed;
        --crm-border: #e5e9f2;
    }

    * { box-sizing: border-box; }

    body {
        margin: 0;
        font-family: Inter, ui-sans-serif, system-ui, -apple-system, BlinkMacSystemFont, "Segoe UI", sans-serif;
        background: #f7f9fc;
        color: #172033;
    }

    .crm-sidebar {
        background:
            radial-gradient(circle at 10% 0%, rgba(70, 71, 255, .23), transparent 29%),
            linear-gradient(180deg, var(--crm-navy-deep) 0%, #071750 54%, #092570 100%);
        box-shadow: 10px 0 35px rgba(12, 24, 73, .08);
    }

    .crm-brand-mark {
        background: linear-gradient(145deg, #3668ff 0%, #5538ff 48%, #9b27ee 100%);
        box-shadow: 0 10px 25px rgba(65, 72, 255, .38), inset 0 1px 0 rgba(255,255,255,.3);
    }

    .crm-nav-link { border: 1px solid transparent; }
    .crm-nav-link svg { width: 18px; height: 18px; stroke-width: 1.8; }
    .crm-nav-link.is-active {
        background: linear-gradient(100deg, #2768ff 0%, #6638f5 56%, #8d37ef 100%);
        box-shadow: 0 8px 23px rgba(63, 74, 255, .35), inset 0 1px 0 rgba(255,255,255,.18);
        border-color: rgba(255,255,255,.12);
    }

    .crm-header {
        min-height: 74px;
        border-color: var(--crm-border);
        box-shadow: 0 1px 8px rgba(15, 23, 42, .025);
    }

    .crm-avatar {
        background: linear-gradient(145deg, #2464ff, #8a2ceb);
        box-shadow: 0 6px 16px rgba(82, 55, 238, .22);
    }

    .crm-icon-button {
        display: inline-flex;
        height: 42px;
        width: 42px;
        align-items: center;
        justify-content: center;
        border: 1px solid #e3e7ef;
        border-radius: 10px;
        background: #fff;
        color: #1e293b;
        box-shadow: 0 3px 10px rgba(15,23,42,.05);
        transition: .18s ease;
    }
    .crm-icon-button:hover { color: #5b35ea; border-color: #cfc7ff; }
    .crm-icon-button svg { width: 19px; height: 19px; }

    .crm-logout {
        display: inline-flex;
        min-height: 42px;
        align-items: center;
        gap: 8px;
        border: 1px solid #fee2e2;
        border-radius: 10px;
        padding: 0 16px;
        background: #fff;
        color: #ef4444;
        font-weight: 700;
        box-shadow: 0 3px 10px rgba(15,23,42,.035);
    }
    .crm-logout:hover { background: #fff5f5; border-color: #fecaca; }
    .crm-logout svg { width: 17px; height: 17px; }

    /*
    |--------------------------------------------------------------------------
    | Responsive Sidebar
    |--------------------------------------------------------------------------
    | Desktop:
    | - Sidebar default visible rahega.
    | - Hamburger click par sidebar left side me completely hide hoga.
    | - Main content full width le lega.
    |
    | Mobile / Tablet:
    | - Existing off-canvas behaviour same rahega.
    */
    .crm-sidebar,
    .crm-main {
        transition:
            transform .25s ease,
            margin-left .25s ease;
    }

    @media (min-width: 1024px) {
        .crm-sidebar {
            transform: translateX(0);
        }

        .crm-sidebar.is-collapsed {
            transform: translateX(-100%);
        }

        .crm-main {
            margin-left: 18rem;
        }

        .crm-main.is-sidebar-expanded {
            margin-left: 0 !important;
        }
    }

    @media (max-width: 1023px) {
        .crm-sidebar {
            position: fixed !important;
            inset: 0 auto 0 0 !important;
            z-index: 60;
            width: 285px !important;
            transform: translateX(-105%);
            transition: transform .25s ease;
        }
        .crm-sidebar.is-open { transform: translateX(0); }
        .crm-sidebar-backdrop.is-open { display: block; }
    }


    /* Follow-up popup: fit desktop viewport without inner vertical scrollbar */
    @media (max-height: 760px) and (min-width: 900px) {
        #followUpReminderTop { padding-top: 10px !important; padding-bottom: 10px !important; }
        #followUpReminderCard > div:nth-child(2) { padding-top: 12px !important; padding-bottom: 12px !important; }
        #followUpNotesWrapper { margin-top: 10px !important; padding-top: 8px !important; padding-bottom: 8px !important; }
        #followUpPopupCallForm textarea { height: 58px !important; }
        #followUpReminderCard .mt-4 { margin-top: 10px !important; }
    }

    @media (max-width: 899px) {
        #followUpReminderModal { align-items: flex-start !important; overflow-y: auto !important; }
        #followUpReminderCard { max-height: none !important; }
    }


    /* =========================================================
       AUTO FOLLOW-UP POPUP - SAME PREMIUM FEEDBACK STYLE
       ========================================================= */
    .auto-feedback-backdrop {
        background: rgba(15,23,42,.58);
        backdrop-filter: blur(3px);
    }
    .auto-feedback-card {
        width: 100%;
        max-width: 820px;
        max-height: calc(100dvh - 28px);
        border: 1px solid #f4ddb0;
        border-radius: 18px;
        background: linear-gradient(145deg,#fffef9 0%,#fffaf0 42%,#fff 100%);
        box-shadow: 0 30px 90px rgba(15,23,42,.28), 0 0 0 1px rgba(245,185,0,.05);
    }
    .auto-feedback-head {
        background: radial-gradient(circle at 92% 10%,rgba(245,185,0,.14),transparent 34%);
    }
    .auto-feedback-tag {
        display:inline-flex;align-items:center;gap:6px;min-height:26px;padding:0 9px;
        border-radius:7px;background:#fff1bf;color:#9a6500;font-size:9px;font-weight:900;
        text-transform:uppercase;letter-spacing:.03em;
    }
    .auto-feedback-close {
        width:40px;height:40px;display:inline-flex;align-items:center;justify-content:center;
        border:1px solid #dedede;border-radius:12px;background:#fff;color:#475467;
        box-shadow:0 4px 12px rgba(15,23,42,.05);
    }
    .auto-feedback-summary {
        display:grid;grid-template-columns:repeat(3,minmax(0,1fr));gap:9px;
    }
    .auto-feedback-summary-card {
        min-height:72px;display:flex;align-items:center;gap:9px;border:1px solid #eadfc9;
        border-radius:12px;background:rgba(255,255,255,.9);padding:10px;
    }
    .auto-feedback-icon {
        width:34px;height:34px;flex:0 0 34px;display:flex;align-items:center;justify-content:center;
        border-radius:50%;background:#fff4cb;color:#d99b00;
    }
    .auto-feedback-primary {
        min-height:42px;display:flex;align-items:center;justify-content:center;gap:8px;
        border:1px solid #f0c333;border-radius:10px;background:linear-gradient(180deg,#ffd22e 0%,#ffc400 100%);
        color:#171717;font-size:10px;font-weight:900;text-decoration:none;
    }
    .auto-feedback-primary.secondary {background:#fff;border-color:#eccd71;}
    .auto-feedback-panel {
        border:1px solid #eadfc9;border-radius:13px;background:rgba(255,255,255,.92);padding:14px;
    }
    .auto-feedback-field label,.auto-feedback-field .label {
        display:block;margin-bottom:5px;color:#475569;font-size:10px;font-weight:900;
    }
    .auto-feedback-field select,.auto-feedback-field textarea,.auto-feedback-field input[type=datetime-local] {
        width:100%;border:1px solid #d7dde7;border-radius:10px;background:#fff;color:#1e293b;font-size:11px;outline:none;
    }
    .auto-feedback-field select,.auto-feedback-field input[type=datetime-local] {min-height:42px;padding:0 11px;}
    .auto-feedback-field textarea {min-height:76px;padding:9px 11px;resize:vertical;}
    .auto-feedback-field select:focus,.auto-feedback-field textarea:focus,.auto-feedback-field input:focus {
        border-color:#f1b900;box-shadow:0 0 0 3px rgba(241,185,0,.12);
    }
    .auto-feedback-snooze {
        min-height:36px;display:inline-flex;align-items:center;justify-content:center;gap:6px;
        border:1px solid #e5d7b2;border-radius:9px;background:#fff;color:#5f6470;padding:0 11px;
        font-size:10px;font-weight:900;
    }
    .auto-feedback-footer {
        background:linear-gradient(to top,#fff 82%,rgba(255,255,255,.94));
    }
    @media(max-width:700px){
        .auto-feedback-card{max-height:calc(100dvh - 12px);border-radius:14px;}
        .auto-feedback-summary{grid-template-columns:1fr;}
        .auto-feedback-actions{grid-template-columns:1fr !important;}
        .auto-feedback-form-grid{grid-template-columns:1fr !important;}
        .auto-feedback-footer-row{align-items:stretch !important;flex-direction:column;}
    }

</style>
</head>

<body class="bg-slate-100 text-slate-800">

<div class="min-h-screen lg:flex">

    {{-- ========================================================= --}}
    {{-- SIDEBAR --}}
    {{-- ========================================================= --}}

    <aside id="crmSidebar"
        class="
            crm-sidebar
            w-full
            bg-slate-950
            text-white

            lg:fixed
            lg:inset-y-0
            lg:left-0
            lg:w-72
            lg:overflow-y-auto
        "
    >

        {{-- Logo / Title --}}

        <div class="border-b border-white/10 px-4 py-5">
            <div class="flex items-center gap-3">
                <div class="crm-brand-mark flex h-12 w-12 shrink-0 items-center justify-center rounded-xl">
                    <i data-lucide="phone-call" class="h-6 w-6 text-white"></i>
                </div>
                <div class="min-w-0">
                    <div class="truncate text-[16px] font-bold tracking-tight text-white">Telecalling Sales CRM</div>
                    <div class="mt-1 truncate text-[10px] text-slate-400">Lead • Call • Follow-up • Conversion</div>
                </div>
            </div>

        </div>


        {{-- ===================================================== --}}
        {{-- SIDEBAR MENU CONFIGURATION --}}
        {{-- ===================================================== --}}
        @php
            $user = auth()->user();
            $isSuperAdmin = $user->hasRole('super_admin');

            // Retain existing nearest follow-up reminder feature.
            $nearestSidebarFollowUp = \App\Models\FollowUp::query()
                ->where('company_id', $user->company_id)
                ->where('assigned_to', $user->id)
                ->where('status', 'pending')
                ->whereNotNull('scheduled_at')
                ->orderByRaw('ABS(TIMESTAMPDIFF(SECOND, NOW(), scheduled_at)) ASC')
                ->first();

            $nearestFollowUpIso = $nearestSidebarFollowUp?->scheduled_at?->toIso8601String();
            $nearestFollowUpIsOverdue = $nearestSidebarFollowUp?->scheduled_at?->isPast() ?? false;

            // Each entry: label, named route, active route pattern, permission, icon.
            $menuGroups = [
                'Calling CRM' => [
                    ['Call History', 'calling-crm.index', 'calling-crm.*', 'calling-crm.view', 'history'],
                    ['Manage Leads', 'manage.leads.index', 'manage.leads.*', 'manage.leads.view', 'contact-round'],
                    ['Recycle Bin', 'recycle-bin.index', 'recycle-bin.*', 'recycle-bin.view', 'trash-2'],
                    ['Demo Cities', 'demo-cities.index', 'demo-cities.*', 'demo-cities.view', 'map-pinned'],
                ],
                'Workspace' => [

                    ['Categories', 'categories.index', 'categories.*', 'categories.view|categories.create', 'folder-tree'],
                    ['Leads', 'leads.index', 'leads.*', 'leads.view', 'users'],
                    ['Data', 'data.index', 'data.*', 'data.view', 'database'],
                    ['Pipeline', 'pipeline.index', 'pipeline.*', 'pipeline.view', 'workflow'],
                    ['Follow-ups', 'followups.index', 'followups.*', 'followups.view', 'phone-forwarded'],
                    ['Call Logs', 'calls.index', 'calls.*', 'calls.view', 'phone'],
                ],
                'Organization' => [
                    ['Companies', 'companies.index', 'companies.*', 'companies.view', 'building-2'],
                    ['Employees', 'employees.index', 'employees.*', 'employees.view', 'user-round'],
                    ['Branches', 'branches.index', 'branches.*', 'branches.view', 'map-pin'],
                    ['Teams', 'teams.index', 'teams.*', 'teams.view', 'users-round'],
                    ['Roles & Permissions', 'access-control.index', 'access-control.*', 'access-control.view', 'shield-check'],
                ],
                'Sales' => [
                    ['Campaigns', 'campaigns.index', 'campaigns.*', 'campaigns.view', 'megaphone'],
                    ['Products', 'products.index', 'products.*', 'products.view', 'package'],
                    ['Customers', 'customers.index', 'customers.*', 'customers.view', 'circle-user-round'],
                    ['Tasks', 'tasks.index', 'tasks.*', 'tasks.view', 'list-checks'],
                    ['Orders', 'orders.index', 'orders.*', 'orders.view', 'shopping-cart'],
                    ['Payments', 'payments.index', 'payments.*', 'payments.view', 'credit-card'],
                    ['Reports', 'reports.index', 'reports.*', 'reports.view', 'chart-no-axes-combined'],
                    ['WhatsApp Templates', 'whatsapp-templates.index', 'whatsapp-templates.*', 'whatsapp-template.view-own|whatsapp-template.view-all', 'message-circle'],
                ],
                'CRM Settings' => [
                    ['Lead Sources', 'crm-settings.lead-sources.index', 'crm-settings.lead-sources.*', 'lead-sources.view', 'waypoints'],
                    ['Lead Statuses', 'crm-settings.lead-statuses.index', 'crm-settings.lead-statuses.*', 'lead-statuses.view', 'list-filter'],
                    ['Call Dispositions', 'crm-settings.call-dispositions.index', 'crm-settings.call-dispositions.*', 'call-dispositions.view', 'sliders-horizontal'],
                    ['Mobile APKs', 'mobile-apks.index', 'mobile-apks.*', 'mobile-apks.view', 'smartphone'],
                ],
            ];

            $groupIcons = [
                'Calling CRM' => 'headset',
                'Workspace' => 'layout-grid',
                'Organization' => 'building-2',
                'Sales' => 'badge-indian-rupee',
                'CRM Settings' => 'settings-2',
            ];

            // Keep only the links that the user can actually open.
            // Pipe-separated permissions mean ANY of them, not a single permission name.
            $visibleMenuGroups = [];
            foreach ($menuGroups as $groupName => $items) {
                foreach ($items as $item) {
                    [$label, $routeName, $activePattern, $permissions, $icon] = $item;
                    $canView = $isSuperAdmin;
                    foreach (explode('|', $permissions) as $permission) {
                        if ($user->can(trim($permission))) {
                            $canView = true;
                            break;
                        }
                    }
                    if ($canView && \Illuminate\Support\Facades\Route::has($routeName)) {
                        $visibleMenuGroups[$groupName][] = $item;
                    }
                }
            }
        @endphp

        <style>
            .crm-menu-group > summary { list-style: none; cursor: pointer; }
            .crm-menu-group > summary::-webkit-details-marker { display: none; }
            .crm-menu-group > summary .crm-menu-chevron { transition: transform .2s ease; }
            .crm-menu-group[open] > summary .crm-menu-chevron { transform: rotate(180deg); }
            .crm-menu-group[open] > summary { background: rgba(255,255,255,.10); color: #fff; }
            .crm-menu-group > summary:focus-visible { outline: 2px solid #93c5fd; outline-offset: 2px; }
            .crm-menu-children { margin: 5px 0 8px 19px; padding-left: 12px; border-left: 1px solid rgba(255,255,255,.15); }
            .crm-menu-children .crm-nav-link svg { width: 16px; height: 16px; }
        </style>

        <nav class="space-y-1 p-3 pb-6" aria-label="Main navigation">
            @if (session()->has('impersonator_id'))
                <div class="mb-3 rounded-xl border border-amber-300 bg-amber-50 p-3 text-amber-900">
                    <div class="mb-2 text-xs">Viewing <strong>{{ $user->name }}</strong> dashboard.</div>
                    <form method="POST" action="{{ route('employees.stop-impersonating') }}">
                        @csrf
                        <button type="submit" class="rounded-lg bg-slate-900 px-3 py-2 text-xs font-semibold text-white">
                            ← Back to My Account
                        </button>
                    </form>
                </div>
            @endif


            {{-- DASHBOARD - MAIN MENU (TOP) --}}
            @if(
                \Illuminate\Support\Facades\Route::has('dashboard')
                && ($isSuperAdmin || $user->can('dashboard.view'))
            )
                <a
                    href="{{ route('dashboard') }}"
                    @if(request()->routeIs('dashboard')) aria-current="page" @endif
                    class="crm-nav-link flex items-center gap-3 rounded-xl px-4 py-3 text-sm font-semibold transition
                    {{ request()->routeIs('dashboard')
                        ? 'is-active text-white'
                        : 'text-slate-200 hover:bg-white/10 hover:text-white' }}"
                >
                    <i data-lucide="layout-dashboard"
                    class="h-[19px] w-[19px] shrink-0"></i>

                    <span>Dashboard</span>
                </a>
            @endif


            @foreach($visibleMenuGroups as $groupName => $links)
                @php
                    $groupActive = collect($links)->contains(fn ($link) => request()->routeIs($link[2]));
                @endphp
                <details class="crm-menu-group rounded-xl" {{ $groupActive ? 'open' : '' }}>
                    <summary class="flex items-center justify-between gap-3 rounded-xl px-4 py-3 text-sm font-semibold text-slate-200 transition hover:bg-white/10 hover:text-white {{ $groupActive ? 'bg-white/10 text-white' : '' }}">
                        <span class="flex min-w-0 items-center gap-3">
                            <i data-lucide="{{ $groupIcons[$groupName] ?? 'folder' }}" class="h-[19px] w-[19px] shrink-0"></i>
                            <span class="truncate">{{ $groupName }}</span>
                        </span>
                        <i data-lucide="chevron-down" class="crm-menu-chevron h-4 w-4 shrink-0 text-slate-400"></i>
                    </summary>
                    <div class="crm-menu-children space-y-1">
                        @foreach($links as $link)
                            @php
                                [$text, $route, $pattern, $permission, $icon] = $link;
                                $isActive = request()->routeIs($pattern);
                            @endphp
                            <a href="{{ route($route) }}"
                               @if($isActive) aria-current="page" @endif
                               class="crm-nav-link flex min-h-[39px] items-center justify-between gap-2 rounded-lg px-3 py-2 text-[12px] font-medium transition {{ $isActive ? 'is-active text-white' : 'text-slate-300 hover:bg-white/10 hover:text-white' }}">
                                <span class="flex min-w-0 items-center gap-2.5">
                                    <i data-lucide="{{ $icon }}" class="shrink-0"></i>
                                    <span class="truncate">{{ $text }}</span>
                                </span>
                                @if($route === 'followups.index')
                                    <span id="sidebarNearestFollowup"
                                          data-time="{{ $nearestFollowUpIso }}"
                                          class="{{ $nearestSidebarFollowUp ? '' : 'hidden' }} inline-flex shrink-0 items-center gap-1 rounded-full border px-1.5 py-1 text-[9px] font-black tabular-nums {{ $nearestFollowUpIsOverdue ? 'sidebar-followup-reminder border-red-400/50 bg-red-500 text-white' : 'border-amber-300/40 bg-amber-400 text-slate-950' }}"
                                          title="Nearest pending follow-up">
                                        <span id="sidebarNearestFollowupDot" class="sidebar-followup-dot h-1.5 w-1.5 rounded-full bg-current"></span>
                                        <span id="sidebarNearestFollowupText">Loading...</span>
                                    </span>
                                @endif
                            </a>
                        @endforeach
                    </div>
                </details>
            @endforeach

            <div class="!mt-5 rounded-xl border border-white/10 bg-white/[.07] p-3 text-white shadow-lg">
                <div class="flex items-center gap-3">
                    <div class="flex h-9 w-9 items-center justify-center rounded-lg border border-cyan-400/30 bg-cyan-400/10 text-cyan-300">
                        <i data-lucide="headphones" class="h-5 w-5"></i>
                    </div>
                    <div class="min-w-0 flex-1">
                        <div class="text-xs font-semibold">Need Help?</div>
                        <div class="mt-0.5 text-[10px] text-cyan-300">Contact Support</div>
                    </div>
                    <i data-lucide="chevron-right" class="h-4 w-4 text-slate-300"></i>
                </div>
            </div>
        </nav>

    </aside>


    {{-- ========================================================= --}}
    {{-- MAIN CONTENT --}}
    {{-- ========================================================= --}}

    <div id="crmSidebarBackdrop" class="crm-sidebar-backdrop fixed inset-0 z-50 hidden bg-slate-950/60 backdrop-blur-sm lg:hidden"></div>

    <main id="crmMain" class="crm-main min-w-0 flex-1 lg:ml-72">


        {{-- ===================================================== --}}
        {{-- HEADER --}}
        {{-- ===================================================== --}}

        <header
            class="
                sticky
                top-0
                z-20
                flex
                items-center
                justify-between
                crm-header
                border-b
                bg-white/95
                px-5
                py-4
                backdrop-blur
                lg:px-8
            "
        >

            {{-- Company / Branch --}}

            <div class="flex min-w-0 items-center gap-4">
                <button type="button" id="crmSidebarToggle" class="crm-icon-button" aria-label="Hide navigation" aria-expanded="true">
                    <i data-lucide="menu"></i>
                </button>

                <div class="min-w-0">

                <div class="font-semibold text-slate-900">

                    @if($isSuperAdmin)

                        {{
                            auth()->user()->company?->name
                            ?? 'TeleCRM Platform'
                        }}

                    @else

                        {{
                            auth()->user()->company?->name
                            ?? 'TeleCRM Workspace'
                        }}

                    @endif

                </div>


                <div class="text-xs text-slate-500">

                    @if($isSuperAdmin)

                        Super Admin

                    @else

                        {{
                            auth()->user()->branch?->name
                            ?? 'All Branches'
                        }}

                    @endif

                </div>

                </div>
            </div>


            {{-- User --}}

            <div class="flex items-center gap-4">

                <div class="crm-avatar hidden h-10 w-10 shrink-0 items-center justify-center rounded-full text-xs font-bold text-white sm:flex">
                    {{ strtoupper(substr(auth()->user()->name ?? 'U', 0, 2)) }}
                </div>

                <div class="text-right">

                    <div class="text-sm font-medium">
                        {{ auth()->user()->name }}
                    </div>

                    <div class="text-xs text-slate-500">

                        {{
                            auth()
                                ->user()
                                ->roles
                                ->pluck('name')
                                ->join(', ')
                        }}

                    </div>

                </div>


                {{-- Logout --}}

                <form
                    method="POST"
                    action="{{ route('logout') }}"
                >

                    @csrf

                    <button type="submit" class="crm-logout">
                        <i data-lucide="log-out"></i>
                        <span class="hidden sm:inline">Logout</span>
                    </button>

                </form>

            </div>

        </header>


        {{-- ===================================================== --}}
        {{-- PAGE CONTENT --}}
        {{-- ===================================================== --}}

        <section class="p-3 sm:p-5 lg:p-5">

            {{-- Success Message --}}

            @if(session('success'))

                <div
                    class="
                        mb-5
                        rounded-lg
                        border
                        border-emerald-200
                        bg-emerald-50
                        p-4
                        text-emerald-700
                    "
                >
                    {{ session('success') }}
                </div>

            @endif


            {{-- Error Message --}}

            @if(session('error'))

                <div
                    class="
                        mb-5
                        rounded-lg
                        border
                        border-rose-200
                        bg-rose-50
                        p-4
                        text-rose-700
                    "
                >
                    {{ session('error') }}
                </div>

            @endif


            {{-- Validation Errors --}}

            @if($errors->any())

                <div
                    class="
                        mb-5
                        rounded-lg
                        border
                        border-rose-200
                        bg-rose-50
                        p-4
                        text-rose-700
                    "
                >

                    <div class="font-semibold">
                        Please fix the following errors:
                    </div>

                    <ul
                        class="
                            mt-2
                            list-disc
                            space-y-1
                            pl-5
                            text-sm
                        "
                    >

                        @foreach($errors->all() as $error)

                            <li>
                                {{ $error }}
                            </li>

                        @endforeach

                    </ul>

                </div>

            @endif


            @yield('content')

        </section>

    </main>

</div>

{{-- ============================================================= --}}
{{-- GLOBAL FOLLOW-UP REMINDER BACKDROP --}}
<div id="followUpReminderBackdrop" class="auto-feedback-backdrop fixed inset-0 z-[99998] hidden"></div>

{{-- ============================================================= --}}
{{-- GLOBAL FOLLOW-UP REMINDER MODAL - FEEDBACK STYLE + SNOOZE --}}
{{-- ============================================================= --}}
<div id="followUpReminderModal" class="fixed inset-0 z-[99999] hidden items-center justify-center overflow-y-auto p-2 sm:p-4">
    <div id="followUpReminderCard" class="auto-feedback-card relative flex flex-col overflow-hidden">

        {{-- HEADER --}}
        <div id="followUpReminderTop" class="auto-feedback-head shrink-0 px-4 pb-3 pt-4 sm:px-5">
            <div class="flex items-start justify-between gap-3">
                <div class="min-w-0">
                    <div class="auto-feedback-tag">
                        <i data-lucide="bell-ring" class="h-3.5 w-3.5"></i>
                        Follow-up Reminder
                    </div>
                    <div id="followUpReminderHeading" class="mt-2 text-[20px] font-black leading-tight text-slate-900">Follow-up is overdue</div>
                    <div class="mt-2 flex flex-wrap items-center gap-2 text-[10px] font-semibold text-slate-500">
                        <span id="followUpTimerBox" class="inline-flex items-center gap-1.5 rounded-lg border border-amber-200 bg-amber-50 px-2.5 py-1.5 text-amber-700">
                            <i data-lucide="clock-3" class="h-3.5 w-3.5"></i>
                            <span id="followUpTimerLabel">Overdue by</span>
                            <span id="followUpCountdown" class="font-black tabular-nums">00:00:00</span>
                        </span>
                        <label class="inline-flex cursor-pointer items-center gap-2 rounded-lg border border-slate-200 bg-white px-2.5 py-1.5">
                            <input type="checkbox" id="followUpReminderEnabledToggle" class="peer sr-only" checked>
                            <span class="relative h-4 w-8 rounded-full bg-slate-300 transition after:absolute after:left-0.5 after:top-0.5 after:h-3 after:w-3 after:rounded-full after:bg-white after:transition peer-checked:bg-emerald-500 peer-checked:after:translate-x-4"></span>
                            <span id="followUpReminderEnabledText">Popup ON</span>
                        </label>
                    </div>
                </div>
                <button type="button" id="followUpReminderClose" class="auto-feedback-close shrink-0" title="Close reminder" aria-label="Close reminder">
                    <i data-lucide="x" class="h-5 w-5"></i>
                </button>
            </div>
        </div>

        {{-- SCROLLABLE BODY --}}
        <div class="min-h-0 flex-1 overflow-y-auto px-4 pb-3 sm:px-5">

            {{-- SUMMARY --}}
            <div class="auto-feedback-summary mb-3">
                <div class="auto-feedback-summary-card">
                    <span class="auto-feedback-icon"><i data-lucide="store" class="h-4 w-4"></i></span>
                    <div class="min-w-0">
                        <div class="text-[8px] font-black uppercase tracking-wide text-slate-400">Lead / Business</div>
                        <div id="followUpLeadName" class="mt-1 truncate text-[11px] font-black text-slate-800">-</div>
                    </div>
                </div>
                <div class="auto-feedback-summary-card">
                    <span class="auto-feedback-icon"><i data-lucide="phone" class="h-4 w-4"></i></span>
                    <div class="min-w-0">
                        <div class="text-[8px] font-black uppercase tracking-wide text-slate-400">Mobile</div>
                        <div id="followUpMobile" class="mt-1 truncate text-[11px] font-black text-slate-800">-</div>
                    </div>
                </div>
                <div class="auto-feedback-summary-card">
                    <span class="auto-feedback-icon"><i data-lucide="calendar-clock" class="h-4 w-4"></i></span>
                    <div class="min-w-0">
                        <div class="text-[8px] font-black uppercase tracking-wide text-slate-400">Scheduled</div>
                        <div id="followUpScheduledAt" class="mt-1 text-[11px] font-black text-slate-800">-</div>
                    </div>
                </div>
            </div>

            {{-- TOP ACTIONS --}}
            <div class="auto-feedback-actions mb-3 grid grid-cols-2 gap-2">
                <a id="followUpCallButton" href="#" class="auto-feedback-primary hidden">
                    <i data-lucide="phone-call" class="h-4 w-4"></i> Call Now
                </a>
                <a id="followUpOpenLeadButton" href="#" class="auto-feedback-primary secondary">
                    <i data-lucide="external-link" class="h-4 w-4"></i> Open Lead
                </a>
            </div>

            {{-- PREVIOUS FOLLOW-UP NOTE --}}
            <div id="followUpNotesWrapper" class="mb-3 rounded-xl border border-violet-100 bg-violet-50/70 px-3 py-2.5">
                <div class="flex gap-2">
                    <i data-lucide="message-square-text" class="mt-0.5 h-4 w-4 shrink-0 text-violet-600"></i>
                    <div class="min-w-0">
                        <div class="text-[8px] font-black uppercase tracking-wide text-violet-500">Previous Follow-up Note</div>
                        <div id="followUpNotes" class="mt-1 whitespace-pre-line text-[10px] font-semibold leading-5 text-slate-700">-</div>
                    </div>
                </div>
            </div>

            {{-- FEEDBACK FORM --}}
            @can('calls.create')
            <div class="auto-feedback-panel">
                <div class="mb-3 flex items-center gap-2">
                    <span class="auto-feedback-icon !h-8 !w-8 !basis-8"><i data-lucide="message-square-text" class="h-4 w-4"></i></span>
                    <div>
                        <div class="text-[12px] font-black text-slate-800">Save Feedback</div>
                        <div class="text-[9px] font-semibold text-slate-400">Same feedback flow as Leads Index</div>
                    </div>
                </div>

                <form id="followUpPopupCallForm" method="POST" action="">
                    @csrf
                    <input type="hidden" name="from_followup_popup" value="1">
                    <input type="hidden" id="followUpPopupFollowUpId" name="follow_up_id" value="">
                    <div class="auto-feedback-form-grid grid grid-cols-2 gap-3">
                        <div class="auto-feedback-field">
                            <label>Call Result <span class="text-rose-500">*</span></label>
                            <select id="followUpPopupDisposition" name="call_disposition_id" required>
                                <option value="">Select disposition</option>
                            </select>
                            <div id="followUpPopupDispositionHint" class="mt-1 hidden text-[9px] font-semibold text-amber-700"></div>
                        </div>

                        <div class="auto-feedback-field">
                            <span class="label">Call Duration</span>
                            <div class="flex min-h-[42px] items-center rounded-[10px] border border-slate-300 bg-white px-3">
                                <i data-lucide="clock-3" class="mr-2 h-4 w-4 text-slate-400"></i>
                                <span id="followUpPopupDurationDisplay" class="text-[11px] font-black tabular-nums text-slate-700">00:00</span>
                                <span class="ml-auto text-[9px] font-semibold text-slate-400">mm:ss</span>
                                <input id="followUpPopupDuration" name="duration_seconds" type="hidden" value="0">
                            </div>
                        </div>

                        <div id="followUpPopupRemarksWrapper" class="auto-feedback-field col-span-2">
                            <label>Remarks <span id="followUpPopupRemarksRequired" class="hidden text-rose-500">*</span></label>
                            <textarea id="followUpPopupRemarks" name="remarks" maxlength="500" placeholder="Customer ne kya kaha..."></textarea>
                        </div>
                    </div>

                    <div id="followUpPopupNextFollowUpWrapper" class="auto-feedback-field mt-3 hidden">
                        <label>Next Follow-up <span id="followUpPopupNextFollowUpRequired" class="hidden text-rose-500">*</span></label>
                        <input id="followUpPopupNextFollowUp" name="follow_up_at" type="datetime-local">
                    </div>

                    <div class="mt-3">
                        <button
                            type="submit"
                            id="followUpPopupSaveCall"
                            class="flex min-h-[44px] w-full items-center justify-center gap-2 rounded-[10px] bg-emerald-600 px-4 text-[11px] font-black text-white transition hover:bg-emerald-700 disabled:cursor-not-allowed disabled:opacity-60"
                        >
                            <i data-lucide="save" class="h-4 w-4"></i>
                            Save Feedback
                        </button>
                    </div>
                </form>
            </div>
            @endcan

            <div id="followUpQueueInfo" class="mt-2 hidden rounded-lg border border-amber-200 bg-amber-50 px-3 py-2 text-[9px] font-bold text-amber-700"></div>
            <div id="followUpActionMessage" class="mt-2 hidden rounded-lg px-3 py-2 text-[10px] font-bold"></div>
        </div>

        {{-- FOOTER: KEEP SNOOZE --}}
        <div class="auto-feedback-footer shrink-0 border-t border-amber-100 px-4 py-3 sm:px-5">
            <div class="auto-feedback-footer-row flex items-center justify-between gap-3">
                <div class="flex flex-wrap items-center gap-2">
                    <button type="button" id="followUpRescheduleToggle" class="auto-feedback-snooze text-indigo-700">
                        <i data-lucide="calendar-days" class="h-4 w-4"></i> Reschedule
                    </button>
                    <span class="text-[9px] font-black uppercase tracking-wide text-slate-400">Snooze</span>
                    <button type="button" data-snooze="10" class="followup-snooze-btn auto-feedback-snooze">10 Min</button>
                    <button type="button" data-snooze="30" class="followup-snooze-btn auto-feedback-snooze">30 Min</button>
                    <button type="button" data-snooze="60" class="followup-snooze-btn auto-feedback-snooze">1 Hour</button>
                </div>


            </div>

            <div id="followUpReschedulePanel" class="absolute bottom-[62px] left-4 z-30 hidden w-[360px] max-w-[calc(100%-32px)] rounded-xl border border-amber-200 bg-white p-4 shadow-2xl">
                <label for="followUpRescheduleInput" class="block text-[9px] font-black uppercase tracking-wide text-amber-700">New Date & Time</label>
                <input type="datetime-local" id="followUpRescheduleInput" class="mt-2 h-10 w-full rounded-lg border border-slate-300 bg-white px-3 text-sm font-semibold text-slate-800 outline-none focus:border-amber-400 focus:ring-2 focus:ring-amber-100">
                <div class="mt-3 flex gap-2">
                    <button type="button" id="followUpRescheduleSave" class="flex-1 rounded-lg bg-amber-400 px-4 py-2.5 text-sm font-black text-slate-900 hover:bg-amber-500 disabled:opacity-60">Save New Time</button>
                    <button type="button" id="followUpRescheduleClose" class="rounded-lg border border-slate-200 bg-white px-4 py-2.5 text-sm font-bold text-slate-600 hover:bg-slate-50">Close</button>
                </div>
            </div>

            <button type="button" id="followUpRemindFiveButton" class="hidden"></button>
            <button type="button" id="followUpCancelButton" class="hidden"></button>
        </div>
    </div>
</div>

{{-- GLOBAL FOLLOW-UP REMINDER SCRIPT --}}
{{-- ============================================================= --}}

<script>
document.addEventListener('DOMContentLoaded', function () {

    if (window.lucide) window.lucide.createIcons();

    const crmSidebar = document.getElementById('crmSidebar');
    const crmSidebarToggle = document.getElementById('crmSidebarToggle');
    const crmSidebarBackdrop = document.getElementById('crmSidebarBackdrop');
    const crmMain = document.getElementById('crmMain');

    const desktopSidebarPreferenceKey = 'crm_desktop_sidebar_collapsed';

    const isDesktopScreen = () => window.matchMedia('(min-width: 1024px)').matches;

    const closeMobileSidebar = () => {
        crmSidebar?.classList.remove('is-open');
        crmSidebarBackdrop?.classList.remove('is-open');
        document.body.classList.remove('overflow-hidden');
    };

    const setDesktopSidebarCollapsed = (collapsed, savePreference = true) => {
        if (!crmSidebar || !crmMain) {
            return;
        }

        crmSidebar.classList.toggle('is-collapsed', collapsed);
        crmMain.classList.toggle('is-sidebar-expanded', collapsed);

        crmSidebarToggle?.setAttribute(
            'aria-label',
            collapsed ? 'Show navigation' : 'Hide navigation'
        );

        crmSidebarToggle?.setAttribute(
            'aria-expanded',
            collapsed ? 'false' : 'true'
        );

        if (savePreference) {
            localStorage.setItem(
                desktopSidebarPreferenceKey,
                collapsed ? '1' : '0'
            );
        }
    };

    const syncSidebarForCurrentScreen = () => {
        if (isDesktopScreen()) {
            // Mobile classes desktop par carry na hon.
            closeMobileSidebar();

            const collapsed =
                localStorage.getItem(desktopSidebarPreferenceKey) === '1';

            setDesktopSidebarCollapsed(collapsed, false);
            return;
        }

        // Desktop collapse classes mobile par carry na hon.
        crmSidebar?.classList.remove('is-collapsed');
        crmMain?.classList.remove('is-sidebar-expanded');

        crmSidebarToggle?.setAttribute('aria-label', 'Open navigation');
        crmSidebarToggle?.setAttribute('aria-expanded', 'false');
    };

    crmSidebarToggle?.addEventListener('click', () => {
        if (isDesktopScreen()) {
            const collapsed = !crmSidebar?.classList.contains('is-collapsed');
            setDesktopSidebarCollapsed(collapsed);
            return;
        }

        const willOpen = !crmSidebar?.classList.contains('is-open');

        crmSidebar?.classList.toggle('is-open', willOpen);
        crmSidebarBackdrop?.classList.toggle('is-open', willOpen);
        document.body.classList.toggle('overflow-hidden', willOpen);

        crmSidebarToggle?.setAttribute(
            'aria-expanded',
            willOpen ? 'true' : 'false'
        );
    });

    crmSidebarBackdrop?.addEventListener('click', closeMobileSidebar);

    crmSidebar?.querySelectorAll('a').forEach(link => {
        link.addEventListener('click', () => {
            if (!isDesktopScreen()) {
                closeMobileSidebar();
            }
        });
    });

    window.addEventListener('resize', syncSidebarForCurrentScreen);

    syncSidebarForCurrentScreen();

    const reminderUrl = @json(route('followups.reminders'));
    const sidebarNearestUrl = @json(route('followups.nearest'));

    /*
    |--------------------------------------------------------------------------
    | Demo Send Route Template
    |--------------------------------------------------------------------------
    | Same backend flow as Lead Details page:
    | PATCH leads.update
    | demo_send_only = 1
    | demo_send      = 1
    */
    const demoSendUpdateUrlTemplate =
        @json(route('leads.update', ['lead' => '__LEAD_ID__']));

    const csrfToken = document
        .querySelector('meta[name="csrf-token"]')
        ?.getAttribute('content');

    const modal = document.getElementById('followUpReminderModal');
    const backdrop = document.getElementById('followUpReminderBackdrop');
    const topBar = document.getElementById('followUpReminderTop');
    const heading = document.getElementById('followUpReminderHeading');
    const timerBox = document.getElementById('followUpTimerBox');
    const timerLabel = document.getElementById('followUpTimerLabel');
    const countdown = document.getElementById('followUpCountdown');
    const leadName = document.getElementById('followUpLeadName');
    const mobile = document.getElementById('followUpMobile');
    const scheduledAt = document.getElementById('followUpScheduledAt');
    const type = document.getElementById('followUpType');
    const priority = document.getElementById('followUpPriority');
    const assignedUser = document.getElementById('followUpAssignedUser');
    const notesWrapper = document.getElementById('followUpNotesWrapper');
    const notes = document.getElementById('followUpNotes');
    const queueInfo = document.getElementById('followUpQueueInfo');
    const callButton = document.getElementById('followUpCallButton');
    const openLeadButton = document.getElementById('followUpOpenLeadButton');
    const completeButton = document.getElementById('followUpCompleteButton');
    const closeButton = document.getElementById('followUpReminderClose');
    const remindFiveButton = document.getElementById('followUpRemindFiveButton');
    const cancelButton = document.getElementById('followUpCancelButton');
    const rescheduleToggle = document.getElementById('followUpRescheduleToggle');
    const reschedulePanel = document.getElementById('followUpReschedulePanel');
    const rescheduleInput = document.getElementById('followUpRescheduleInput');
    const rescheduleSave = document.getElementById('followUpRescheduleSave');
    const rescheduleClose = document.getElementById('followUpRescheduleClose');
    const actionMessage = document.getElementById('followUpActionMessage');

    const reminderEnabledToggle = document.getElementById('followUpReminderEnabledToggle');
    const reminderEnabledText = document.getElementById('followUpReminderEnabledText');

    const popupCallForm = document.getElementById('followUpPopupCallForm');
    const popupFollowUpId = document.getElementById('followUpPopupFollowUpId');
    const popupSaveCallButton = document.getElementById('followUpPopupSaveCall');
    const popupDisposition = document.getElementById('followUpPopupDisposition');
    const popupDispositionHint = document.getElementById('followUpPopupDispositionHint');
    const popupDuration = document.getElementById('followUpPopupDuration');
    const popupRemarksWrapper = document.getElementById('followUpPopupRemarksWrapper');
    const popupRemarks = document.getElementById('followUpPopupRemarks');
    const popupRemarksRequired = document.getElementById('followUpPopupRemarksRequired');
    const popupNextFollowUpWrapper = document.getElementById('followUpPopupNextFollowUpWrapper');
    const popupNextFollowUp = document.getElementById('followUpPopupNextFollowUp');
    const popupNextFollowUpRequired = document.getElementById('followUpPopupNextFollowUpRequired');
    const popupDurationDisplay = document.getElementById('followUpPopupDurationDisplay');
    const sendDemoButton = document.getElementById('followUpSendDemoButton');
    let callDurationInterval = null;
    let callDurationStartedAt = null;

    const sidebarNearestFollowup = document.getElementById('sidebarNearestFollowup');
    const sidebarNearestFollowupText = document.getElementById('sidebarNearestFollowupText');
    const sidebarNearestFollowupDot = document.getElementById('sidebarNearestFollowupDot');

    let reminderQueue = [];
    let currentReminder = null;
    let countdownInterval = null;
    let isFetching = false;
    let modalOpen = false;
    let audioContext = null;
    /*
    |--------------------------------------------------------------------------
    | Call Dispositions
    |--------------------------------------------------------------------------
    | Popup ko auto_remarks aur next_followup bhi chahiye.
    | Isliye current company ke active dispositions directly Blade se preload
    | kar rahe hain. Reminder API agar dispositions return kare to niche merge
    | hoga, lekin auto_remarks / next_followup lose nahi honge.
    */
    @php
        $popupCallDispositions = \App\Models\CallDisposition::query()
            ->where('company_id', auth()->user()->company_id)
            ->where('is_active', true)
            ->orderBy('name')
            ->get([
                'id',
                'name',
                'requires_remarks',
                'requires_follow_up',
                'auto_remarks',
                'next_followup',
            ]);
    @endphp

    let callDispositions = @json($popupCallDispositions);

    let popupCallResultSaved = false;

    const reminderPreferenceKey =
        'followup_popup_enabled_user_' + @json(auth()->id());

    function isReminderPopupEnabled() {
        return localStorage.getItem(reminderPreferenceKey) !== '0';
    }

    function syncReminderPreferenceUi() {
        const enabled = isReminderPopupEnabled();

        if (reminderEnabledToggle) {
            reminderEnabledToggle.checked = enabled;
        }

        if (reminderEnabledText) {
            reminderEnabledText.textContent = enabled ? 'Popup ON' : 'Popup OFF';
        }
    }

    function disableReminderPopupNow() {
        reminderQueue = [];
        if (modalOpen) {
            closeModal(false);
        }
    }

    function escapePhone(phone) {
        if (!phone) {
            return '';
        }

        return String(phone).replace(/[^\d+]/g, '');
    }

    function snoozeStorageKey(id) {
        return 'followup_reminder_hidden_' + id;
    }

    function dismissedStorageKey(id) {
        return 'followup_reminder_dismissed_' + id;
    }

    function isTemporarilyHidden(id) {
        const value = localStorage.getItem(snoozeStorageKey(id));

        if (!value) {
            return false;
        }

        const hiddenUntil = parseInt(value, 10);

        if (!hiddenUntil || Date.now() >= hiddenUntil) {
            localStorage.removeItem(snoozeStorageKey(id));
            return false;
        }

        return true;
    }

    function hideTemporarily(id, minutes = 5) {
        const until = Date.now() + (minutes * 60 * 1000);

        localStorage.setItem(
            snoozeStorageKey(id),
            String(until)
        );
    }

    function clearTemporaryHide(id) {
        localStorage.removeItem(snoozeStorageKey(id));
    }

    /*
    |--------------------------------------------------------------------------
    | Close/Dismiss
    |--------------------------------------------------------------------------
    | Close button DB ko modify nahi karta.
    | Same scheduled_at ke liye current browser tab/session me dobara popup nahi
    | khulega. Agar follow-up reschedule hota hai to scheduled_at change hone ki
    | wajah se reminder automatically eligible ho jayega.
    */
    function dismissReminder(reminder) {
        if (!reminder) {
            return;
        }

        sessionStorage.setItem(
            dismissedStorageKey(reminder.id),
            String(reminder.scheduled_at || '')
        );
    }

    function isDismissed(reminder) {
        const saved = sessionStorage.getItem(
            dismissedStorageKey(reminder.id)
        );

        if (!saved) {
            return false;
        }

        if (saved !== String(reminder.scheduled_at || '')) {
            sessionStorage.removeItem(
                dismissedStorageKey(reminder.id)
            );
            return false;
        }

        return true;
    }

    function clearDismissed(id) {
        sessionStorage.removeItem(
            dismissedStorageKey(id)
        );
    }

    function toDatetimeLocalValue(dateString) {
        if (!dateString) {
            return '';
        }

        const date = new Date(dateString);

        if (Number.isNaN(date.getTime())) {
            return '';
        }

        const pad = value => String(value).padStart(2, '0');

        return date.getFullYear()
            + '-'
            + pad(date.getMonth() + 1)
            + '-'
            + pad(date.getDate())
            + 'T'
            + pad(date.getHours())
            + ':'
            + pad(date.getMinutes());
    }

    function minimumDatetimeLocalValue() {
        const date = new Date();
        const pad = value => String(value).padStart(2, '0');

        return date.getFullYear()
            + '-'
            + pad(date.getMonth() + 1)
            + '-'
            + pad(date.getDate())
            + 'T'
            + pad(date.getHours())
            + ':'
            + pad(date.getMinutes());
    }

    function playReminderSound() {
        try {
            const AudioContext = window.AudioContext || window.webkitAudioContext;

            if (!AudioContext) {
                return;
            }

            if (!audioContext) {
                audioContext = new AudioContext();
            }

            const playTone = (frequency, start, duration) => {
                const oscillator = audioContext.createOscillator();
                const gain = audioContext.createGain();

                oscillator.type = 'sine';
                oscillator.frequency.value = frequency;

                gain.gain.setValueAtTime(
                    0.0001,
                    audioContext.currentTime + start
                );

                gain.gain.exponentialRampToValueAtTime(
                    0.20,
                    audioContext.currentTime + start + 0.02
                );

                gain.gain.exponentialRampToValueAtTime(
                    0.0001,
                    audioContext.currentTime + start + duration
                );

                oscillator.connect(gain);
                gain.connect(audioContext.destination);

                oscillator.start(audioContext.currentTime + start);
                oscillator.stop(
                    audioContext.currentTime + start + duration + 0.05
                );
            };

            playTone(880, 0, 0.22);
            playTone(1100, 0.28, 0.22);
            playTone(880, 0.56, 0.30);

        } catch (error) {
            console.log('Reminder sound unavailable.', error);
        }
    }

    function showBrowserNotification(reminder) {
        if (!('Notification' in window)) {
            return;
        }

        if (Notification.permission !== 'granted') {
            return;
        }

        try {
            const statusText = reminder.is_overdue
                ? 'Follow-up is overdue'
                : 'Follow-up due in ' + reminder.minutes_remaining + ' minute(s)';

            const notification = new Notification(
                'Follow-up Reminder',
                {
                    body: reminder.lead_name + '\n' + statusText,
                    tag: 'followup-' + reminder.id,
                    requireInteraction: true,
                }
            );

            notification.onclick = function () {
                window.focus();

                if (reminder.lead_url) {
                    window.location.href = reminder.lead_url;
                }

                notification.close();
            };

        } catch (error) {
            console.log('Notification error', error);
        }
    }

    function requestNotificationPermission() {
        if (!('Notification' in window)) {
            return;
        }

        if (Notification.permission === 'default') {
            Notification.requestPermission().catch(() => {});
        }
    }

    function showActionMessage(message, success = true) {
        actionMessage.classList.remove(
            'hidden',
            'bg-emerald-50',
            'text-emerald-700',
            'border',
            'border-emerald-200',
            'bg-rose-50',
            'text-rose-700',
            'border-rose-200'
        );

        if (success) {
            actionMessage.classList.add(
                'bg-emerald-50',
                'text-emerald-700',
                'border',
                'border-emerald-200'
            );
        } else {
            actionMessage.classList.add(
                'bg-rose-50',
                'text-rose-700',
                'border',
                'border-rose-200'
            );
        }

        actionMessage.textContent = message;
    }

    function clearActionMessage() {
        actionMessage.classList.add('hidden');
        actionMessage.textContent = '';
    }

    function populatePopupDispositions() {
        if (!popupDisposition) {
            return;
        }

        const currentValue = popupDisposition.value;

        popupDisposition.innerHTML =
            '<option value="">Select disposition</option>';

        callDispositions.forEach(disposition => {
            const option = document.createElement('option');

            option.value = disposition.id;
            option.textContent = disposition.name;

            option.dataset.requiresRemarks =
                disposition.requires_remarks ? '1' : '0';

            option.dataset.requiresFollowUp =
                disposition.requires_follow_up ? '1' : '0';

            /*
            |--------------------------------------------------------------------------
            | NEW: Auto Remarks
            |--------------------------------------------------------------------------
            */
            option.dataset.autoRemarks =
                disposition.auto_remarks
                    ? String(disposition.auto_remarks)
                    : '';

            /*
            |--------------------------------------------------------------------------
            | NEW: Auto Next Follow-up Minutes
            |--------------------------------------------------------------------------
            */
            option.dataset.nextFollowup =
                disposition.next_followup !== null
                && disposition.next_followup !== undefined
                && disposition.next_followup !== ''
                    ? String(disposition.next_followup)
                    : '';

            popupDisposition.appendChild(option);
        });

        if (
            currentValue
            && [...popupDisposition.options].some(
                option => String(option.value) === String(currentValue)
            )
        ) {
            popupDisposition.value = currentValue;
        }
    }

    /*
    |--------------------------------------------------------------------------
    | Add Minutes To Current Browser Time
    |--------------------------------------------------------------------------
    | datetime-local input ke format me value return karega:
    | YYYY-MM-DDTHH:mm
    */
    function datetimeLocalAfterMinutes(minutes) {
        const value = Number(minutes);

        if (!Number.isFinite(value) || value <= 0) {
            return '';
        }

        const date = new Date(
            Date.now() + (value * 60 * 1000)
        );

        const pad = number =>
            String(number).padStart(2, '0');

        return date.getFullYear()
            + '-'
            + pad(date.getMonth() + 1)
            + '-'
            + pad(date.getDate())
            + 'T'
            + pad(date.getHours())
            + ':'
            + pad(date.getMinutes());
    }

    function updatePopupDispositionFields() {
        if (
            !popupDisposition
            || !popupRemarksWrapper
            || !popupRemarks
            || !popupNextFollowUpWrapper
            || !popupNextFollowUp
        ) {
            return;
        }

        const option =
            popupDisposition.options[popupDisposition.selectedIndex];

        const hasDisposition =
            !!option && !!option.value;

        const requiresRemarks =
            hasDisposition
            && option.dataset.requiresRemarks === '1';

        const requiresFollowUp =
            hasDisposition
            && option.dataset.requiresFollowUp === '1';

        /*
        |--------------------------------------------------------------------------
        | NEW: Selected Disposition Values
        |--------------------------------------------------------------------------
        */
        const autoRemarks =
            hasDisposition
                ? String(option.dataset.autoRemarks || '').trim()
                : '';

        const nextFollowupMinutes =
            hasDisposition
                ? Number(option.dataset.nextFollowup || 0)
                : 0;

        const hasAutoNextFollowup =
            Number.isFinite(nextFollowupMinutes)
            && nextFollowupMinutes > 0;

        /*
        |--------------------------------------------------------------------------
        | NEW: Fill Auto Remarks
        |--------------------------------------------------------------------------
        | Disposition me auto_remarks hai to popup remarks me automatic fill.
        | Naya disposition select karne par purana auto remark carry nahi hoga.
        */
        popupRemarks.value = autoRemarks;

        /*
        |--------------------------------------------------------------------------
        | NEW: Current Time + next_followup Minutes
        |--------------------------------------------------------------------------
        | Example:
        | next_followup = 30
        | current       = 06:00 PM
        | follow_up_at  = 06:30 PM
        |
        | Ye hidden field FormData ke through existing call save endpoint par
        | automatically submit ho jayega.
        */
        if (hasAutoNextFollowup) {
            popupNextFollowUp.value =
                datetimeLocalAfterMinutes(nextFollowupMinutes);
        } else {
            popupNextFollowUp.value = '';
        }

        /*
        |--------------------------------------------------------------------------
        | Required Rules
        |--------------------------------------------------------------------------
        | next_followup configured hai to follow-up create hona hi chahiye,
        | chahe requires_follow_up checkbox galti se off ho.
        */
        popupRemarks.required = requiresRemarks;

        popupNextFollowUp.required =
            requiresFollowUp || hasAutoNextFollowup;

        // Remarks field hamesha visible.
        popupRemarksWrapper.classList.remove('hidden');

        if (requiresRemarks) {
            popupRemarksRequired?.classList.remove('hidden');
        } else {
            popupRemarksRequired?.classList.add('hidden');
        }

        /*
        |--------------------------------------------------------------------------
        | Next Follow-up Date & Time Visibility
        |--------------------------------------------------------------------------
        | IMPORTANT:
        | requires_follow_up = true OR next_followup minutes > 0
        | => Date & Time field ALWAYS visible.
        |
        | next_followup configured hai:
        | => date/time automatic calculate + fill hoga
        | => user us date/time ko manually edit bhi kar sakta hai
        |
        | Follow-up required nahi hai:
        | => field hidden rahega
        */
        if (requiresFollowUp || hasAutoNextFollowup) {

            popupNextFollowUpWrapper.classList.remove('hidden');
            popupNextFollowUpRequired?.classList.remove('hidden');

        } else {

            popupNextFollowUpWrapper.classList.add('hidden');
            popupNextFollowUpRequired?.classList.add('hidden');

            // Follow-up required nahi hai to stale date/time submit na ho.
            popupNextFollowUp.value = '';
        }

        /*
        |--------------------------------------------------------------------------
        | Mark Form As Changed
        |--------------------------------------------------------------------------
        */
        popupCallResultSaved = false;

        if (popupSaveCallButton) {
            popupSaveCallButton.textContent = 'Save Feedback';
        }

        /*
        |--------------------------------------------------------------------------
        | Hint
        |--------------------------------------------------------------------------
        */
        if (popupDispositionHint) {
            if (!hasDisposition) {
                popupDispositionHint.classList.add('hidden');
                popupDispositionHint.textContent = '';
            } else {
                const rules = [];

                if (autoRemarks) {
                    rules.push('Auto remark filled');
                }

                if (hasAutoNextFollowup) {
                    rules.push(
                        'Next follow-up auto set: '
                        + nextFollowupMinutes
                        + ' min'
                    );
                } else if (requiresFollowUp) {
                    rules.push('Select next follow-up date & time');
                }

                if (requiresRemarks) {
                    rules.push('Remarks required');
                }

                if (rules.length === 0) {
                    rules.push(
                        'No auto remark or auto follow-up'
                    );
                }

                popupDispositionHint.textContent =
                    option.text.trim()
                    + ' — '
                    + rules.join(' • ');

                popupDispositionHint.classList.remove('hidden');
            }
        }
    }

    function resetPopupCallForm(reminder) {
        if (!popupCallForm) {
            return;
        }

        popupCallForm.reset();
        popupCallResultSaved = false;
        resetCallDuration();
        populatePopupDispositions();

        popupCallForm.action =
            reminder.call_store_url || '';

        /*
        |--------------------------------------------------------------------------
        | Exact Existing Follow-up ID
        |--------------------------------------------------------------------------
        | Controller isi follow-up ko update karega. Koi naya follow-up create nahi hoga.
        */
        if (popupFollowUpId) {
            popupFollowUpId.value = reminder.id
                ? String(reminder.id)
                : '';
        }

        if (popupNextFollowUp) {
            popupNextFollowUp.min = minimumDatetimeLocalValue();
        }

        updatePopupDispositionFields();
    }

    function formatCallDuration(totalSeconds) {
        const seconds = Math.max(0, Math.floor(Number(totalSeconds) || 0));
        const minutes = Math.floor(seconds / 60);
        const remain = seconds % 60;
        return String(minutes).padStart(2, '0') + ':' + String(remain).padStart(2, '0');
    }

    function resetCallDuration() {
        if (callDurationInterval) {
            clearInterval(callDurationInterval);
            callDurationInterval = null;
        }
        callDurationStartedAt = null;
        if (popupDuration) popupDuration.value = '0';
        if (popupDurationDisplay) popupDurationDisplay.textContent = '00:00';
    }

    function startCallDuration() {
        if (!popupDuration || !popupDurationDisplay || callDurationStartedAt) return;

        callDurationStartedAt = Date.now();
        const updateDuration = function () {
            const seconds = Math.floor((Date.now() - callDurationStartedAt) / 1000);
            popupDuration.value = String(seconds);
            popupDurationDisplay.textContent = formatCallDuration(seconds);
            popupCallResultSaved = false;
        };

        updateDuration();
        callDurationInterval = setInterval(updateDuration, 1000);
    }

    function openModal(reminder) {
        if (!reminder || !isReminderPopupEnabled()) {
            return;
        }

        // Critical elements only. Missing non-visible/optional fields must never
        // prevent the popup from opening.
        if (!modal || !backdrop) {
            console.error('Follow-up reminder modal/backdrop element is missing.');
            return;
        }

        currentReminder = reminder;
        modalOpen = true;

        clearActionMessage();
        reschedulePanel?.classList.add('hidden');

        if (leadName) {
            leadName.textContent = reminder.lead_name || 'Unknown Lead';
        }

        if (mobile) {
            mobile.textContent = reminder.mobile
                ? reminder.mobile
                : 'Mobile number not available';
        }

        if (scheduledAt) {
            scheduledAt.textContent = reminder.scheduled_at_formatted || '-';
        }

        // These fields are intentionally not visible in the new compact popup.
        // Null-checks are required because the old JS still references their IDs.
        if (type) {
            type.textContent = reminder.type || 'Follow-up';
        }

        if (priority) {
            priority.textContent = reminder.priority || 'Normal';
        }

        if (assignedUser) {
            assignedUser.textContent = reminder.assigned_user || '-';
        }

        if (reminder.notes && String(reminder.notes).trim()) {
            notesWrapper.classList.remove('hidden');
            notes.textContent = reminder.notes;
        } else {
            notesWrapper.classList.add('hidden');
        }

        const phone = escapePhone(reminder.mobile);

        if (callButton) {
            if (phone) {
                callButton.href = 'tel:' + phone;
                callButton.classList.remove('hidden');
                callButton.classList.add('flex');
            } else {
                callButton.classList.add('hidden');
                callButton.classList.remove('flex');
            }
        }

        if (openLeadButton) {
            if (reminder.lead_url) {
                openLeadButton.href = reminder.lead_url;
                openLeadButton.classList.remove('hidden');
                openLeadButton.classList.add('flex');
            } else {
                openLeadButton.classList.add('hidden');
                openLeadButton.classList.remove('flex');
            }
        }

        const remainingQueue = reminderQueue.length;

        if (queueInfo) {
            if (remainingQueue > 0) {
                queueInfo.classList.remove('hidden');
                queueInfo.textContent =
                    remainingQueue
                    + ' more follow-up reminder'
                    + (remainingQueue > 1 ? 's' : '')
                    + ' waiting';
            } else {
                queueInfo.classList.add('hidden');
            }
        }

        rescheduleInput.min = minimumDatetimeLocalValue();
        rescheduleInput.value = toDatetimeLocalValue(
            reminder.scheduled_at
        );

        resetPopupCallForm(reminder);

        // If reminder API includes demo_send, reflect it.
        // Otherwise default to normal "Send Demo" state.
        setDemoButtonState(
            reminder.demo_send === true
            || Number(reminder.demo_send) === 1
        );

        backdrop.classList.remove('hidden');
        modal.classList.remove('hidden');
        modal.classList.add('flex');
        document.body.style.overflow = 'hidden';

        startCountdown(reminder);
        playReminderSound();
        showBrowserNotification(reminder);
    }

    function closeModal(showNext = true) {
        modalOpen = false;

        backdrop.classList.add('hidden');
        modal.classList.add('hidden');
        modal.classList.remove('flex');

        reschedulePanel.classList.add('hidden');
        document.body.style.overflow = '';

        if (countdownInterval) {
            clearInterval(countdownInterval);
            countdownInterval = null;
        }

        if (callDurationInterval) {
            clearInterval(callDurationInterval);
            callDurationInterval = null;
        }
        callDurationStartedAt = null;

        currentReminder = null;

        if (showNext) {
            setTimeout(showNextReminder, 350);
        }
    }

    function closeCurrentReminder() {

        if (!currentReminder) {
            closeModal(true);
            return;
        }

        const reminder = currentReminder;
        const reminderId = reminder.id;

        /*
        |--------------------------------------------------------------------------
        | Close For 1 Minute
        |--------------------------------------------------------------------------
        |
        | X button dabane par:
        | - popup immediately close hoga
        | - DB me koi change nahi hoga
        | - same follow-up 1 minute tak hide rahega
        | - 1 minute baad pending raha to fir popup open hoga
        |
        */

        hideTemporarily(
            reminderId,
            1
        );

        /*
        |--------------------------------------------------------------------------
        | Purana Permanent/Session Dismiss Remove
        |--------------------------------------------------------------------------
        */

        clearDismissed(
            reminderId
        );

        /*
        |--------------------------------------------------------------------------
        | Current Queue Se Remove
        |--------------------------------------------------------------------------
        */

        reminderQueue = reminderQueue.filter(
            item =>
                Number(item.id)
                !==
                Number(reminderId)
        );

        /*
        |--------------------------------------------------------------------------
        | Close Popup
        |--------------------------------------------------------------------------
        */

        closeModal(true);


        /*
        |--------------------------------------------------------------------------
        | Exactly 1 Minute Baad Reminder Check
        |--------------------------------------------------------------------------
        */

        setTimeout(
            function () {

                clearTemporaryHide(
                    reminderId
                );

                fetchReminders();

            },
            60 * 1000
        );
    }

    function startCountdown(reminder) {

        if (countdownInterval) {
            clearInterval(countdownInterval);
        }

        const targetTime =
            new Date(reminder.scheduled_at).getTime();


        /*
        |--------------------------------------------------------------------------
        | HH:MM:SS Formatter
        |--------------------------------------------------------------------------
        */

        function formatTimer(totalSeconds) {

            totalSeconds = Math.max(
                0,
                Math.floor(totalSeconds)
            );

            const hours =
                Math.floor(totalSeconds / 3600);

            const minutes =
                Math.floor((totalSeconds % 3600) / 60);

            const seconds =
                totalSeconds % 60;

            return (
                String(hours).padStart(2, '0')
                + ':'
                + String(minutes).padStart(2, '0')
                + ':'
                + String(seconds).padStart(2, '0')
            );
        }


        /*
        |--------------------------------------------------------------------------
        | Update Timer
        |--------------------------------------------------------------------------
        */

        const update = function () {

            const now = Date.now();

            const difference =
                targetTime - now;


            /*
            |--------------------------------------------------------------------------
            | OVERDUE
            |--------------------------------------------------------------------------
            */

            if (difference <= 0) {

                const overdueSeconds =
                    Math.abs(
                        Math.floor(
                            difference / 1000
                        )
                    );


                heading.textContent =
                    'Follow-up is overdue';

                timerLabel.textContent =
                    'Overdue by';


                /*
                |--------------------------------------------------------------
                | HH:MM:SS
                |--------------------------------------------------------------
                */

                countdown.textContent =
                    formatTimer(overdueSeconds);


                /*
                |--------------------------------------------------------------------------
                | Red Theme
                |--------------------------------------------------------------------------
                */

                topBar.classList.remove(
                    'bg-amber-500',
                    'bg-emerald-600'
                );

                topBar.classList.add(
                    'bg-rose-600'
                );


                timerBox.classList.remove(
                    'border-amber-200',
                    'bg-amber-50',
                    'border-emerald-200',
                    'bg-emerald-50'
                );

                timerBox.classList.add(
                    'border-rose-200',
                    'bg-rose-50'
                );


                timerLabel.className =
                    'text-xs font-bold uppercase tracking-wider text-rose-700';


                countdown.className =
                    'mt-1 text-3xl font-black text-rose-800 tabular-nums';


                return;
            }


            /*
            |--------------------------------------------------------------------------
            | UPCOMING
            |--------------------------------------------------------------------------
            */

            const totalSeconds =
                Math.floor(
                    difference / 1000
                );


            heading.textContent =
                'Follow-up is due soon';

            timerLabel.textContent =
                'Time remaining';


            /*
            |--------------------------------------------------------------
            | HH:MM:SS
            |--------------------------------------------------------------
            */

            countdown.textContent =
                formatTimer(totalSeconds);


            /*
            |--------------------------------------------------------------------------
            | Amber Theme
            |--------------------------------------------------------------------------
            */

            topBar.classList.remove(
                'bg-rose-600',
                'bg-emerald-600'
            );

            topBar.classList.add(
                'bg-amber-500'
            );


            timerBox.classList.remove(
                'border-rose-200',
                'bg-rose-50',
                'border-emerald-200',
                'bg-emerald-50'
            );

            timerBox.classList.add(
                'border-amber-200',
                'bg-amber-50'
            );


            timerLabel.className =
                'text-xs font-bold uppercase tracking-wider text-amber-700';


            countdown.className =
                'mt-1 text-3xl font-black text-amber-800 tabular-nums';
        };


        /*
        |--------------------------------------------------------------------------
        | Start
        |--------------------------------------------------------------------------
        */

        update();

        countdownInterval =
            setInterval(
                update,
                1000
            );
    }

    function showNextReminder() {
        if (modalOpen || !isReminderPopupEnabled()) {
            return;
        }

        while (reminderQueue.length > 0) {
            const reminder = reminderQueue.shift();

            if (isTemporarilyHidden(reminder.id)) {
                continue;
            }

            const scheduledTime =
                new Date(reminder.scheduled_at).getTime();

            const diffMs = scheduledTime - Date.now();

            // Upcoming reminder only during the final 60 seconds.
            // Overdue pending reminder remains eligible.
            if (diffMs > 60 * 1000) {
                continue;
            }

            openModal(reminder);
            return;
        }
    }

    async function fetchReminders() {
        if (isFetching || !isReminderPopupEnabled()) {
            return;
        }

        isFetching = true;

        try {
            const response = await fetch(
                reminderUrl,
                {
                    method: 'GET',
                    credentials: 'same-origin',
                    headers: {
                        'Accept': 'application/json',
                        'X-Requested-With': 'XMLHttpRequest',
                    },
                }
            );

            if (response.status === 401 || response.status === 419) {
                return;
            }

            if (!response.ok) {
                console.error(
                    'Reminder API error:',
                    response.status
                );
                return;
            }

            const data = await response.json();

            if (
                !data.success
                || !Array.isArray(data.reminders)
            ) {
                return;
            }

            if (Array.isArray(data.dispositions)) {
                /*
                |--------------------------------------------------------------------------
                | Merge Reminder API Dispositions With Blade Preloaded Data
                |--------------------------------------------------------------------------
                | Reminder API purana payload return kare jisme auto_remarks aur
                | next_followup na ho, tab bhi preloaded values preserve rahengi.
                */
                const existingById = new Map(
                    callDispositions.map(item => [
                        String(item.id),
                        item
                    ])
                );

                callDispositions = data.dispositions.map(item => {
                    const existing =
                        existingById.get(String(item.id)) || {};

                    return {
                        ...existing,
                        ...item,

                        auto_remarks:
                            item.auto_remarks
                            ?? existing.auto_remarks
                            ?? null,

                        next_followup:
                            item.next_followup
                            ?? existing.next_followup
                            ?? null,
                    };
                });

                /*
                | API kisi active disposition ko omit kare to Blade-preloaded
                | record dropdown se disappear na ho.
                */
                const apiIds = new Set(
                    callDispositions.map(item =>
                        String(item.id)
                    )
                );

                existingById.forEach((item, id) => {
                    if (!apiIds.has(id)) {
                        callDispositions.push(item);
                    }
                });

                populatePopupDispositions();
            }

            const currentId = currentReminder
                ? Number(currentReminder.id)
                : null;

            const queuedIds = reminderQueue.map(
                item => Number(item.id)
            );

            data.reminders.forEach(reminder => {
                const id = Number(reminder.id);

                if (currentId === id) {
                    currentReminder = reminder;
                    return;
                }

                if (queuedIds.includes(id)) {
                    return;
                }

                if (
                    isTemporarilyHidden(id)
                ) {
                    return;
                }

                reminderQueue.push(reminder);
            });

            reminderQueue.sort((a, b) => {
                return new Date(a.scheduled_at).getTime()
                    - new Date(b.scheduled_at).getTime();
            });

            if (!modalOpen) {
                showNextReminder();
            }

        } catch (error) {
            console.error(
                'Unable to fetch follow-up reminders:',
                error
            );
        } finally {
            isFetching = false;
        }
    }

    async function postJson(url, payload = {}) {
        const response = await fetch(
            url,
            {
                method: 'POST',
                credentials: 'same-origin',
                headers: {
                    'Accept': 'application/json',
                    'Content-Type': 'application/json',
                    'X-CSRF-TOKEN': csrfToken,
                    'X-Requested-With': 'XMLHttpRequest',
                },
                body: JSON.stringify(payload),
            }
        );

        let data = {};

        try {
            data = await response.json();
        } catch (error) {
            data = {};
        }

        if (!response.ok) {
            let message =
                data.message
                || 'Request failed. Please try again.';

            if (data.errors) {
                const firstError = Object.values(data.errors)
                    .flat()
                    .find(Boolean);

                if (firstError) {
                    message = firstError;
                }
            }

            throw new Error(message);
        }

        return data;
    }

    async function savePopupCallResult(showSuccessMessage = false) {
        if (!popupCallForm) {
            return null;
        }

        if (!currentReminder) {
            throw new Error('Current follow-up reminder not available.');
        }

        if (!popupCallForm.action) {
            throw new Error('Call save URL not available for this lead.');
        }

        if (!popupCallForm.reportValidity()) {
            throw new Error('Please fill all required call result fields.');
        }

        /*
        |--------------------------------------------------------------------------
        | Duplicate Protection
        |--------------------------------------------------------------------------
        | Same popup form agar already successfully save ho chuka hai aur user ne
        | uske baad koi field change nahi ki, to dubara Call Log create nahi hoga.
        */
        if (popupCallResultSaved) {
            return {
                success: true,
                already_saved: true,
                message: 'Call result already saved.'
            };
        }

        const formData = new FormData(popupCallForm);

        const response = await fetch(
            popupCallForm.action,
            {
                method: 'POST',
                credentials: 'same-origin',
                headers: {
                    'Accept': 'application/json',
                    'X-CSRF-TOKEN': csrfToken,
                    'X-Requested-With': 'XMLHttpRequest',
                },
                body: formData,
            }
        );

        let data = {};
        const contentType = response.headers.get('content-type') || '';

        if (contentType.includes('application/json')) {
            try {
                data = await response.json();
            } catch (error) {
                data = {};
            }
        }

        if (!response.ok) {
            let message =
                data.message
                || 'Unable to save call result.';

            if (data.errors) {
                const firstError = Object.values(data.errors)
                    .flat()
                    .find(Boolean);

                if (firstError) {
                    message = firstError;
                }
            }

            throw new Error(message);
        }

        popupCallResultSaved = true;

        if (showSuccessMessage) {
            showActionMessage(
                data.message || 'Call result saved successfully.',
                true
            );
        }

        return data;
    }

    async function completeFollowUp() {
        if (!currentReminder) {
            return;
        }

        const reminder = currentReminder;

        clearActionMessage();

        completeButton.disabled = true;
        completeButton.textContent = 'Completing...';

        if (popupSaveCallButton) {
            popupSaveCallButton.disabled = true;
        }

        try {
            /*
            |--------------------------------------------------------------------------
            | STEP 1: Save Call Result
            |--------------------------------------------------------------------------
            | calls.create permission hone par popup form available hoga. Us case me
            | call result successfully save hone ke baad hi follow-up complete hoga.
            */
            if (popupCallForm) {
                await savePopupCallResult(false);
            }

            /*
            |--------------------------------------------------------------------------
            | STEP 2: Mark Current Follow-up Completed
            |--------------------------------------------------------------------------
            */
            const data = await postJson(
                reminder.complete_url,
                {}
            );

            clearTemporaryHide(reminder.id);
            clearDismissed(reminder.id);

            reminderQueue = reminderQueue.filter(
                item => Number(item.id) !== Number(reminder.id)
            );

            showActionMessage(
                data.message
                || (popupCallForm
                    ? 'Call result saved and follow-up completed successfully.'
                    : 'Follow-up completed successfully.'),
                true
            );

            setTimeout(function () {
                closeModal(true);
                fetchReminders();
                fetchSidebarNearestFollowUp();
            }, 700);

        } catch (error) {
            showActionMessage(
                error.message
                || 'Unable to save call result and complete follow-up.',
                false
            );
        } finally {
            completeButton.disabled = false;
            completeButton.textContent = 'Complete';

            if (popupSaveCallButton) {
                popupSaveCallButton.disabled = false;
            }
        }
    }

    async function snoozeFollowUp(minutes) {
        if (!currentReminder) {
            return;
        }

        const reminder = currentReminder;
        const buttons = document.querySelectorAll(
            '.followup-snooze-btn'
        );

        buttons.forEach(button => button.disabled = true);

        try {
            const data = await postJson(
                reminder.snooze_url,
                {
                    minutes: Number(minutes)
                }
            );

            clearTemporaryHide(reminder.id);
            clearDismissed(reminder.id);

            reminderQueue = reminderQueue.filter(
                item => Number(item.id) !== Number(reminder.id)
            );

            showActionMessage(
                data.message || 'Follow-up snoozed.',
                true
            );

            setTimeout(function () {
                closeModal(true);
                fetchReminders();
                fetchSidebarNearestFollowUp();
            }, 650);

        } catch (error) {
            showActionMessage(
                error.message || 'Something went wrong.',
                false
            );
        } finally {
            buttons.forEach(button => button.disabled = false);
        }
    }

    async function rescheduleFollowUp() {
        if (!currentReminder) {
            return;
        }

        const reminder = currentReminder;
        const newTime = rescheduleInput.value;

        if (popupNextFollowUp) {
            popupNextFollowUp.value = newTime || '';
        }

        if (!newTime) {
            showActionMessage(
                'Please select new date and time.',
                false
            );
            return;
        }

        rescheduleSave.disabled = true;
        rescheduleSave.textContent = 'Saving...';

        try {
            const data = await postJson(
                reminder.reschedule_url,
                {
                    scheduled_at: newTime
                }
            );

            clearTemporaryHide(reminder.id);
            clearDismissed(reminder.id);

            reminderQueue = reminderQueue.filter(
                item => Number(item.id) !== Number(reminder.id)
            );

            showActionMessage(
                data.message
                || 'Follow-up rescheduled successfully.',
                true
            );

            setTimeout(function () {
                closeModal(true);
                fetchReminders();
                fetchSidebarNearestFollowUp();
            }, 700);

        } catch (error) {
            showActionMessage(
                error.message || 'Unable to reschedule follow-up.',
                false
            );
        } finally {
            rescheduleSave.disabled = false;
            rescheduleSave.textContent = 'Save New Time';
        }
    }

    async function cancelFollowUp() {
        if (!currentReminder) {
            return;
        }

        const reminder = currentReminder;

        const confirmed = window.confirm(
            'Are you sure you want to cancel this follow-up?'
        );

        if (!confirmed) {
            return;
        }

        cancelButton.disabled = true;
        cancelButton.textContent = 'Cancelling...';

        try {
            const data = await postJson(
                reminder.cancel_url,
                {}
            );

            clearTemporaryHide(reminder.id);
            clearDismissed(reminder.id);

            reminderQueue = reminderQueue.filter(
                item => Number(item.id) !== Number(reminder.id)
            );

            showActionMessage(
                data.message
                || 'Follow-up cancelled successfully.',
                true
            );

            setTimeout(function () {
                closeModal(true);
                fetchReminders();
                fetchSidebarNearestFollowUp();
            }, 700);

        } catch (error) {
            showActionMessage(
                error.message || 'Unable to cancel follow-up.',
                false
            );
        } finally {
            cancelButton.disabled = false;
            cancelButton.textContent = '✕ Cancel Follow-up';
        }
    }

    function remindAgainInFiveMinutes() {
        if (!currentReminder) {
            return;
        }

        const id = currentReminder.id;

        hideTemporarily(id, 5);

        reminderQueue = reminderQueue.filter(
            item => Number(item.id) !== Number(id)
        );

        closeModal(true);
    }


    /*
    |--------------------------------------------------------------------------
    | Sidebar Nearest Follow-up Live Timer
    |--------------------------------------------------------------------------
    */

    function resetSidebarTimerClasses() {

        if (!sidebarNearestFollowup) {
            return;
        }

        sidebarNearestFollowup.classList.remove(
            'sidebar-followup-reminder',
            'border-red-400/50',
            'bg-red-500',
            'text-white',
            'border-amber-300/40',
            'bg-amber-400',
            'text-slate-950',
            'border-sky-300/40',
            'bg-sky-500'
        );
    }


    function formatSidebarDuration(totalSeconds) {

        totalSeconds = Math.max(
            0,
            Math.floor(totalSeconds)
        );

        const hours = Math.floor(totalSeconds / 3600);

        const minutes = Math.floor(
            (totalSeconds % 3600) / 60
        );

        const seconds = totalSeconds % 60;

        return String(hours).padStart(2, '0')
            + ':'
            + String(minutes).padStart(2, '0')
            + ':'
            + String(seconds).padStart(2, '0');
    }


    function updateSidebarFollowupTimer() {

        if (
            !sidebarNearestFollowup
            || !sidebarNearestFollowupText
        ) {
            return;
        }

        const scheduledTime =
            sidebarNearestFollowup.dataset.time;

        if (!scheduledTime) {

            sidebarNearestFollowup.classList.add(
                'hidden'
            );

            return;
        }

        const target =
            new Date(scheduledTime).getTime();

        if (Number.isNaN(target)) {

            sidebarNearestFollowup.classList.add(
                'hidden'
            );

            return;
        }

        sidebarNearestFollowup.classList.remove(
            'hidden'
        );

        const diffMs =
            target - Date.now();

        const absoluteSeconds =
            Math.floor(
                Math.abs(diffMs) / 1000
            );

        resetSidebarTimerClasses();


        /*
        |--------------------------------------------------------------------------
        | Overdue = Red + Blink
        |--------------------------------------------------------------------------
        */

        if (diffMs <= 0) {

            sidebarNearestFollowupText.textContent =
                'OVD '
                + formatSidebarDuration(
                    absoluteSeconds
                );

            sidebarNearestFollowup.classList.add(
                'sidebar-followup-reminder',
                'border-red-400/50',
                'bg-red-500',
                'text-white'
            );

            return;
        }


        /*
        |--------------------------------------------------------------------------
        | Upcoming Timer
        |--------------------------------------------------------------------------
        */

        sidebarNearestFollowupText.textContent =
            formatSidebarDuration(
                absoluteSeconds
            );


        /*
        |--------------------------------------------------------------------------
        | Last 10 Minutes = Red + Blink
        |--------------------------------------------------------------------------
        */

        if (
            diffMs <=
            (10 * 60 * 1000)
        ) {

            sidebarNearestFollowup.classList.add(
                'sidebar-followup-reminder',
                'border-red-400/50',
                'bg-red-500',
                'text-white'
            );

            return;
        }


        /*
        |--------------------------------------------------------------------------
        | 10 - 30 Minutes = Amber
        |--------------------------------------------------------------------------
        */

        if (
            diffMs <=
            (30 * 60 * 1000)
        ) {

            sidebarNearestFollowup.classList.add(
                'border-amber-300/40',
                'bg-amber-400',
                'text-slate-950'
            );

            return;
        }


        /*
        |--------------------------------------------------------------------------
        | More Than 30 Minutes = Blue
        |--------------------------------------------------------------------------
        */

        sidebarNearestFollowup.classList.add(
            'border-sky-300/40',
            'bg-sky-500',
            'text-white'
        );
    }


    async function fetchSidebarNearestFollowUp() {

        if (!sidebarNearestFollowup) {
            return;
        }

        try {

            const response =
                await fetch(
                    sidebarNearestUrl,
                    {
                        method: 'GET',

                        credentials:
                            'same-origin',

                        headers: {
                            'Accept':
                                'application/json',

                            'X-Requested-With':
                                'XMLHttpRequest',
                        },
                    }
                );

            if (
                response.status === 401
                || response.status === 419
            ) {
                return;
            }

            if (!response.ok) {
                return;
            }

            const data =
                await response.json();

            if (
                !data.success
                || !data.followup
            ) {

                sidebarNearestFollowup.dataset.time = '';

                sidebarNearestFollowup.classList.add(
                    'hidden'
                );

                return;
            }

            sidebarNearestFollowup.dataset.time =
                data.followup.scheduled_at;

            sidebarNearestFollowup.classList.remove(
                'hidden'
            );

            updateSidebarFollowupTimer();

        } catch (error) {

            console.error(
                'Unable to fetch nearest sidebar follow-up:',
                error
            );
        }
    }


    callButton?.addEventListener('click', function () {
        startCallDuration();
    });

    function getReminderLeadId(reminder) {
        if (!reminder) return null;

        // Best case: reminder API directly sends lead_id.
        if (reminder.lead_id) {
            return String(reminder.lead_id);
        }

        // Some APIs may return nested lead object.
        if (reminder.lead && reminder.lead.id) {
            return String(reminder.lead.id);
        }

        /*
        |--------------------------------------------------------------------------
        | Fallback: extract lead id from URLs already returned by reminder API
        |--------------------------------------------------------------------------
        | Examples:
        | /leads/25
        | /leads/25/calls
        */
        const candidates = [
            reminder.lead_url,
            reminder.call_store_url,
        ].filter(Boolean);

        for (const url of candidates) {
            const value = String(url);

            const match =
                value.match(/\/leads\/(\d+)(?:\/|$|\?)/i)
                || value.match(/\/lead\/(\d+)(?:\/|$|\?)/i);

            if (match && match[1]) {
                return match[1];
            }
        }

        return null;
    }

    function buildDemoSendUpdateUrl(reminder) {
        const leadId = getReminderLeadId(reminder);

        if (!leadId) {
            return '';
        }

        return demoSendUpdateUrlTemplate.replace(
            '__LEAD_ID__',
            encodeURIComponent(leadId)
        );
    }

    function setDemoButtonState(marked) {
        if (!sendDemoButton) return;

        if (marked) {
            sendDemoButton.classList.remove(
                'border-emerald-200',
                'bg-emerald-50',
                'text-emerald-700',
                'hover:bg-emerald-100'
            );

            sendDemoButton.classList.add(
                'border-emerald-300',
                'bg-emerald-600',
                'text-white'
            );

            sendDemoButton.innerHTML =
                '<i data-lucide="circle-check" class="h-5 w-5"></i> Demo Sent';

            if (window.lucide) {
                window.lucide.createIcons();
            }
        } else {
            sendDemoButton.classList.remove(
                'border-emerald-300',
                'bg-emerald-600',
                'text-white'
            );

            sendDemoButton.classList.add(
                'border-emerald-200',
                'bg-emerald-50',
                'text-emerald-700',
                'hover:bg-emerald-100'
            );

            sendDemoButton.innerHTML =
                '<i data-lucide="circle-play" class="h-5 w-5"></i> Send Demo';

            if (window.lucide) {
                window.lucide.createIcons();
            }
        }
    }

    async function markCurrentLeadDemoSent() {
        if (!currentReminder || !sendDemoButton) {
            return;
        }

        const updateUrl = buildDemoSendUpdateUrl(currentReminder);

        if (!updateUrl) {
            showActionMessage(
                'Lead ID not available. Reminder API me lead_id bhejna zaroori hai.',
                false
            );
            return;
        }

        const oldHtml = sendDemoButton.innerHTML;

        sendDemoButton.disabled = true;
        sendDemoButton.innerHTML =
            '<span class="inline-flex items-center gap-2">Saving...</span>';

        clearActionMessage();

        try {
            const formData = new FormData();

            /*
            |--------------------------------------------------------------------------
            | SAME DATA AS LEAD DETAILS "Demo Send" FORM
            |--------------------------------------------------------------------------
            */
            formData.append('_method', 'PATCH');
            formData.append('demo_send_only', '1');
            formData.append('demo_send', '1');

            const response = await fetch(
                updateUrl,
                {
                    method: 'POST',
                    credentials: 'same-origin',
                    headers: {
                        'Accept': 'application/json',
                        'X-CSRF-TOKEN': csrfToken,
                        'X-Requested-With': 'XMLHttpRequest',
                    },
                    body: formData,
                }
            );

            let data = {};

            const contentType =
                response.headers.get('content-type') || '';

            if (contentType.includes('application/json')) {
                try {
                    data = await response.json();
                } catch (e) {
                    data = {};
                }
            }

            if (!response.ok) {
                let message =
                    data.message
                    || 'Unable to mark demo as sent.';

                if (data.errors) {
                    const firstError = Object.values(data.errors)
                        .flat()
                        .find(Boolean);

                    if (firstError) {
                        message = firstError;
                    }
                }

                throw new Error(message);
            }

            // Keep popup state updated even if reminder API does not return demo_send.
            currentReminder.demo_send = true;

            setDemoButtonState(true);

            showActionMessage(
                data.message || 'Demo Send marked successfully.',
                true
            );

        } catch (error) {
            sendDemoButton.innerHTML = oldHtml;

            if (window.lucide) {
                window.lucide.createIcons();
            }

            showActionMessage(
                error.message || 'Unable to mark demo as sent.',
                false
            );
        } finally {
            sendDemoButton.disabled = false;
        }
    }

    sendDemoButton?.addEventListener(
        'click',
        markCurrentLeadDemoSent
    );

    completeButton?.addEventListener(
        'click',
        completeFollowUp
    );

    closeButton?.addEventListener(
        'click',
        closeCurrentReminder
    );

    remindFiveButton?.addEventListener(
        'click',
        remindAgainInFiveMinutes
    );

    cancelButton?.addEventListener(
        'click',
        cancelFollowUp
    );

    rescheduleToggle.addEventListener(
        'click',
        function () {
            reschedulePanel.classList.toggle('hidden');

            if (!reschedulePanel.classList.contains('hidden')) {
                rescheduleInput.min = minimumDatetimeLocalValue();

                if (currentReminder) {
                    rescheduleInput.value = toDatetimeLocalValue(
                        currentReminder.scheduled_at
                    );

                    if (popupNextFollowUp) {
                        popupNextFollowUp.value = rescheduleInput.value;
                    }
                }

                rescheduleInput.focus();
            }
        }
    );

    rescheduleClose.addEventListener(
        'click',
        function () {
            reschedulePanel.classList.add('hidden');
        }
    );

    rescheduleSave.addEventListener(
        'click',
        rescheduleFollowUp
    );

    document
        .querySelectorAll('.followup-snooze-btn')
        .forEach(button => {
            button.addEventListener(
                'click',
                function () {
                    const minutes = Number(
                        this.dataset.snooze
                    );

                    snoozeFollowUp(minutes);
                }
            );
        });

    reminderEnabledToggle?.addEventListener(
        'change',
        function () {
            localStorage.setItem(
                reminderPreferenceKey,
                this.checked ? '1' : '0'
            );

            syncReminderPreferenceUi();

            if (!this.checked) {
                disableReminderPopupNow();
                return;
            }

            fetchReminders();
        }
    );

    popupDisposition?.addEventListener(
        'change',
        updatePopupDispositionFields
    );

    popupCallForm?.addEventListener(
        'submit',
        async function (event) {
            event.preventDefault();

            if (!currentReminder || !this.action) {
                showActionMessage(
                    'Call save URL not available for this lead.',
                    false
                );
                return;
            }

            if (!this.reportValidity()) {
                return;
            }

            if (popupSaveCallButton) {
                popupSaveCallButton.disabled = true;
                popupSaveCallButton.textContent = 'Saving Feedback...';
            }

            try {
                await savePopupCallResult(false);

                /*
                |--------------------------------------------------------------------------
                | Save Feedback Success
                |--------------------------------------------------------------------------
                | Feedback existing backend flow se save ho chuka hai.
                | Follow-up ko complete/cancel nahi karna hai.
                | Sirf current popup close karke reminder queue continue karni hai.
                */
                const savedReminderId = currentReminder
                    ? Number(currentReminder.id)
                    : null;

                if (savedReminderId !== null) {
                    reminderQueue = reminderQueue.filter(
                        item => Number(item.id) !== savedReminderId
                    );

                    // Same reminder turant dobara popup na ho.
                    hideTemporarily(savedReminderId, 1);
                }

                closeModal(true);

                // Fresh reminder/nearest timer state sync.
                fetchReminders();
                fetchSidebarNearestFollowUp();

            } catch (error) {
                showActionMessage(
                    error.message || 'Unable to save call result.',
                    false
                );
            } finally {
                if (popupSaveCallButton) {
                    popupSaveCallButton.disabled = false;
                    popupSaveCallButton.textContent = popupCallResultSaved
                        ? '✓ Feedback Saved'
                        : 'Save Feedback';
                }
            }
        }
    );

    /*
    |--------------------------------------------------------------------------
    | Form Change = Unsaved Again
    |--------------------------------------------------------------------------
    | User call result save karne ke baad koi disposition/duration/remarks/date
    | change karta hai to next save ko naya/updated submission maana jayega.
    */
    popupCallForm?.addEventListener(
        'input',
        function () {
            if (!popupCallResultSaved) {
                return;
            }

            popupCallResultSaved = false;

            if (popupSaveCallButton) {
                popupSaveCallButton.textContent = '✓ Save Call Result';
            }
        }
    );

    popupCallForm?.addEventListener(
        'change',
        function () {
            if (!popupCallResultSaved) {
                return;
            }

            popupCallResultSaved = false;

            if (popupSaveCallButton) {
                popupSaveCallButton.textContent = '✓ Save Call Result';
            }
        }
    );

    syncReminderPreferenceUi();
    requestNotificationPermission();

    fetchReminders();
    fetchSidebarNearestFollowUp();
    updateSidebarFollowupTimer();

    setInterval(
        fetchReminders,
        10000
    );

    setInterval(
        fetchSidebarNearestFollowUp,
        30000
    );

    setInterval(
        updateSidebarFollowupTimer,
        1000
    );

    document.addEventListener(
        'visibilitychange',
        function () {
            if (document.visibilityState === 'visible') {
                fetchReminders();
                fetchSidebarNearestFollowUp();
            }
        }
    );

    window.addEventListener(
        'focus',
        function () {
            fetchReminders();
            fetchSidebarNearestFollowUp();
        }
    );
});

</script>

</body>
</html>
