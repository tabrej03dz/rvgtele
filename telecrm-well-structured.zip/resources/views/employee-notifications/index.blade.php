@extends('layouts.crm')

@section('title', 'Employee Notifications')

@section('content')
    <form method="POST"
        action="{{ route('employee-notifications.store') }}"
        enctype="multipart/form-data"
        class="mx-auto max-w-2xl space-y-4 rounded-xl border bg-white p-5">
        @csrf

        <h1 class="text-xl font-bold">Employee Notifications</h1>

        <div>
            <label for="recipient" class="block font-medium">Send to</label>

            <select id="recipient" name="recipient" required
                class="mt-1 w-full rounded-lg border p-2">
                <option value="">Select recipients</option>
                <option value="all" @selected(old('recipient') === 'all')>
                    All Employees
                </option>

                @foreach ($employees as $employee)
                    <option value="{{ $employee->id }}"
                        @selected((string) old('recipient') === (string) $employee->id)>
                        {{ $employee->name }} · {{ $employee->employee_code ?: '#' . $employee->id }}
                    </option>
                @endforeach
            </select>
        </div>

        <div>
            <label for="message" class="block font-medium">Message</label>

            <textarea id="message" name="message" rows="5" maxlength="600"
                class="mt-1 w-full rounded-lg border p-2">{{ old('message') }}</textarea>
        </div>

        <div>
            <label for="image" class="block font-medium">Image · up to 10 MB</label>
            <input id="image" name="image" type="file"
                accept="image/jpeg,image/png,image/webp">
        </div>

        <div>
            <label for="video" class="block font-medium">MP4 video · up to 20 MB</label>
            <input id="video" name="video" type="file" accept="video/mp4">
        </div>

        <button type="submit"
            class="rounded-lg bg-indigo-600 px-4 py-2 font-semibold text-white">
            Send Notification
        </button>
    </form>
@endsection