<?php

namespace App\Http\Controllers;

use App\Jobs\SendEmployeePush;
use App\Models\DeviceToken;
use App\Models\User;
use Illuminate\Database\Eloquent\Builder;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\RedirectResponse;
use Illuminate\Http\Request;
use Illuminate\Support\Collection;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Queue;
use Illuminate\Support\Facades\Storage;
use Illuminate\Validation\ValidationException;
use Illuminate\View\View;
use RuntimeException;
use Symfony\Component\HttpFoundation\BinaryFileResponse;
use Throwable;
use App\Services\FirebasePushService;

class EmployeePushController extends Controller
{

    private const HISTORY_PER_PAGE = 10;
    public function index(): View
    {
        $history = DB::table('employee_push_notifications as n')
            ->select('n.*')
            ->selectSub(
                DB::table('employee_push_recipients as r')
                    ->selectRaw('count(*)')
                    ->whereColumn('r.notification_id', 'n.id'),
                'participant_count',
            )
            ->orderByDesc('n.id')
            ->paginate(self::HISTORY_PER_PAGE);

        return view('employee-notifications.index', [
            'history' => $history,
            'editing' => null,
            'selectedIds' => [],
            'employees' => $this->employeeOptions(),
        ]);
    }

    public function details(int $notification): View
    {
        $item = $this->record($notification);

        $participants = DB::table('employee_push_recipients as r')
            ->join('users as u', 'u.id', '=', 'r.user_id')
            ->where('r.notification_id', $notification)
            ->orderBy('u.name')
            ->orderBy('u.id')
            ->paginate(25, ['u.id', 'u.name', 'u.employee_code']);

        return view('employee-notifications.details', compact('item', 'participants'));
    }

    public function edit(int $notification): View
    {
        $editing = $this->record($notification);

        $selectedIds = DB::table('employee_push_recipients')
            ->where('notification_id', $notification)
            ->pluck('user_id')
            ->all();

        return view('employee-notifications.index', [
            'history' => null,
            'editing' => $editing,
            'selectedIds' => $selectedIds,
            'employees' => $this->employeeOptions(),
        ]);
    }

    public function store(Request $request): RedirectResponse
    {
        return $this->publish($request);
    }

    public function resend(Request $request, int $notification): RedirectResponse
    {
        return $this->publish($request, $this->record($notification));
    }

    private function publish(Request $request, ?object $source = null): RedirectResponse
    {
        $request->mergeIfMissing([
            'audience' => $request->input('recipient_ids', []) === []
                ? 'all'
                : 'selected',
        ]);
        $data = $request->validate([
            'audience' => ['required', 'in:all,selected'],
            'recipient_ids' => [
                'exclude_unless:audience,selected',
                'required',
                'array',
                'min:1',
            ],
            'recipient_ids.*' => ['required', 'integer', 'min:1', 'distinct'],
            'message' => ['nullable', 'string', 'max:600'],
            'image' => ['nullable', 'file', 'mimes:jpg,jpeg,png,webp', 'max:10240'],
            'video' => ['nullable', 'file', 'mimes:mp4', 'max:20480'],
            'remove_image' => ['sometimes', 'boolean'],
            'remove_video' => ['sometimes', 'boolean'],
        ]);

        $employees = $this->employees();
        $requestedIds = $data['recipient_ids'] ?? [];

        if ($data['audience'] === 'selected') {
            $employees->whereIn('users.id', $requestedIds);
        }

        $message = $data['message'] ?? '';
        $attachments = [
            'image' => $source?->image_path,
            'video' => $source?->video_path,
        ];
        $newFiles = [];

        try {
            foreach (['image', 'video'] as $kind) {
                if ($request->hasFile($kind)) {
                    $path = $request->file($kind)
                        ->store('employee-notifications', 'local');

                    if (!$path) {
                        throw new RuntimeException("Could not save the {$kind}.");
                    }

                    $newFiles[] = $path;
                    $attachments[$kind] = $path;
                } elseif ($request->boolean('remove_' . $kind)) {
                    $attachments[$kind] = null;
                }
            }

            if ($message === '' && !$attachments['image'] && !$attachments['video']) {
                throw ValidationException::withMessages([
                    'message' => 'Enter a message or attach an image or video.',
                ]);
            }

            [$id, $participantCount] = DB::transaction(function () use (
                $request,
                $source,
                $message,
                $attachments,
                $employees,
                $requestedIds,
                $data,
            ): array {
                $now = now();

                $id = DB::table('employee_push_notifications')->insertGetId([
                    'created_by' => $request->user()->id,
                    'resent_from_id' => $source?->id,
                    'message' => $message,
                    'image_path' => $attachments['image'],
                    'video_path' => $attachments['video'],
                    'created_at' => $now,
                    'updated_at' => $now,
                ]);

                $participantCount = DB::table('employee_push_recipients')->insertUsing(
                    ['notification_id', 'user_id'],
                    $employees
                        ->selectRaw('? as notification_id, users.id as user_id', [$id])
                        ->toBase(),
                );

                if (
                    $participantCount === 0 ||
                    ($data['audience'] === 'selected' && $participantCount !== count($requestedIds))
                ) {
                    throw ValidationException::withMessages([
                        'recipient_ids' => 'Select eligible employees. One or more selected employees are unavailable.',
                    ]);
                }

                return [$id, $participantCount];
            });
        } catch (Throwable $exception) {
            if ($newFiles !== []) {
                Storage::disk('local')->delete($newFiles);
            }

            throw $exception;
        }

       $delivery = $this->sendPushesDirectly($id, $message, $attachments);

        if ($delivery['devices'] === 0) {
            return redirect()
                ->route('employee-notifications.index')
                ->with(
                    'error',
                    "Notification #{$id} saved for {$participantCount} employee(s). No registered Android or iOS devices were found."
                );
        }

        $notice = "Notification #{$id} saved for {$participantCount} employee(s). "
            . "Firebase accepted {$delivery['accepted']} of {$delivery['devices']} device send(s). "
            . "Failed: {$delivery['failed']}.";

        return redirect()
            ->route('employee-notifications.index')
            ->with($delivery['failed'] > 0 ? 'error' : 'success', $notice);
    }

private function sendPushesDirectly(
    int $notificationId,
    string $message,
    array $attachments,
): array {
    $firebase = app(FirebasePushService::class);

    $body = $message !== '' ? $message : match (true) {
        filled($attachments['image'] ?? null) && filled($attachments['video'] ?? null) =>
            'New image and video. Tap to open.',
        filled($attachments['video'] ?? null) => 'New video. Tap to open.',
        default => 'New image. Tap to open.',
    };

    $delivery = [
        'devices' => 0,
        'accepted' => 0,
        'failed' => 0,
    ];

    DeviceToken::query()
        ->whereIn('user_id', DB::table('employee_push_recipients')
            ->where('notification_id', $notificationId)
            ->select('user_id'))
        ->whereIn('platform', ['android', 'ios'])
        ->whereNotNull('token')
        ->where('token', '<>', '')
        ->select(['id', 'token'])
        ->chunkById(100, function (Collection $devices) use (
            $firebase,
            $notificationId,
            $body,
            &$delivery,
        ): void {
            foreach ($devices as $device) {
                $delivery['devices']++;

                $result = $firebase->sendToToken(
                    deviceToken: $device->token,
                    title: 'TeleCRM',
                    body: $body,
                    data: [
                        'type' => 'employee_notification',
                        'notification_id' => (string) $notificationId,
                    ],
                    androidChannel: 'employee_notifications',
                    androidClickAction: null,
                );

                if ($result['success'] ?? false) {
                    $delivery['accepted']++;
                } else {
                    $delivery['failed']++;
                }
            }
        });

    return $delivery;
}

public function inbox(Request $request): JsonResponse
{
    $notifications = DB::table('employee_push_recipients as r')
        ->join('employee_push_notifications as n', 'n.id', '=', 'r.notification_id')
        ->where('r.user_id', $request->user()->id)
        ->orderByDesc('n.id')
        ->paginate(20, [
            'n.id',
            'n.message',
            'n.created_at',
            'n.updated_at',
            'n.image_path',
            'n.video_path',
        ])
        ->through(function (object $item): array {
            $hasImage = filled($item->image_path);
            $hasVideo = filled($item->video_path);
            $detailUrl = url("/api/employee-notifications/{$item->id}");

            return [
                'id' => (int) $item->id,
                'message' => $item->message,
                'created_at' => $item->created_at,
                'updated_at' => $item->updated_at,
                'has_image' => $hasImage,
                'has_video' => $hasVideo,
                'image_url' => $hasImage ? "{$detailUrl}/image" : null,
                'video_url' => $hasVideo ? "{$detailUrl}/video" : null,
            ];
        });

    return response()->json([
        'status' => true,
        'data' => $notifications->items(),
        'pagination' => [
            'current_page' => $notifications->currentPage(),
            'last_page' => $notifications->lastPage(),
            'per_page' => $notifications->perPage(),
            'total' => $notifications->total(),
            'next_page' => $notifications->hasMorePages()
                ? $notifications->currentPage() + 1
                : null,
        ],
    ])->header('Cache-Control', 'private, no-store');
}

    public function show(Request $request, int $notification): JsonResponse
    {
        $item = $this->notificationFor($request, $notification);

        return response()->json([
            'id' => $item->id,
            'message' => $item->message,
            'created_at' => $item->created_at,
            'has_image' => $item->image_path !== null,
            'has_video' => $item->video_path !== null,
            'image_url' => $item->image_path
                ? route('api.employee-notifications.attachment', [
                    'notification' => $item->id,
                    'kind' => 'image',
                ])
                : null,
            'video_url' => $item->video_path
                ? route('api.employee-notifications.attachment', [
                    'notification' => $item->id,
                    'kind' => 'video',
                ])
                : null,
        ])->header('Cache-Control', 'private, no-store');
    }

    public function attachment(
        Request $request,
        int $notification,
        string $kind,
    ): BinaryFileResponse {
        $item = $this->notificationFor($request, $notification);
        $path = $kind === 'image' ? $item->image_path : $item->video_path;
        $disk = Storage::disk('local');

        abort_unless($path && $disk->exists($path), 404);

        return response()->file($disk->path($path), [
            'Content-Type' => $kind === 'video'
                ? 'video/mp4'
                : ($disk->mimeType($path) ?: 'application/octet-stream'),
            'Cache-Control' => 'private, no-store',
            'X-Content-Type-Options' => 'nosniff',
        ])->setPrivate();
    }

    private function notificationFor(Request $request, int $id): object
    {
        $item = DB::table('employee_push_notifications as n')
            ->join('employee_push_recipients as r', 'r.notification_id', '=', 'n.id')
            ->where('n.id', $id)
            ->where('r.user_id', $request->user()->id)
            ->first(['n.id', 'n.message', 'n.image_path', 'n.video_path', 'n.created_at']);

        abort_if($item === null, 404);

        return $item;
    }

    private function record(int $id): object
    {
        $item = DB::table('employee_push_notifications')->where('id', $id)->first();

        abort_if($item === null, 404);

        return $item;
    }

    private function employeeOptions(): Collection
    {
        return $this->employees()
            ->orderBy('users.name')
            ->orderBy('users.id')
            ->get(['users.id', 'users.name', 'users.employee_code']);
    }

    private function employees(): Builder
    {
        return User::query()
            ->whereNotNull('users.company_id')
            ->whereHas('roles', fn (Builder $roles) => $roles->whereIn('name', [
                'employee',
                'telecaller',
                'sales_executive',
                'field_sales_executive',
                'quality_analyst',
                'customer_support',
                'accounts_user',
                'team_leader',
                'sales_manager',
                'branch_manager',
            ]));
    }

public function destroy(Request $request, int $notification): RedirectResponse
{
    $paths = DB::transaction(function () use ($notification): array {
        $item = DB::table('employee_push_notifications')
            ->where('id', $notification)
            ->lockForUpdate()
            ->first(['id', 'image_path', 'video_path']);

        abort_if($item === null, 404, 'Notification not found.');

        DB::table('employee_push_notifications')
            ->where('id', $notification)
            ->delete();

        return array_unique(array_filter([
            $item->image_path,
            $item->video_path,
        ]));
    });

    $disk = Storage::disk('local');
    $failedFiles = 0;

    foreach ($paths as $path) {
        $stillUsed = DB::table('employee_push_notifications')
            ->where('image_path', $path)
            ->orWhere('video_path', $path)
            ->exists();

        if ($stillUsed) {
            continue;
        }

        try {
            if ($disk->delete($path)) {
                continue;
            }
        } catch (\Throwable $exception) {
            report($exception);
        }

        $failedFiles++;

        logger()->warning('Could not delete employee notification attachment.', [
            'notification_id' => $notification,
            'path' => $path,
        ]);
    }

    $requestedPage = max(1, $request->integer('history_page', 1));
    $total = DB::table('employee_push_notifications')->count();
    $lastPage = max(1, (int) ceil($total / self::HISTORY_PER_PAGE));

    $url = route('employee-notifications.index', [
        'page' => min($requestedPage, $lastPage),
    ]) . '#notification-history';

    if ($failedFiles > 0) {
        return redirect()->to($url)->with(
            'error',
            "Notification #{$notification} deleted, but {$failedFiles} attachment file(s) could not be removed. Check Laravel logs."
        );
    }

    return redirect()->to($url)
        ->with('success', "Notification #{$notification} deleted successfully.");
}
}