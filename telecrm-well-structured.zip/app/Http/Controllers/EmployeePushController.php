<?php

namespace App\Http\Controllers;

use App\Jobs\SendEmployeePush;
use App\Models\DeviceToken;
use App\Models\User;
use Illuminate\Database\Eloquent\Builder;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\RedirectResponse;
use Illuminate\Http\Request;
use Illuminate\Support\Collection;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Queue;
use Illuminate\Support\Facades\Storage;
use Illuminate\Validation\ValidationException;
use Illuminate\View\View;
use RuntimeException;
use Symfony\Component\HttpFoundation\BinaryFileResponse;
use Throwable;

class EmployeePushController extends Controller
{
    private function employees(): Builder
    {
        return User::query()
            ->whereNotNull('users.company_id')
            ->whereHas('roles', fn (Builder $roles) => $roles->whereIn('name', [
                'employee',
                'telecaller',
                'sales_executive',
                'field_sales_executive',
                'quality_analyst',
                'customer_support',
                'accounts_user',
                'team_leader',
                'sales_manager',
                'branch_manager',
            ]));
    }

    public function index(): View
    {
        $employees = $this->employees()
            ->orderBy('users.name')
            ->get(['users.id', 'users.name', 'users.employee_code']);

        return view('employee-notifications.index', compact('employees'));
    }

    public function store(Request $request): RedirectResponse
    {
        $data = $request->validate([
            'recipient' => ['required', 'string', 'regex:/\A(?:all|[1-9][0-9]{0,18})\z/'],
            'message' => ['nullable', 'required_without_all:image,video', 'string', 'max:600'],
            'image' => ['nullable', 'file', 'mimes:jpg,jpeg,png,webp', 'max:10240'],
            'video' => ['nullable', 'file', 'mimes:mp4', 'max:20480'],
        ]);

        $employees = $this->employees();

        if ($data['recipient'] !== 'all') {
            $employees->where('users.id', $data['recipient']);
        }

        $paths = [];

        try {
            foreach (['image', 'video'] as $kind) {
                if (!$request->hasFile($kind)) {
                    continue;
                }

                $path = $request->file($kind)->store('employee-notifications', 'local');

                if (!$path) {
                    throw new RuntimeException("Could not save the {$kind}.");
                }

                $paths[$kind] = $path;
            }

            $queued = DB::transaction(function () use ($request, $data, $employees, $paths): int {
                $now = now();

                $id = DB::table('employee_push_notifications')->insertGetId([
                    'created_by' => $request->user()->id,
                    'message' => $data['message'] ?? '',
                    'image_path' => $paths['image'] ?? null,
                    'video_path' => $paths['video'] ?? null,
                    'created_at' => $now,
                    'updated_at' => $now,
                ]);

                $recipients = $employees
                    ->selectRaw('? as notification_id, users.id as user_id', [$id])
                    ->toBase();

                $recipientCount = DB::table('employee_push_recipients')->insertUsing(
                    ['notification_id', 'user_id'],
                    $recipients,
                );

                if ($recipientCount === 0) {
                    throw ValidationException::withMessages([
                        'recipient' => 'No eligible employee was found.',
                    ]);
                }

                $queue = Queue::connection('database');
                $queued = 0;

                DeviceToken::query()
                    ->whereIn('user_id', DB::table('employee_push_recipients')
                        ->where('notification_id', $id)
                        ->select('user_id'))
                    ->whereIn('platform', ['android', 'ios'])
                    ->where('token', '<>', '')
                    ->select(['id', 'user_id'])
                    ->chunkById(250, function (Collection $devices) use ($id, $queue, &$queued): void {
                        $jobs = $devices->map(fn (DeviceToken $device) => new SendEmployeePush(
                            notificationId: $id,
                            deviceId: $device->id,
                            userId: $device->user_id,
                        ));

                        $queue->bulk($jobs->all(), '', 'broadcasts');
                        $queued += $jobs->count();
                    });

                return $queued;
            });
        } catch (Throwable $exception) {
            if ($paths !== []) {
                Storage::disk('local')->delete(array_values($paths));
            }

            throw $exception;
        }

        $notice = $queued > 0
            ? "Notification queued for {$queued} mobile device(s)."
            : 'Notification saved. No registered mobile devices were found for the selected recipients.';

        return redirect()->route('employee-notifications.index')->with('success', $notice);
    }

    public function show(Request $request, int $notification): JsonResponse
    {
        $item = $this->notificationFor($request, $notification);

        return response()->json([
            'id' => $item->id,
            'message' => $item->message,
            'has_image' => $item->image_path !== null,
            'has_video' => $item->video_path !== null,
        ])->header('Cache-Control', 'private, no-store');
    }

    public function attachment(
        Request $request,
        int $notification,
        string $kind,
    ): BinaryFileResponse {
        $item = $this->notificationFor($request, $notification);
        $path = $kind === 'image' ? $item->image_path : $item->video_path;
        $disk = Storage::disk('local');

        abort_unless($path && $disk->exists($path), 404);

        return response()->file($disk->path($path), [
            'Content-Type' => $kind === 'video'
                ? 'video/mp4'
                : ($disk->mimeType($path) ?: 'application/octet-stream'),
            'Cache-Control' => 'private, no-store',
            'X-Content-Type-Options' => 'nosniff',
        ])->setPrivate();
    }

    private function notificationFor(Request $request, int $id): object
    {
        $item = DB::table('employee_push_notifications as n')
            ->join('employee_push_recipients as r', 'r.notification_id', '=', 'n.id')
            ->where('n.id', $id)
            ->where('r.user_id', $request->user()->id)
            ->first(['n.id', 'n.message', 'n.image_path', 'n.video_path']);

        abort_if($item === null, 404);

        return $item;
    }
}