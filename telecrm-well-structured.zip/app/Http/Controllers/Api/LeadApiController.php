<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use App\Models\CallDisposition;
use App\Models\Lead;
use App\Models\LeadAssignment;
use App\Models\LeadLabel;
use App\Models\LeadSource;
use App\Models\LeadStatus;
use App\Models\Note;
use App\Models\Pipeline;
use App\Models\PipelineStage;
use App\Models\Team;
use App\Models\User;
use Illuminate\Database\Eloquent\Builder;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Validation\Rule;
use App\Services\MobileCallService;
use Throwable;
use App\Models\CallLog;
use App\Models\FollowUp;
use Illuminate\Support\Facades\Schema;


class LeadApiController extends Controller
{



public function callOnMobile(
    Request $request,
    Lead $lead,
    MobileCallService $mobileCallService
): JsonResponse {

    $user = $request->user();

    /*
    |--------------------------------------------------------------------------
    | Company Security
    |--------------------------------------------------------------------------
    */

    if (
        isset($user->company_id) &&
        isset($lead->company_id) &&
        (int) $user->company_id !== (int) $lead->company_id
    ) {
        return response()->json([
            'status' => false,
            'message' => 'You are not allowed to access this lead.',
        ], 403);
    }

    /*
    |--------------------------------------------------------------------------
    | Employee Lead Security
    |--------------------------------------------------------------------------
    |
    | Normal employee ko doosre employee ki lead par call nahi karne dena.
    |
    | Agar aapke LeadApiController me already guard/access method hai,
    | to ye block hata kar wahi guard use karna better hai.
    |
    */

    $hasFullAccess = $user->hasAnyRole([
        'super_admin',
        'admin',
    ]);

    if (
        !$hasFullAccess &&
        (int) $lead->assigned_to !== (int) $user->id
    ) {
        return response()->json([
            'status' => false,
            'message' => 'This lead is not assigned to you.',
        ], 403);
    }

    /*
    |--------------------------------------------------------------------------
    | Mobile Number
    |--------------------------------------------------------------------------
    */

    if (blank($lead->mobile)) {
        return response()->json([
            'status' => false,
            'message' => 'Lead mobile number is missing.',
        ], 422);
    }

    try {

        $result = $mobileCallService->send(
            $user,
            $lead
        );

        return response()->json([
            'status' => true,

            'message' =>
                'Call command sent to your mobile app.',

            'data' => [
                'lead_id' => $lead->id,
                'lead_name' => $lead->name,
                'mobile' => $lead->mobile,
                'device' => $result,
            ],
        ]);

    } catch (Throwable $e) {

        report($e);

        return response()->json([
            'status' => false,
            'message' => $e->getMessage(),
        ], 422);
    }
}

    private array $fullAccessRoles = ['super_admin', 'admin'];

    public function indexOld(Request $request): JsonResponse
    {
        $validated = $request->validate([
            'search' => ['nullable', 'string', 'max:255'],
            'status' => ['nullable', 'integer'],
            'source' => ['nullable', 'integer'],
            'category' => ['nullable', 'string', 'max:255'],
            'assigned_to' => ['nullable', 'string'],
            'team_id' => ['nullable', 'integer'],
            'priority' => ['nullable', Rule::in(['low', 'normal', 'high', 'urgent', 'hot'])],
            'temperature' => ['nullable', Rule::in(['cold', 'warm', 'hot'])],
            'call_disposition' => ['nullable', 'string'],
            'label_id' => ['nullable', 'integer'],
            'demo_send' => ['nullable', 'boolean'],
            'lead_send' => ['nullable', Rule::in(['today', 'all'])],
            'created_filter' => ['nullable', Rule::in(['today'])],
            'date_from' => ['nullable', 'date'],
            'date_to' => ['nullable', 'date', 'after_or_equal:date_from'],
            'per_page' => ['nullable', 'integer', Rule::in([10, 25, 50, 100, 200])],
        ]);

        $leads = $this->filteredLeadQuery($request)
            ->with([
                'assignedUser:id,name,email,employee_code,team_id',
                'source:id,name',
                'status:id,name,color',
                'team:id,name',
                'stage:id,name,color',
                'labels:id,company_id,name,color',
            ])
            ->addSelect([
                'latest_note_body' => Note::query()
                    ->select('body')->whereColumn('notes.lead_id', 'leads.id')
                    ->latest('notes.id')->limit(1),
                'latest_note_created_at' => Note::query()
                    ->select('created_at')->whereColumn('notes.lead_id', 'leads.id')
                    ->latest('notes.id')->limit(1),
            ])
            ->latest('leads.id')
            ->paginate((int) ($validated['per_page'] ?? 25));

        return $this->success($leads, 'Leads fetched successfully.');
    }





// public function index(Request $request): JsonResponse
// {
//     $companyId = $this->companyId($request);

//     /*
//     |--------------------------------------------------------------------------
//     | Validation
//     |--------------------------------------------------------------------------
//     */

//     $validated = $request->validate([
//         /*
//         |--------------------------------------------------------------------------
//         | Exact Lead / Call Disposition Filters
//         |--------------------------------------------------------------------------
//         |
//         | lead_id=4607
//         | call_disposition_id=3
//         |
//         | Dono saath bhejne par wahi exact accessible lead return hogi jiske
//         | kisi call log me selected disposition save hai.
//         |
//         */

//         'lead_id' => [
//             'nullable',
//             'integer',
//             'min:1',
//             Rule::exists('leads', 'id')->where(
//                 fn ($query) => $query
//                     ->where('company_id', $companyId)
//                     ->whereNull('deleted_at')
//             ),
//         ],

//         'call_disposition_id' => [
//             'nullable',
//             'integer',
//             'min:1',
//             Rule::exists('call_dispositions', 'id')->where(
//                 fn ($query) => $query->where(
//                     fn ($scope) => $scope
//                         ->whereNull('company_id')
//                         ->orWhere('company_id', $companyId)
//                 )
//             ),
//         ],

//         'call_disposition_type' => [
//             'nullable',
//             'string',
//             'max:100',
//         ],

//         'search' => [
//             'nullable',
//             'string',
//             'max:255',
//         ],

//         'status' => [
//             'nullable',
//             'integer',
//         ],

//         'source' => [
//             'nullable',
//             'integer',
//         ],

//         'category' => [
//             'nullable',
//             'string',
//             'max:255',
//         ],

//         'assigned_to' => [
//             'nullable',
//             'string',
//         ],

//         'team_id' => [
//             'nullable',
//             'integer',
//         ],

//         'priority' => [
//             'nullable',
//             Rule::in([
//                 'low',
//                 'normal',
//                 'high',
//                 'urgent',
//                 'hot',
//             ]),
//         ],

//         'temperature' => [
//             'nullable',
//             Rule::in([
//                 'cold',
//                 'warm',
//                 'hot',
//             ]),
//         ],

//         'label_id' => [
//             'nullable',
//             'integer',
//         ],

//         'demo_send' => [
//             'nullable',
//             'boolean',
//         ],

//         'lead_send' => [
//             'nullable',
//             Rule::in([
//                 'today',
//                 'all',
//             ]),
//         ],

//         'created_filter' => [
//             'nullable',
//             Rule::in([
//                 'today',
//             ]),
//         ],

//         'date_from' => [
//             'nullable',
//             'date',
//         ],

//         'date_to' => [
//             'nullable',
//             'date',
//             'after_or_equal:date_from',
//         ],

//         /*
//         |--------------------------------------------------------------------------
//         | Separate section filters
//         |--------------------------------------------------------------------------
//         */

//         'new_category' => [
//             'nullable',
//             'string',
//             'max:255',
//         ],

//         'dialed_category' => [
//             'nullable',
//             'string',
//             'max:255',
//         ],

//         'connected_category' => [
//             'nullable',
//             'string',
//             'max:255',
//         ],

//         'new_disposition' => [
//             'nullable',
//             'string',
//             'max:50',
//         ],

//         'dialed_disposition' => [
//             'nullable',
//             'string',
//             'max:50',
//         ],

//         'connected_disposition' => [
//             'nullable',
//             'string',
//             'max:50',
//         ],

//         'new_assigned_to' => [
//             'nullable',
//             'string',
//         ],

//         'dialed_assigned_to' => [
//             'nullable',
//             'string',
//         ],

//         'connected_assigned_to' => [
//             'nullable',
//             'string',
//         ],

//         'new_team_id' => [
//             'nullable',
//             'integer',
//         ],

//         'dialed_team_id' => [
//             'nullable',
//             'integer',
//         ],

//         'connected_team_id' => [
//             'nullable',
//             'integer',
//         ],

//         /*
//         |--------------------------------------------------------------------------
//         | Pagination
//         |--------------------------------------------------------------------------
//         */

//         'per_page' => [
//             'nullable',
//             'integer',
//             Rule::in([
//                 10,
//                 25,
//                 50,
//                 100,
//                 200,
//             ]),
//         ],

//         'new_page' => [
//             'nullable',
//             'integer',
//             'min:1',
//         ],

//         'dialed_page' => [
//             'nullable',
//             'integer',
//             'min:1',
//         ],

//         'connected_page' => [
//             'nullable',
//             'integer',
//             'min:1',
//         ],
//     ]);


//     /*
//     |--------------------------------------------------------------------------
//     | Base Request
//     |--------------------------------------------------------------------------
//     |
//     | Section-specific filters filteredLeadQuery() ko nahi bhejne.
//     |
//     */

//     $baseRequest = clone $request;

//     $removeKeys = [
//         'lead_id',
//         'call_disposition_id',
//         'call_disposition_type',

//         'call_state',
//         'call_disposition',

//         'new_category',
//         'dialed_category',
//         'connected_category',

//         'new_disposition',
//         'dialed_disposition',
//         'connected_disposition',

//         'new_assigned_to',
//         'dialed_assigned_to',
//         'connected_assigned_to',

//         'new_team_id',
//         'dialed_team_id',
//         'connected_team_id',

//         'new_page',
//         'dialed_page',
//         'connected_page',

//         'page',
//         'per_page',
//     ];

//     foreach ($removeKeys as $key) {
//         $baseRequest->query->remove($key);
//         $baseRequest->request->remove($key);
//     }


//     /*
//     |--------------------------------------------------------------------------
//     | Base Accessible Query
//     |--------------------------------------------------------------------------
//     |
//     | Existing Admin / Super Admin / Team Leader / Employee permission
//     | filteredLeadQuery() se hi chalega.
//     |
//     */

//     $baseQuery = $this->filteredLeadQuery(
//         $baseRequest
//     );


//     /*
//     |--------------------------------------------------------------------------
//     | Exact Lead ID Filter
//     |--------------------------------------------------------------------------
//     |
//     | Ye common base query par lagega, isliye new/dialed/connected tino
//     | sections aur unke counts sirf selected lead ke according banenge.
//     |
//     */

//     if (!empty($validated['lead_id'])) {
//         $baseQuery->whereKey(
//             (int) $validated['lead_id']
//         );
//     }


//     /*
//     |--------------------------------------------------------------------------
//     | Relations
//     |--------------------------------------------------------------------------
//     */

//     $relations = [
//         'assignedUser:id,name,email,employee_code,team_id',

//         'source:id,name',

//         'status:id,name,color',

//         'team:id,name',

//         'stage:id,name,color',

//         'labels:id,company_id,name,color',

//         'latestCall' => function ($query) {
//             $query->with([
//                 'disposition',
//                 'user:id,name',
//             ]);
//         },

//         'latestNote.user:id,name',

//         'latestFollowUp' => function ($query) {
//             $query->with([
//                 'assignedUser:id,name',
//             ]);
//         },
//     ];


//     /*
//     |--------------------------------------------------------------------------
//     | Prepare Lead Query
//     |--------------------------------------------------------------------------
//     |
//     | Teenon sections me same relation + latest note + latest current call data.
//     |
//     */

//     $prepareQuery = function (Builder $query) use ($relations) {

//         return $query
//             ->with($relations)

//             /*
//              * Existing/global call count.
//              */
//             ->withCount('calls')

//             ->addSelect([

//                 /*
//                 |--------------------------------------------------------------------------
//                 | Latest Call ID Of Current Assignment
//                 |--------------------------------------------------------------------------
//                 */

//                 'latest_call_id' => CallLog::query()
//                     ->select('id')
//                     ->whereColumn(
//                         'call_logs.lead_id',
//                         'leads.id'
//                     )
//                     ->where(
//                         function (Builder $callScope) {

//                             $callScope

//                                 /*
//                                  * Assigned Lead:
//                                  * Current employee ki latest assignment ke
//                                  * baad ki calls.
//                                  */
//                                 ->where(
//                                     function (Builder $assigned) {

//                                         $assigned
//                                             ->whereNotNull(
//                                                 'leads.assigned_to'
//                                             )
//                                             ->whereColumn(
//                                                 'call_logs.user_id',
//                                                 'leads.assigned_to'
//                                             )
//                                             ->whereRaw(
//                                                 "
//                                                 call_logs.created_at >=
//                                                 COALESCE(
//                                                     (
//                                                         SELECT MAX(
//                                                             la.assigned_at
//                                                         )
//                                                         FROM lead_assignments AS la

//                                                         WHERE la.lead_id =
//                                                             leads.id

//                                                         AND la.new_user_id =
//                                                             leads.assigned_to
//                                                     ),
//                                                     leads.created_at
//                                                 )
//                                                 "
//                                             );
//                                     }
//                                 )

//                                 /*
//                                  * Unassigned lead:
//                                  * Global call behavior.
//                                  */
//                                 ->orWhere(
//                                     function (Builder $unassigned) {

//                                         $unassigned
//                                             ->whereNull(
//                                                 'leads.assigned_to'
//                                             );
//                                     }
//                                 );
//                         }
//                     )
//                     ->latest('call_logs.id')
//                     ->limit(1),


//                 /*
//                 |--------------------------------------------------------------------------
//                 | Latest Note
//                 |--------------------------------------------------------------------------
//                 */

//                 'latest_note_body' => Note::query()
//                     ->select('body')
//                     ->whereColumn(
//                         'notes.lead_id',
//                         'leads.id'
//                     )
//                     ->latest('notes.id')
//                     ->limit(1),


//                 'latest_note_created_at' => Note::query()
//                     ->select('created_at')
//                     ->whereColumn(
//                         'notes.lead_id',
//                         'leads.id'
//                     )
//                     ->latest('notes.id')
//                     ->limit(1),


//                 'latest_note_user_name' => Note::query()
//                     ->leftJoin(
//                         'users',
//                         'users.id',
//                         '=',
//                         'notes.user_id'
//                     )
//                     ->select(
//                         'users.name'
//                     )
//                     ->whereColumn(
//                         'notes.lead_id',
//                         'leads.id'
//                     )
//                     ->latest('notes.id')
//                     ->limit(1),
//             ]);
//     };


//     /*
//     |--------------------------------------------------------------------------
//     | Current Assignment Call Scope
//     |--------------------------------------------------------------------------
//     */

//     $currentAssignmentCallScope = function (
//         Builder $callQuery
//     ) {

//         $callQuery->where(
//             function (Builder $scope) {

//                 /*
//                  * Assigned lead.
//                  */
//                 $scope
//                     ->where(
//                         function (Builder $assigned) {

//                             $assigned
//                                 ->whereNotNull(
//                                     'leads.assigned_to'
//                                 )
//                                 ->whereColumn(
//                                     'call_logs.user_id',
//                                     'leads.assigned_to'
//                                 )
//                                 ->whereRaw(
//                                     "
//                                     call_logs.created_at >=
//                                     COALESCE(
//                                         (
//                                             SELECT MAX(
//                                                 la.assigned_at
//                                             )
//                                             FROM lead_assignments AS la

//                                             WHERE la.lead_id =
//                                                 leads.id

//                                             AND la.new_user_id =
//                                                 leads.assigned_to
//                                         ),
//                                         leads.created_at
//                                     )
//                                     "
//                                 );
//                         }
//                     )

//                     /*
//                      * Unassigned lead.
//                      */
//                     ->orWhere(
//                         function (Builder $unassigned) {

//                             $unassigned
//                                 ->whereNull(
//                                     'leads.assigned_to'
//                                 );
//                         }
//                     );
//             }
//         );
//     };


//     /*
//     |--------------------------------------------------------------------------
//     | Global Latest Call Disposition Filter
//     |--------------------------------------------------------------------------
//     |
//     | call_disposition_id aur call_disposition_type historical call par nahi,
//     | current assignment ki latest call par match honge.
//     |
//     */

//     $callDispositionId = !empty($validated['call_disposition_id'])
//         ? (int) $validated['call_disposition_id']
//         : null;

//     $callDispositionType = !empty($validated['call_disposition_type'])
//         ? strtolower(trim((string) $validated['call_disposition_type']))
//         : null;

//     if ($callDispositionId !== null || $callDispositionType !== null) {
//         $baseQuery->whereHas(
//             'calls',
//             function (Builder $calls) use (
//                 $callDispositionId,
//                 $callDispositionType,
//                 $currentAssignmentCallScope,
//                 $companyId
//             ) {
//                 $currentAssignmentCallScope($calls);

//                 $calls->where(
//                     'call_logs.company_id',
//                     $companyId
//                 );

//                 if ($callDispositionId !== null) {
//                     $calls->where(
//                         'call_logs.call_disposition_id',
//                         $callDispositionId
//                     );
//                 }

//                 if ($callDispositionType !== null) {
//                     $calls->whereHas(
//                         'disposition',
//                         function (Builder $disposition) use (
//                             $callDispositionType,
//                             $companyId
//                         ) {
//                             $disposition
//                                 ->whereRaw(
//                                     'LOWER(call_dispositions.type) = ?',
//                                     [$callDispositionType]
//                                 )
//                                 ->where(function (Builder $scope) use ($companyId) {
//                                     $scope
//                                         ->whereNull('call_dispositions.company_id')
//                                         ->orWhere(
//                                             'call_dispositions.company_id',
//                                             $companyId
//                                         );
//                                 });
//                         }
//                     );
//                 }

//                 $calls->whereRaw(
//                     "
//                     call_logs.id = (
//                         SELECT MAX(cl_latest.id)
//                         FROM call_logs AS cl_latest
//                         WHERE cl_latest.lead_id = call_logs.lead_id
//                         AND (
//                             (
//                                 leads.assigned_to IS NOT NULL
//                                 AND cl_latest.user_id = leads.assigned_to
//                                 AND cl_latest.created_at >= COALESCE(
//                                     (
//                                         SELECT MAX(la_latest.assigned_at)
//                                         FROM lead_assignments AS la_latest
//                                         WHERE la_latest.lead_id = leads.id
//                                         AND la_latest.new_user_id = leads.assigned_to
//                                     ),
//                                     leads.created_at
//                                 )
//                             )
//                             OR leads.assigned_to IS NULL
//                         )
//                     )
//                     "
//                 );
//             }
//         );
//     }


//     /*
//     |--------------------------------------------------------------------------
//     | NEW CALL
//     |--------------------------------------------------------------------------
//     |
//     | Current assignment ke baad ek bhi call nahi.
//     |
//     */

//     $newQuery = clone $baseQuery;

//     $newQuery->whereDoesntHave(
//         'calls',
//         $currentAssignmentCallScope
//     );


//     /*
//     |--------------------------------------------------------------------------
//     | DIALED CALL
//     |--------------------------------------------------------------------------
//     |
//     | Current assignment ke baad kam se kam ek call hui.
//     | Disposition kuch bhi ho sakta hai.
//     |
//     */

//     $dialedQuery = clone $baseQuery;

//     $dialedQuery->whereHas(
//         'calls',
//         $currentAssignmentCallScope
//     );


//     /*
//     |--------------------------------------------------------------------------
//     | CONNECTED CALL
//     |--------------------------------------------------------------------------
//     |
//     | Current assignment par call honi chahiye
//     |
//     | AND
//     |
//     | remarks / remark / auto_remarks / note hona chahiye.
//     |
//     */

//     $connectedQuery = clone $baseQuery;

//     /*
//      * Current assignment ki call compulsory.
//      */
//     $connectedQuery->whereHas(
//         'calls',
//         $currentAssignmentCallScope
//     );

//     $connectedQuery->where(
//         function (Builder $connected) use (
//             $currentAssignmentCallScope
//         ) {

//             /*
//             |--------------------------------------------------------------------------
//             | Note Exists
//             |--------------------------------------------------------------------------
//             */

//             $connected->whereHas('notes');


//             /*
//             |--------------------------------------------------------------------------
//             | remarks
//             |--------------------------------------------------------------------------
//             */

//             if (
//                 Schema::hasColumn(
//                     'call_logs',
//                     'remarks'
//                 )
//             ) {

//                 $connected->orWhereHas(
//                     'calls',
//                     function (
//                         Builder $calls
//                     ) use (
//                         $currentAssignmentCallScope
//                     ) {

//                         $currentAssignmentCallScope(
//                             $calls
//                         );

//                         $calls
//                             ->whereNotNull(
//                                 'remarks'
//                             )
//                             ->whereRaw(
//                                 "
//                                 TRIM(
//                                     COALESCE(
//                                         remarks,
//                                         ''
//                                     )
//                                 ) <> ''
//                                 "
//                             );
//                     }
//                 );
//             }


//             /*
//             |--------------------------------------------------------------------------
//             | remark
//             |--------------------------------------------------------------------------
//             */

//             if (
//                 Schema::hasColumn(
//                     'call_logs',
//                     'remark'
//                 )
//             ) {

//                 $connected->orWhereHas(
//                     'calls',
//                     function (
//                         Builder $calls
//                     ) use (
//                         $currentAssignmentCallScope
//                     ) {

//                         $currentAssignmentCallScope(
//                             $calls
//                         );

//                         $calls
//                             ->whereNotNull(
//                                 'remark'
//                             )
//                             ->whereRaw(
//                                 "
//                                 TRIM(
//                                     COALESCE(
//                                         remark,
//                                         ''
//                                     )
//                                 ) <> ''
//                                 "
//                             );
//                     }
//                 );
//             }


//             /*
//             |--------------------------------------------------------------------------
//             | auto_remarks
//             |--------------------------------------------------------------------------
//             */

//             if (
//                 Schema::hasColumn(
//                     'call_logs',
//                     'auto_remarks'
//                 )
//             ) {

//                 $connected->orWhereHas(
//                     'calls',
//                     function (
//                         Builder $calls
//                     ) use (
//                         $currentAssignmentCallScope
//                     ) {

//                         $currentAssignmentCallScope(
//                             $calls
//                         );

//                         $calls
//                             ->whereNotNull(
//                                 'auto_remarks'
//                             )
//                             ->whereRaw(
//                                 "
//                                 TRIM(
//                                     COALESCE(
//                                         auto_remarks,
//                                         ''
//                                     )
//                                 ) <> ''
//                                 "
//                             );
//                     }
//                 );
//             }
//         }
//     );


//     /*
//     |--------------------------------------------------------------------------
//     | Keep Dialed And Connected Sections Unique
//     |--------------------------------------------------------------------------
//     |
//     | Connected lead ko Dialed section se exclude kar rahe hain. Isse ek lead
//     | response me do sections me repeat nahi hogi aur counts.total unique rahega.
//     |
//     */

//     $dialedQuery->whereNotIn(
//         'leads.id',
//         (clone $connectedQuery)->select('leads.id')
//     );


//     /*
//     |--------------------------------------------------------------------------
//     | Section Specific Filters
//     |--------------------------------------------------------------------------
//     */

//     $applySectionFilters = function (
//         Builder $query,
//         string $section
//     ) use (
//         $request,
//         $currentAssignmentCallScope
//     ) {

//         /*
//         |--------------------------------------------------------------------------
//         | Category
//         |--------------------------------------------------------------------------
//         */

//         $category = $request->input(
//             "{$section}_category"
//         );

//         if (
//             $category !== null &&
//             $category !== ''
//         ) {

//             $query->where(
//                 'leads.category',
//                 $category
//             );
//         }


//         /*
//         |--------------------------------------------------------------------------
//         | Employee
//         |--------------------------------------------------------------------------
//         */

//         $assignedTo = $request->input(
//             "{$section}_assigned_to"
//         );

//         if (
//             $assignedTo !== null &&
//             $assignedTo !== ''
//         ) {

//             if ($assignedTo === 'unassigned') {

//                 $query->whereNull(
//                     'leads.assigned_to'
//                 );

//             } elseif (
//                 ctype_digit(
//                     (string) $assignedTo
//                 )
//             ) {

//                 $query->where(
//                     'leads.assigned_to',
//                     (int) $assignedTo
//                 );
//             }
//         }


//         /*
//         |--------------------------------------------------------------------------
//         | Team
//         |--------------------------------------------------------------------------
//         */

//         $teamId = $request->input(
//             "{$section}_team_id"
//         );

//         if ($teamId) {

//             $query->where(
//                 'leads.team_id',
//                 (int) $teamId
//             );
//         }


//         /*
//         |--------------------------------------------------------------------------
//         | Disposition
//         |--------------------------------------------------------------------------
//         |
//         | New section me normally disposition nahi hoga.
//         |
//         | Dialed/Connected me current assignment ki latest call ka
//         | disposition match hoga.
//         |
//         */

//         $disposition = $request->input(
//             "{$section}_disposition"
//         );

//         if (
//             $disposition !== null &&
//             $disposition !== '' &&
//             $disposition !== 'all'
//         ) {

//             if ($disposition === 'no_call') {

//                 $query->whereDoesntHave(
//                     'calls',
//                     $currentAssignmentCallScope
//                 );

//             } elseif (
//                 ctype_digit(
//                     (string) $disposition
//                 )
//             ) {

//                 $dispositionId =
//                     (int) $disposition;

//                 $query->whereHas(
//                     'calls',
//                     function (
//                         Builder $calls
//                     ) use (
//                         $dispositionId,
//                         $currentAssignmentCallScope
//                     ) {

//                         /*
//                          * Current assignment calls only.
//                          */
//                         $currentAssignmentCallScope(
//                             $calls
//                         );

//                         /*
//                          * Selected disposition.
//                          */
//                         $calls->where(
//                             'call_disposition_id',
//                             $dispositionId
//                         );

//                         /*
//                          * Current assignment ki latest call hi
//                          * selected disposition honi chahiye.
//                          */
//                         $calls->whereRaw(
//                             "
//                             call_logs.id = (
//                                 SELECT MAX(cl2.id)

//                                 FROM call_logs AS cl2

//                                 WHERE cl2.lead_id =
//                                     call_logs.lead_id

//                                 AND (
//                                     (
//                                         leads.assigned_to IS NOT NULL

//                                         AND cl2.user_id =
//                                             leads.assigned_to

//                                         AND cl2.created_at >=
//                                             COALESCE(
//                                                 (
//                                                     SELECT MAX(
//                                                         la.assigned_at
//                                                     )
//                                                     FROM lead_assignments AS la

//                                                     WHERE la.lead_id =
//                                                         leads.id

//                                                     AND la.new_user_id =
//                                                         leads.assigned_to
//                                                 ),
//                                                 leads.created_at
//                                             )
//                                     )

//                                     OR

//                                     leads.assigned_to IS NULL
//                                 )
//                             )
//                             "
//                         );
//                     }
//                 );

//             } else {

//                 /*
//                  * Invalid disposition.
//                  */
//                 $query->whereRaw(
//                     '1 = 0'
//                 );
//             }
//         }
//     };


//     /*
//     |--------------------------------------------------------------------------
//     | Apply Section Filters
//     |--------------------------------------------------------------------------
//     */

//     $applySectionFilters(
//         $newQuery,
//         'new'
//     );

//     $applySectionFilters(
//         $dialedQuery,
//         'dialed'
//     );

//     $applySectionFilters(
//         $connectedQuery,
//         'connected'
//     );


//     /*
//     |--------------------------------------------------------------------------
//     | Counts
//     |--------------------------------------------------------------------------
//     |
//     | Ye filtered counts hain.
//     |
//     */

//     $newCount =
//         (clone $newQuery)->count();

//     $dialedCount =
//         (clone $dialedQuery)->count();

//     $connectedCount =
//         (clone $connectedQuery)->count();


//     /*
//     |--------------------------------------------------------------------------
//     | Pagination
//     |--------------------------------------------------------------------------
//     |
//     | Har section ki separate pagination.
//     |
//     */

//     $perPage = (int) (
//         $validated['per_page']
//         ?? 25
//     );


//     /*
//     |--------------------------------------------------------------------------
//     | New Leads
//     |--------------------------------------------------------------------------
//     */

//     $newLeads =
//         $prepareQuery(
//             clone $newQuery
//         )
//             ->orderByDesc(
//                 'leads.id'
//             )
//             ->paginate(
//                 $perPage,
//                 ['*'],
//                 'new_page'
//             );


//     /*
//     |--------------------------------------------------------------------------
//     | Dialed Leads
//     |--------------------------------------------------------------------------
//     */

//     $dialedLeads =
//         $prepareQuery(
//             clone $dialedQuery
//         )
//             ->orderByDesc(
//                 'latest_call_id'
//             )
//             ->orderByDesc(
//                 'leads.id'
//             )
//             ->paginate(
//                 $perPage,
//                 ['*'],
//                 'dialed_page'
//             );


//     /*
//     |--------------------------------------------------------------------------
//     | Connected Leads
//     |--------------------------------------------------------------------------
//     */

//     $connectedLeads =
//         $prepareQuery(
//             clone $connectedQuery
//         )
//             ->orderByDesc(
//                 'latest_call_id'
//             )
//             ->orderByDesc(
//                 'leads.id'
//             )
//             ->paginate(
//                 $perPage,
//                 ['*'],
//                 'connected_page'
//             );


//     /*
//     |--------------------------------------------------------------------------
//     | Final API Response
//     |--------------------------------------------------------------------------
//     |
//     | Ek hi API me teen separate sections.
//     |
//     */

//     $data = [

//         /*
//         |--------------------------------------------------------------------------
//         | Summary
//         |--------------------------------------------------------------------------
//         */

//         'counts' => [
//             'new' =>
//                 $newCount,

//             'dialed' =>
//                 $dialedCount,

//             'connected' =>
//                 $connectedCount,

//             'total' =>
//                 $newCount +
//                 $dialedCount +
//                 $connectedCount,
//         ],


//         /*
//         |--------------------------------------------------------------------------
//         | NEW
//         |--------------------------------------------------------------------------
//         */

//         'new' => [
//             'count' =>
//                 $newCount,

//             'leads' =>
//                 $newLeads,
//         ],


//         /*
//         |--------------------------------------------------------------------------
//         | DIALED
//         |--------------------------------------------------------------------------
//         */

//         'dialed' => [
//             'count' =>
//                 $dialedCount,

//             'leads' =>
//                 $dialedLeads,
//         ],


//         /*
//         |--------------------------------------------------------------------------
//         | CONNECTED
//         |--------------------------------------------------------------------------
//         */

//         'connected' => [
//             'count' =>
//                 $connectedCount,

//             'leads' =>
//                 $connectedLeads,
//         ],
//     ];


//     return $this->success(
//         $data,
//         'Leads fetched successfully.'
//     );
// }



// public function index(Request $request): JsonResponse
// {
//     $companyId = $this->companyId($request);

//     /*
//     |--------------------------------------------------------------------------
//     | Validation
//     |--------------------------------------------------------------------------
//     */

//     $validated = $request->validate([
//         /*
//         |--------------------------------------------------------------------------
//         | Exact Lead / Call Disposition Filters
//         |--------------------------------------------------------------------------
//         |
//         | lead_id=4607
//         | call_disposition_id=3
//         |
//         | Dono saath bhejne par wahi exact accessible lead return hogi jiske
//         | kisi call log me selected disposition save hai.
//         |
//         */

//         'lead_id' => [
//             'nullable',
//             'integer',
//             'min:1',
//             Rule::exists('leads', 'id')->where(
//                 fn ($query) => $query
//                     ->where('company_id', $companyId)
//                     ->whereNull('deleted_at')
//             ),
//         ],

//         'call_disposition_id' => [
//             'nullable',
//             'integer',
//             'min:1',
//             Rule::exists('call_dispositions', 'id')->where(
//                 fn ($query) => $query->where(
//                     fn ($scope) => $scope
//                         ->whereNull('company_id')
//                         ->orWhere('company_id', $companyId)
//                 )
//             ),
//         ],

//         'call_disposition_type' => [
//             'nullable',
//             'string',
//             'max:100',
//         ],

//         'search' => [
//             'nullable',
//             'string',
//             'max:255',
//         ],

//         'status' => [
//             'nullable',
//             'integer',
//         ],

//         'source' => [
//             'nullable',
//             'integer',
//         ],

//         'category' => [
//             'nullable',
//             'string',
//             'max:255',
//         ],

//         'assigned_to' => [
//             'nullable',
//             'string',
//         ],

//         'team_id' => [
//             'nullable',
//             'integer',
//         ],

//         'priority' => [
//             'nullable',
//             Rule::in([
//                 'low',
//                 'normal',
//                 'high',
//                 'urgent',
//                 'hot',
//             ]),
//         ],

//         'temperature' => [
//             'nullable',
//             Rule::in([
//                 'cold',
//                 'warm',
//                 'hot',
//             ]),
//         ],

//         'label_id' => [
//             'nullable',
//             'integer',
//         ],

//         'demo_send' => [
//             'nullable',
//             'boolean',
//         ],

//         'lead_send' => [
//             'nullable',
//             Rule::in([
//                 'today',
//                 'all',
//             ]),
//         ],

//         'created_filter' => [
//             'nullable',
//             Rule::in([
//                 'today',
//             ]),
//         ],

//         'date_from' => [
//             'nullable',
//             'date',
//         ],

//         'date_to' => [
//             'nullable',
//             'date',
//             'after_or_equal:date_from',
//         ],

//         /*
//         |--------------------------------------------------------------------------
//         | Separate section filters
//         |--------------------------------------------------------------------------
//         */

//         'new_category' => [
//             'nullable',
//             'string',
//             'max:255',
//         ],

//         'dialed_category' => [
//             'nullable',
//             'string',
//             'max:255',
//         ],

//         'connected_category' => [
//             'nullable',
//             'string',
//             'max:255',
//         ],

//         'new_disposition' => [
//             'nullable',
//             'string',
//             'max:50',
//         ],

//         'dialed_disposition' => [
//             'nullable',
//             'string',
//             'max:50',
//         ],

//         'connected_disposition' => [
//             'nullable',
//             'string',
//             'max:50',
//         ],

//         'new_assigned_to' => [
//             'nullable',
//             'string',
//         ],

//         'dialed_assigned_to' => [
//             'nullable',
//             'string',
//         ],

//         'connected_assigned_to' => [
//             'nullable',
//             'string',
//         ],

//         'new_team_id' => [
//             'nullable',
//             'integer',
//         ],

//         'dialed_team_id' => [
//             'nullable',
//             'integer',
//         ],

//         'connected_team_id' => [
//             'nullable',
//             'integer',
//         ],

//         /*
//         |--------------------------------------------------------------------------
//         | Pagination
//         |--------------------------------------------------------------------------
//         */

//         'per_page' => [
//             'nullable',
//             'integer',
//             Rule::in([
//                 10,
//                 25,
//                 50,
//                 100,
//                 200,
//             ]),
//         ],

//         'new_page' => [
//             'nullable',
//             'integer',
//             'min:1',
//         ],

//         'dialed_page' => [
//             'nullable',
//             'integer',
//             'min:1',
//         ],

//         'connected_page' => [
//             'nullable',
//             'integer',
//             'min:1',
//         ],
//     ]);


//     /*
//     |--------------------------------------------------------------------------
//     | Base Request
//     |--------------------------------------------------------------------------
//     |
//     | Section-specific filters filteredLeadQuery() ko nahi bhejne.
//     |
//     */

//     $baseRequest = clone $request;

//     $removeKeys = [
//         'lead_id',
//         'call_disposition_id',
//         'call_disposition_type',

//         'call_state',
//         'call_disposition',

//         'new_category',
//         'dialed_category',
//         'connected_category',

//         'new_disposition',
//         'dialed_disposition',
//         'connected_disposition',

//         'new_assigned_to',
//         'dialed_assigned_to',
//         'connected_assigned_to',

//         'new_team_id',
//         'dialed_team_id',
//         'connected_team_id',

//         'new_page',
//         'dialed_page',
//         'connected_page',

//         'page',
//         'per_page',
//     ];

//     foreach ($removeKeys as $key) {
//         $baseRequest->query->remove($key);
//         $baseRequest->request->remove($key);
//     }


//     /*
//     |--------------------------------------------------------------------------
//     | Base Accessible Query
//     |--------------------------------------------------------------------------
//     |
//     | Existing Admin / Super Admin / Team Leader / Employee permission
//     | filteredLeadQuery() se hi chalega.
//     |
//     */

//     $baseQuery = $this->filteredLeadQuery(
//         $baseRequest
//     );


//     /*
//     |--------------------------------------------------------------------------
//     | Exact Lead ID Filter
//     |--------------------------------------------------------------------------
//     |
//     | Ye common base query par lagega, isliye new/dialed/connected tino
//     | sections aur unke counts sirf selected lead ke according banenge.
//     |
//     */

//     if (!empty($validated['lead_id'])) {
//         $baseQuery->whereKey(
//             (int) $validated['lead_id']
//         );
//     }


//     /*
//     |--------------------------------------------------------------------------
//     | Relations
//     |--------------------------------------------------------------------------
//     */

//     $relations = [
//         'assignedUser:id,name,email,employee_code,team_id',

//         'source:id,name',

//         'status:id,name,color',

//         'team:id,name',

//         'stage:id,name,color',

//         'labels:id,company_id,name,color',

//         'latestCall' => function ($query) {
//             $query->with([
//                 'disposition',
//                 'user:id,name',
//             ]);
//         },

//         'latestNote.user:id,name',

//         'latestFollowUp' => function ($query) {
//             $query->with([
//                 'assignedUser:id,name',
//             ]);
//         },
//     ];


//     /*
//     |--------------------------------------------------------------------------
//     | Prepare Lead Query
//     |--------------------------------------------------------------------------
//     |
//     | Teenon sections me same relation + latest note + latest current call data.
//     |
//     */

//     $prepareQuery = function (Builder $query) use ($relations) {

//         return $query
//             ->with($relations)

//             /*
//              * Existing/global call count.
//              */
//             ->withCount('calls')

//             ->addSelect([

//                 /*
//                 |--------------------------------------------------------------------------
//                 | Latest Call ID Of Current Assignment
//                 |--------------------------------------------------------------------------
//                 */

//                 'latest_call_id' => CallLog::query()
//                     ->select('id')
//                     ->whereColumn(
//                         'call_logs.lead_id',
//                         'leads.id'
//                     )
//                     ->where(
//                         function (Builder $callScope) {

//                             $callScope

//                                 /*
//                                  * Assigned Lead:
//                                  * Current employee ki latest assignment ke
//                                  * baad ki calls.
//                                  */
//                                 ->where(
//                                     function (Builder $assigned) {

//                                         $assigned
//                                             ->whereNotNull(
//                                                 'leads.assigned_to'
//                                             )
//                                             ->whereColumn(
//                                                 'call_logs.user_id',
//                                                 'leads.assigned_to'
//                                             )
//                                             ->whereRaw(
//                                                 "
//                                                 call_logs.created_at >=
//                                                 COALESCE(
//                                                     (
//                                                         SELECT MAX(
//                                                             la.assigned_at
//                                                         )
//                                                         FROM lead_assignments AS la

//                                                         WHERE la.lead_id =
//                                                             leads.id

//                                                         AND la.new_user_id =
//                                                             leads.assigned_to
//                                                     ),
//                                                     leads.created_at
//                                                 )
//                                                 "
//                                             );
//                                     }
//                                 )

//                                 /*
//                                  * Unassigned lead:
//                                  * Global call behavior.
//                                  */
//                                 ->orWhere(
//                                     function (Builder $unassigned) {

//                                         $unassigned
//                                             ->whereNull(
//                                                 'leads.assigned_to'
//                                             );
//                                     }
//                                 );
//                         }
//                     )
//                     ->latest('call_logs.id')
//                     ->limit(1),


//                 /*
//                 |--------------------------------------------------------------------------
//                 | Latest Note
//                 |--------------------------------------------------------------------------
//                 */

//                 'latest_note_body' => Note::query()
//                     ->select('body')
//                     ->whereColumn(
//                         'notes.lead_id',
//                         'leads.id'
//                     )
//                     ->latest('notes.id')
//                     ->limit(1),


//                 'latest_note_created_at' => Note::query()
//                     ->select('created_at')
//                     ->whereColumn(
//                         'notes.lead_id',
//                         'leads.id'
//                     )
//                     ->latest('notes.id')
//                     ->limit(1),


//                 'latest_note_user_name' => Note::query()
//                     ->leftJoin(
//                         'users',
//                         'users.id',
//                         '=',
//                         'notes.user_id'
//                     )
//                     ->select(
//                         'users.name'
//                     )
//                     ->whereColumn(
//                         'notes.lead_id',
//                         'leads.id'
//                     )
//                     ->latest('notes.id')
//                     ->limit(1),
//             ]);
//     };


//     /*
//     |--------------------------------------------------------------------------
//     | Current Assignment Call Scope
//     |--------------------------------------------------------------------------
//     */

//     $currentAssignmentCallScope = function (
//         Builder $callQuery
//     ) {

//         $callQuery->where(
//             function (Builder $scope) {

//                 /*
//                  * Assigned lead.
//                  */
//                 $scope
//                     ->where(
//                         function (Builder $assigned) {

//                             $assigned
//                                 ->whereNotNull(
//                                     'leads.assigned_to'
//                                 )
//                                 ->whereColumn(
//                                     'call_logs.user_id',
//                                     'leads.assigned_to'
//                                 )
//                                 ->whereRaw(
//                                     "
//                                     call_logs.created_at >=
//                                     COALESCE(
//                                         (
//                                             SELECT MAX(
//                                                 la.assigned_at
//                                             )
//                                             FROM lead_assignments AS la

//                                             WHERE la.lead_id =
//                                                 leads.id

//                                             AND la.new_user_id =
//                                                 leads.assigned_to
//                                         ),
//                                         leads.created_at
//                                     )
//                                     "
//                                 );
//                         }
//                     )

//                     /*
//                      * Unassigned lead.
//                      */
//                     ->orWhere(
//                         function (Builder $unassigned) {

//                             $unassigned
//                                 ->whereNull(
//                                     'leads.assigned_to'
//                                 );
//                         }
//                     );
//             }
//         );
//     };


//     /*
//     |--------------------------------------------------------------------------
//     | Global Latest Call Disposition Filter
//     |--------------------------------------------------------------------------
//     |
//     | call_disposition_id aur call_disposition_type historical call par nahi,
//     | current assignment ki latest call par match honge.
//     |
//     */

//     $callDispositionId = !empty($validated['call_disposition_id'])
//         ? (int) $validated['call_disposition_id']
//         : null;

//     $callDispositionType = !empty($validated['call_disposition_type'])
//         ? strtolower(trim((string) $validated['call_disposition_type']))
//         : null;

//     if ($callDispositionId !== null || $callDispositionType !== null) {
//         $baseQuery->whereHas(
//             'calls',
//             function (Builder $calls) use (
//                 $callDispositionId,
//                 $callDispositionType,
//                 $currentAssignmentCallScope,
//                 $companyId
//             ) {
//                 $currentAssignmentCallScope($calls);

//                 $calls->where(
//                     'call_logs.company_id',
//                     $companyId
//                 );

//                 if ($callDispositionId !== null) {
//                     $calls->where(
//                         'call_logs.call_disposition_id',
//                         $callDispositionId
//                     );
//                 }

//                 if ($callDispositionType !== null) {
//                     $calls->whereHas(
//                         'disposition',
//                         function (Builder $disposition) use (
//                             $callDispositionType,
//                             $companyId
//                         ) {
//                             $disposition
//                                 ->whereRaw(
//                                     'LOWER(call_dispositions.type) = ?',
//                                     [$callDispositionType]
//                                 )
//                                 ->where(function (Builder $scope) use ($companyId) {
//                                     $scope
//                                         ->whereNull('call_dispositions.company_id')
//                                         ->orWhere(
//                                             'call_dispositions.company_id',
//                                             $companyId
//                                         );
//                                 });
//                         }
//                     );
//                 }

//                 $calls->whereRaw(
//                     "
//                     call_logs.id = (
//                         SELECT MAX(cl_latest.id)
//                         FROM call_logs AS cl_latest
//                         WHERE cl_latest.lead_id = call_logs.lead_id
//                         AND (
//                             (
//                                 leads.assigned_to IS NOT NULL
//                                 AND cl_latest.user_id = leads.assigned_to
//                                 AND cl_latest.created_at >= COALESCE(
//                                     (
//                                         SELECT MAX(la_latest.assigned_at)
//                                         FROM lead_assignments AS la_latest
//                                         WHERE la_latest.lead_id = leads.id
//                                         AND la_latest.new_user_id = leads.assigned_to
//                                     ),
//                                     leads.created_at
//                                 )
//                             )
//                             OR leads.assigned_to IS NULL
//                         )
//                     )
//                     "
//                 );
//             }
//         );
//     }


//     /*
//     |--------------------------------------------------------------------------
//     | NEW CALL
//     |--------------------------------------------------------------------------
//     |
//     | Current assignment ke baad ek bhi call nahi.
//     |
//     */

//     $newQuery = clone $baseQuery;

//     $newQuery->whereDoesntHave(
//         'calls',
//         $currentAssignmentCallScope
//     );


//     /*
//     |--------------------------------------------------------------------------
//     | DIALED CALL
//     |--------------------------------------------------------------------------
//     |
//     | Current assignment ke baad kam se kam ek call hui.
//     | Disposition kuch bhi ho sakta hai.
//     |
//     */

//     $dialedQuery = clone $baseQuery;

//     $dialedQuery->whereHas(
//         'calls',
//         $currentAssignmentCallScope
//     );


//     /*
//     |--------------------------------------------------------------------------
//     | CONNECTED CALL
//     |--------------------------------------------------------------------------
//     |
//     | Current assignment par call honi chahiye
//     |
//     | AND
//     |
//     | Sirf actual call remarks / legacy remark hona chahiye.
//     |
//     */

//     $connectedQuery = clone $baseQuery;

//     $connectedQuery->whereHas(
//         'calls',
//         function (Builder $calls) use (
//             $currentAssignmentCallScope
//         ) {

//             /*
//             * Sirf current assignment ki call.
//             */
//             $currentAssignmentCallScope($calls);

//             /*
//             * Web ki tarah:
//             * actual remarks hone par hi Connected.
//             */
//             if (Schema::hasColumn('call_logs', 'remarks')) {

//                 $calls
//                     ->whereNotNull('remarks')
//                     ->whereRaw(
//                         "TRIM(COALESCE(call_logs.remarks, '')) <> ''"
//                     );

//             } elseif (Schema::hasColumn('call_logs', 'remark')) {

//                 // Legacy fallback
//                 $calls
//                     ->whereNotNull('remark')
//                     ->whereRaw(
//                         "TRIM(COALESCE(call_logs.remark, '')) <> ''"
//                     );

//             } else {

//                 $calls->whereRaw('1 = 0');
//             }
//         }
//     );




//     /*
//     |--------------------------------------------------------------------------
//     | Keep Dialed And Connected Sections Unique
//     |--------------------------------------------------------------------------
//     |
//     | Connected lead ko Dialed section se exclude kar rahe hain. Isse ek lead
//     | response me do sections me repeat nahi hogi aur counts.total unique rahega.
//     |
//     */

//     // $dialedQuery->whereNotIn(
//     //     'leads.id',
//     //     (clone $connectedQuery)->select('leads.id')
//     // );


//     /*
//     |--------------------------------------------------------------------------
//     | Section Specific Filters
//     |--------------------------------------------------------------------------
//     */

//     $applySectionFilters = function (
//         Builder $query,
//         string $section
//     ) use (
//         $request,
//         $currentAssignmentCallScope
//     ) {

//         /*
//         |--------------------------------------------------------------------------
//         | Category
//         |--------------------------------------------------------------------------
//         */

//         $category = $request->input(
//             "{$section}_category"
//         );

//         if (
//             $category !== null &&
//             $category !== ''
//         ) {

//             $query->where(
//                 'leads.category',
//                 $category
//             );
//         }


//         /*
//         |--------------------------------------------------------------------------
//         | Employee
//         |--------------------------------------------------------------------------
//         */

//         $assignedTo = $request->input(
//             "{$section}_assigned_to"
//         );

//         if (
//             $assignedTo !== null &&
//             $assignedTo !== ''
//         ) {

//             if ($assignedTo === 'unassigned') {

//                 $query->whereNull(
//                     'leads.assigned_to'
//                 );

//             } elseif (
//                 ctype_digit(
//                     (string) $assignedTo
//                 )
//             ) {

//                 $query->where(
//                     'leads.assigned_to',
//                     (int) $assignedTo
//                 );
//             }
//         }


//         /*
//         |--------------------------------------------------------------------------
//         | Team
//         |--------------------------------------------------------------------------
//         */

//         $teamId = $request->input(
//             "{$section}_team_id"
//         );

//         if ($teamId) {

//             $query->where(
//                 'leads.team_id',
//                 (int) $teamId
//             );
//         }


//         /*
//         |--------------------------------------------------------------------------
//         | Disposition
//         |--------------------------------------------------------------------------
//         |
//         | New section me normally disposition nahi hoga.
//         |
//         | Dialed/Connected me current assignment ki latest call ka
//         | disposition match hoga.
//         |
//         */

//         $disposition = $request->input(
//             "{$section}_disposition"
//         );

//         if (
//             $disposition !== null &&
//             $disposition !== '' &&
//             $disposition !== 'all'
//         ) {

//             if ($disposition === 'no_call') {

//                 $query->whereDoesntHave(
//                     'calls',
//                     $currentAssignmentCallScope
//                 );

//             } elseif (
//                 ctype_digit(
//                     (string) $disposition
//                 )
//             ) {

//                 $dispositionId =
//                     (int) $disposition;

//                 $query->whereHas(
//                     'calls',
//                     function (
//                         Builder $calls
//                     ) use (
//                         $dispositionId,
//                         $currentAssignmentCallScope
//                     ) {

//                         /*
//                          * Current assignment calls only.
//                          */
//                         $currentAssignmentCallScope(
//                             $calls
//                         );

//                         /*
//                          * Selected disposition.
//                          */
//                         $calls->where(
//                             'call_disposition_id',
//                             $dispositionId
//                         );

//                         /*
//                          * Current assignment ki latest call hi
//                          * selected disposition honi chahiye.
//                          */
//                         $calls->whereRaw(
//                             "
//                             call_logs.id = (
//                                 SELECT MAX(cl2.id)

//                                 FROM call_logs AS cl2

//                                 WHERE cl2.lead_id =
//                                     call_logs.lead_id

//                                 AND (
//                                     (
//                                         leads.assigned_to IS NOT NULL

//                                         AND cl2.user_id =
//                                             leads.assigned_to

//                                         AND cl2.created_at >=
//                                             COALESCE(
//                                                 (
//                                                     SELECT MAX(
//                                                         la.assigned_at
//                                                     )
//                                                     FROM lead_assignments AS la

//                                                     WHERE la.lead_id =
//                                                         leads.id

//                                                     AND la.new_user_id =
//                                                         leads.assigned_to
//                                                 ),
//                                                 leads.created_at
//                                             )
//                                     )

//                                     OR

//                                     leads.assigned_to IS NULL
//                                 )
//                             )
//                             "
//                         );
//                     }
//                 );

//             } else {

//                 /*
//                  * Invalid disposition.
//                  */
//                 $query->whereRaw(
//                     '1 = 0'
//                 );
//             }
//         }
//     };


//     /*
//     |--------------------------------------------------------------------------
//     | Apply Section Filters
//     |--------------------------------------------------------------------------
//     */

//     $applySectionFilters(
//         $newQuery,
//         'new'
//     );

//     $applySectionFilters(
//         $dialedQuery,
//         'dialed'
//     );

//     $applySectionFilters(
//         $connectedQuery,
//         'connected'
//     );


//     /*
//     |--------------------------------------------------------------------------
//     | Counts
//     |--------------------------------------------------------------------------
//     |
//     | Ye filtered counts hain.
//     |
//     */

//     $newCount =
//         (clone $newQuery)->count();

//     $dialedCount =
//         (clone $dialedQuery)->count();

//     $connectedCount =
//         (clone $connectedQuery)->count();

//     // New + Dialed + Connected ko add nahi karna,
//     // kyunki Connected lead Dialed me bhi ho sakti hai.
//     $totalCount =
//         (clone $baseQuery)->count();


//     /*
//     |--------------------------------------------------------------------------
//     | Pagination
//     |--------------------------------------------------------------------------
//     |
//     | Har section ki separate pagination.
//     |
//     */

//     $perPage = (int) (
//         $validated['per_page']
//         ?? 10
//     );


//     /*
//     |--------------------------------------------------------------------------
//     | New Leads
//     |--------------------------------------------------------------------------
//     */

//     $newLeads =
//         $prepareQuery(
//             clone $newQuery
//         )
//             ->orderByDesc(
//                 'leads.id'
//             )
//             ->paginate(
//                 $perPage,
//                 ['*'],
//                 'new_page'
//             );


//     /*
//     |--------------------------------------------------------------------------
//     | Dialed Leads
//     |--------------------------------------------------------------------------
//     */

//     $dialedLeads =
//         $prepareQuery(
//             clone $dialedQuery
//         )
//             ->orderByDesc(
//                 'latest_call_id'
//             )
//             ->orderByDesc(
//                 'leads.id'
//             )
//             ->paginate(
//                 $perPage,
//                 ['*'],
//                 'dialed_page'
//             );


//     /*
//     |--------------------------------------------------------------------------
//     | Connected Leads
//     |--------------------------------------------------------------------------
//     */

//     $connectedLeads =
//         $prepareQuery(
//             clone $connectedQuery
//         )
//             ->orderByDesc(
//                 'latest_call_id'
//             )
//             ->orderByDesc(
//                 'leads.id'
//             )
//             ->paginate(
//                 $perPage,
//                 ['*'],
//                 'connected_page'
//             );


//     /*
//     |--------------------------------------------------------------------------
//     | Final API Response
//     |--------------------------------------------------------------------------
//     |
//     | Ek hi API me teen separate sections.
//     |
//     */

//     $data = [

//         /*
//         |--------------------------------------------------------------------------
//         | Summary
//         |--------------------------------------------------------------------------
//         */

//         'counts' => [
//             'new' =>
//                 $newCount,

//             'dialed' =>
//                 $dialedCount,

//             'connected' =>
//                 $connectedCount,

//             'total' =>
//                 $totalCount,
//         ],


//         /*
//         |--------------------------------------------------------------------------
//         | NEW
//         |--------------------------------------------------------------------------
//         */

//         'new' => [
//             'count' =>
//                 $newCount,

//             'leads' =>
//                 $newLeads,
//         ],


//         /*
//         |--------------------------------------------------------------------------
//         | DIALED
//         |--------------------------------------------------------------------------
//         */

//         'dialed' => [
//             'count' =>
//                 $dialedCount,

//             'leads' =>
//                 $dialedLeads,
//         ],


//         /*
//         |--------------------------------------------------------------------------
//         | CONNECTED
//         |--------------------------------------------------------------------------
//         */

//         'connected' => [
//             'count' =>
//                 $connectedCount,

//             'leads' =>
//                 $connectedLeads,
//         ],
//     ];


//     return $this->success(
//         $data,
//         'Leads fetched successfully.'
//     );
// }


public function index(Request $request): JsonResponse
{
    $companyId = $this->companyId($request);

    /*
    |--------------------------------------------------------------------------
    | Validation - Web board ke same filters
    |--------------------------------------------------------------------------
    */
    $validated = $request->validate([
        // API compatibility filters
        'lead_id' => [
            'nullable',
            'integer',
            'min:1',
            Rule::exists('leads', 'id')->where(
                fn ($query) => $query
                    ->where('company_id', $companyId)
                    ->whereNull('deleted_at')
            ),
        ],
        'call_disposition_id' => [
            'nullable',
            'integer',
            'min:1',
            Rule::exists('call_dispositions', 'id')->where(
                fn ($query) => $query->where(
                    fn ($scope) => $scope
                        ->whereNull('company_id')
                        ->orWhere('company_id', $companyId)
                )
            ),
        ],
        'call_disposition_type' => ['nullable', 'string', 'max:100'],

        // Global filters
        'search' => ['nullable', 'string', 'max:255'],
        'status' => ['nullable', 'integer'],
        'source' => ['nullable', 'integer'],
        'city' => ['nullable', 'string', 'max:255'],
        'category' => ['nullable', 'string', 'max:255'],
        'assigned_to' => ['nullable', 'string'],
        'team_id' => ['nullable', 'integer'],
        'priority' => ['nullable', Rule::in(['low', 'normal', 'high', 'urgent', 'hot'])],
        'temperature' => ['nullable', Rule::in(['cold', 'warm', 'hot'])],
        'label_id' => ['nullable', 'integer'],
        'demo_send' => ['nullable', 'boolean'],
        'lead_send' => ['nullable', Rule::in(['today', 'all'])],
        'created_filter' => ['nullable', Rule::in(['today'])],
        'date_from' => ['nullable', 'date'],
        'date_to' => ['nullable', 'date', 'after_or_equal:date_from'],

        // Dashboard quick metric - web same
        'quick_metric' => [
            'nullable',
            Rule::in([
                'calls_today',
                'connected_today',
                'employee_total_calls',
                'unique_connected',
                'follow_up',
                'demo_today',
                'total_demo',
            ]),
        ],

        // NEW section filters - web same
        'new_category' => ['nullable', 'string', 'max:255'],
        'new_source' => ['nullable', 'integer'],
        'new_city' => ['nullable', 'string', 'max:255'],
        'new_priority' => ['nullable', Rule::in(['low', 'normal', 'high', 'urgent', 'hot'])],
        'new_assigned_to' => ['nullable', 'string'],
        'new_date_filter' => ['nullable', Rule::in(['today', 'yesterday', 'week', 'month'])],
        'new_disposition_id' => ['nullable', 'string', 'max:50'],
        'new_demo_status' => ['nullable', Rule::in(['sent', 'not_sent'])],
        'new_label_id' => ['nullable', 'integer'],

        // DIALED section filters - web same
        'dialed_category' => ['nullable', 'string', 'max:255'],
        'dialed_source' => ['nullable', 'integer'],
        'dialed_city' => ['nullable', 'string', 'max:255'],
        'dialed_priority' => ['nullable', Rule::in(['low', 'normal', 'high', 'urgent', 'hot'])],
        'dialed_assigned_to' => ['nullable', 'string'],
        'dialed_date_filter' => ['nullable', Rule::in(['today', 'yesterday', 'week', 'month'])],
        'dialed_disposition_id' => ['nullable', 'string', 'max:50'],
        'dialed_demo_status' => ['nullable', Rule::in(['sent', 'not_sent'])],
        'dialed_label_id' => ['nullable', 'integer'],

        // CONNECTED section filters - web same
        'connected_category' => ['nullable', 'string', 'max:255'],
        'connected_source' => ['nullable', 'integer'],
        'connected_city' => ['nullable', 'string', 'max:255'],
        'connected_priority' => ['nullable', Rule::in(['low', 'normal', 'high', 'urgent', 'hot'])],
        'connected_assigned_to' => ['nullable', 'string'],
        'connected_date_filter' => ['nullable', Rule::in(['today', 'yesterday', 'week', 'month'])],
        'connected_disposition_id' => ['nullable', 'string', 'max:50'],
        'connected_demo_status' => ['nullable', Rule::in(['sent', 'not_sent'])],
        'connected_label_id' => ['nullable', 'integer'],

        // Separate pagination - web same
        'new_page' => ['nullable', 'integer', 'min:1'],
        'dialed_page' => ['nullable', 'integer', 'min:1'],
        'connected_page' => ['nullable', 'integer', 'min:1'],
    ]);

    $quickMetric = (string) ($validated['quick_metric'] ?? '');

    /*
    |--------------------------------------------------------------------------
    | Base Request - section filters ko global filteredLeadQuery me mat bhejo
    |--------------------------------------------------------------------------
    */
    $baseRequest = clone $request;

    $sections = ['new', 'dialed', 'connected'];
    $sectionFields = [
        'category',
        'source',
        'city',
        'priority',
        'assigned_to',
        'date_filter',
        'disposition_id',
        'demo_status',
        'label_id',
    ];

    foreach ($sections as $section) {
        foreach ($sectionFields as $field) {
            $key = $section . '_' . $field;
            $baseRequest->query->remove($key);
            $baseRequest->request->remove($key);
        }
    }

    foreach ([
        'new_page',
        'dialed_page',
        'connected_page',
        'page',
        'per_page',
        'call_disposition',
        'quick_metric',
        'lead_id',
        'call_disposition_id',
        'call_disposition_type',
    ] as $key) {
        $baseRequest->query->remove($key);
        $baseRequest->request->remove($key);
    }

    /*
     * Web filteredLeadQuery() me demo_send=0 filter apply nahi hota.
     * API ke existing filteredLeadQuery() me has('demo_send') par false bhi
     * filter hota hai, isliye exact web behavior ke liye false ko remove karo.
     */
    if ($request->has('demo_send') && !$request->boolean('demo_send')) {
        $baseRequest->query->remove('demo_send');
        $baseRequest->request->remove('demo_send');
    }

    /*
    |--------------------------------------------------------------------------
    | Base Accessible Query
    |--------------------------------------------------------------------------
    */
    $baseQuery = $this->filteredLeadQuery($baseRequest);

    /*
     * Web filteredLeadQuery() global city filter support karta hai.
     * API helper me city missing hai, isliye yahan same filter explicitly.
     */
    if ($request->filled('city')) {
        $baseQuery->where(
            'leads.city',
            (string) $request->input('city')
        );
    }

    // API compatibility: exact accessible lead
    if (!empty($validated['lead_id'])) {
        $baseQuery->whereKey((int) $validated['lead_id']);
    }

    /*
    |--------------------------------------------------------------------------
    | Relations / Card Data - web same
    |--------------------------------------------------------------------------
    */
    $relations = [
        'assignedUser:id,name,email,employee_code,team_id',
        'source:id,name',
        'status:id,name,color',
        'team:id,name',
        'stage:id,name,color',
        'labels:id,company_id,name,color',
        'latestCall' => function ($query) {
            $query->with([
                'disposition',
                'user:id,name',
            ]);
        },
        'latestNote.user:id,name',
        'latestFollowUp' => function ($query) {
            $query->with([
                'assignedUser:id,name',
            ]);
        },
    ];

    $prepareQuery = function (Builder $query) use ($relations) {
        return $query
            ->with($relations)
            ->withCount('calls')
            ->addSelect([
                'latest_call_id' => CallLog::query()
                    ->select('id')
                    ->whereColumn('call_logs.lead_id', 'leads.id')
                    ->where(function (Builder $callScope) {
                        $callScope
                            ->where(function (Builder $assigned) {
                                $assigned
                                    ->whereNotNull('leads.assigned_to')
                                    ->whereColumn('call_logs.user_id', 'leads.assigned_to')
                                    ->whereRaw(
                                        'call_logs.created_at >= COALESCE(('
                                        . 'SELECT MAX(la.assigned_at) FROM lead_assignments la '
                                        . 'WHERE la.lead_id = leads.id '
                                        . 'AND la.new_user_id = leads.assigned_to'
                                        . '), leads.created_at)'
                                    );
                            })
                            ->orWhere(function (Builder $unassigned) {
                                $unassigned->whereNull('leads.assigned_to');
                            });
                    })
                    ->latest('call_logs.id')
                    ->limit(1),

                'latest_note_body' => Note::query()
                    ->select('body')
                    ->whereColumn('notes.lead_id', 'leads.id')
                    ->latest('notes.id')
                    ->limit(1),

                'latest_note_created_at' => Note::query()
                    ->select('created_at')
                    ->whereColumn('notes.lead_id', 'leads.id')
                    ->latest('notes.id')
                    ->limit(1),

                'latest_note_user_name' => Note::query()
                    ->leftJoin('users', 'users.id', '=', 'notes.user_id')
                    ->select('users.name')
                    ->whereColumn('notes.lead_id', 'leads.id')
                    ->latest('notes.id')
                    ->limit(1),
            ]);
    };

    /*
    |--------------------------------------------------------------------------
    | Current Assignment State - web applyCurrentAssignmentCallState() same
    |--------------------------------------------------------------------------
    */
    $assignmentBoundarySql =
        "COALESCE((SELECT MAX(la.assigned_at) " .
        "FROM lead_assignments la " .
        "WHERE la.lead_id = leads.id " .
        "AND la.new_user_id = leads.assigned_to), leads.created_at)";

    $currentAssignedCall = function (Builder $calls) use ($assignmentBoundarySql) {
        $calls
            ->whereColumn('call_logs.user_id', 'leads.assigned_to')
            ->whereRaw("call_logs.created_at >= {$assignmentBoundarySql}");
    };

    $applyCurrentAssignmentCallState = function (
        Builder $query,
        string $state
    ) use (
        $assignmentBoundarySql,
        $currentAssignedCall
    ): Builder {

        if ($state === 'new') {
            return $query->where(function (Builder $stateQuery) use ($currentAssignedCall) {
                $stateQuery
                    ->where(function (Builder $assigned) use ($currentAssignedCall) {
                        $assigned
                            ->whereNotNull('leads.assigned_to')
                            ->whereDoesntHave('calls', $currentAssignedCall);
                    })
                    ->orWhere(function (Builder $unassigned) {
                        $unassigned
                            ->whereNull('leads.assigned_to')
                            ->whereDoesntHave('calls');
                    });
            });
        }

        if ($state === 'dialed') {
            return $query->where(function (Builder $stateQuery) use ($currentAssignedCall) {
                $stateQuery
                    ->where(function (Builder $assigned) use ($currentAssignedCall) {
                        $assigned
                            ->whereNotNull('leads.assigned_to')
                            ->whereHas('calls', $currentAssignedCall);
                    })
                    ->orWhere(function (Builder $unassigned) {
                        $unassigned
                            ->whereNull('leads.assigned_to')
                            ->whereHas('calls');
                    });
            });
        }

        if ($state === 'connected') {
            return $query->where(function (Builder $stateQuery) use ($assignmentBoundarySql) {
                $stateQuery
                    ->where(function (Builder $assigned) use ($assignmentBoundarySql) {
                        $assigned
                            ->whereNotNull('leads.assigned_to')
                            ->whereHas('calls', function (Builder $calls) use ($assignmentBoundarySql) {
                                $calls
                                    ->whereColumn('call_logs.user_id', 'leads.assigned_to')
                                    ->whereRaw("call_logs.created_at >= {$assignmentBoundarySql}");

                                if (Schema::hasColumn('call_logs', 'remarks')) {
                                    $calls
                                        ->whereNotNull('remarks')
                                        ->whereRaw("TRIM(COALESCE(call_logs.remarks, '')) <> ''");
                                } elseif (Schema::hasColumn('call_logs', 'remark')) {
                                    $calls
                                        ->whereNotNull('remark')
                                        ->whereRaw("TRIM(COALESCE(call_logs.remark, '')) <> ''");
                                } else {
                                    $calls->whereRaw('1 = 0');
                                }
                            });
                    })
                    ->orWhere(function (Builder $unassigned) {
                        $unassigned
                            ->whereNull('leads.assigned_to')
                            ->whereHas('calls', function (Builder $calls) {
                                if (Schema::hasColumn('call_logs', 'remarks')) {
                                    $calls
                                        ->whereNotNull('remarks')
                                        ->whereRaw("TRIM(COALESCE(call_logs.remarks, '')) <> ''");
                                } elseif (Schema::hasColumn('call_logs', 'remark')) {
                                    $calls
                                        ->whereNotNull('remark')
                                        ->whereRaw("TRIM(COALESCE(call_logs.remark, '')) <> ''");
                                } else {
                                    $calls->whereRaw('1 = 0');
                                }
                            });
                    });
            });
        }

        return $query;
    };

    /*
    |--------------------------------------------------------------------------
    | Optional API global latest disposition filters
    |--------------------------------------------------------------------------
    | Default request par web result ko affect nahi karte.
    */
    $callDispositionId = !empty($validated['call_disposition_id'])
        ? (int) $validated['call_disposition_id']
        : null;

    $callDispositionType = !empty($validated['call_disposition_type'])
        ? strtolower(trim((string) $validated['call_disposition_type']))
        : null;

    if ($callDispositionId !== null || $callDispositionType !== null) {
        $baseQuery->whereHas('calls', function (Builder $calls) use (
            $callDispositionId,
            $callDispositionType,
            $assignmentBoundarySql,
            $companyId
        ) {
            $calls->where(function (Builder $scope) use ($assignmentBoundarySql) {
                $scope
                    ->where(function (Builder $assigned) use ($assignmentBoundarySql) {
                        $assigned
                            ->whereNotNull('leads.assigned_to')
                            ->whereColumn('call_logs.user_id', 'leads.assigned_to')
                            ->whereRaw("call_logs.created_at >= {$assignmentBoundarySql}");
                    })
                    ->orWhere(function (Builder $unassigned) {
                        $unassigned->whereNull('leads.assigned_to');
                    });
            });

            $calls->where('call_logs.company_id', $companyId);

            if ($callDispositionId !== null) {
                $calls->where('call_logs.call_disposition_id', $callDispositionId);
            }

            if ($callDispositionType !== null) {
                $calls->whereHas('disposition', function (Builder $disposition) use (
                    $callDispositionType,
                    $companyId
                ) {
                    $disposition
                        ->whereRaw('LOWER(call_dispositions.type) = ?', [$callDispositionType])
                        ->where(function (Builder $scope) use ($companyId) {
                            $scope
                                ->whereNull('call_dispositions.company_id')
                                ->orWhere('call_dispositions.company_id', $companyId);
                        });
                });
            }

            $calls->whereRaw(
                "call_logs.id = (
                    SELECT MAX(cl_latest.id)
                    FROM call_logs AS cl_latest
                    WHERE cl_latest.lead_id = call_logs.lead_id
                    AND (
                        (
                            leads.assigned_to IS NOT NULL
                            AND cl_latest.user_id = leads.assigned_to
                            AND cl_latest.created_at >= {$assignmentBoundarySql}
                        )
                        OR leads.assigned_to IS NULL
                    )
                )"
            );
        });
    }

    /*
    |--------------------------------------------------------------------------
    | Section Filters - web applyBoardFilters() same
    |--------------------------------------------------------------------------
    */
    $applySectionFilters = function (
        Builder $query,
        string $section
    ) use (
        $request,
        $companyId,
        $assignmentBoundarySql,
        $applyCurrentAssignmentCallState
    ): Builder {

        $categoryKey = $section . '_category';
        if ($request->filled($categoryKey)) {
            $query->where('leads.category', (string) $request->input($categoryKey));
        }

        $sourceKey = $section . '_source';
        if ($request->filled($sourceKey)) {
            $query->where('leads.source_id', (int) $request->input($sourceKey));
        }

        $cityKey = $section . '_city';
        if ($request->filled($cityKey)) {
            $query->where('leads.city', (string) $request->input($cityKey));
        }

        $priorityKey = $section . '_priority';
        if ($request->filled($priorityKey)) {
            $priority = (string) $request->input($priorityKey);
            if (in_array($priority, ['low', 'normal', 'high', 'urgent', 'hot'], true)) {
                $query->where('leads.priority', $priority);
            }
        }

        $assignedKey = $section . '_assigned_to';
        if ($request->filled($assignedKey)) {
            $query->where('leads.assigned_to', (int) $request->input($assignedKey));
        }

        $dateKey = $section . '_date_filter';
        if ($request->filled($dateKey)) {
            $dateFilter = (string) $request->input($dateKey);

            switch ($dateFilter) {
                case 'today':
                    $query->whereDate('leads.created_at', today());
                    break;

                case 'yesterday':
                    $query->whereDate('leads.created_at', today()->subDay());
                    break;

                case 'week':
                    $query->whereBetween('leads.created_at', [
                        now()->startOfWeek(),
                        now()->endOfWeek(),
                    ]);
                    break;

                case 'month':
                    $query
                        ->whereYear('leads.created_at', now()->year)
                        ->whereMonth('leads.created_at', now()->month);
                    break;
            }
        }

        $dispositionKey = $section . '_disposition_id';
        if ($request->filled($dispositionKey)) {
            $dispositionValue = (string) $request->input($dispositionKey);

            if ($dispositionValue === 'none') {
                $applyCurrentAssignmentCallState($query, 'new');
            } elseif (ctype_digit($dispositionValue) && (int) $dispositionValue > 0) {
                $dispositionId = (int) $dispositionValue;

                $validDisposition = CallDisposition::query()
                    ->whereKey($dispositionId)
                    ->where('is_active', true)
                    ->where(function (Builder $dispositionQuery) use ($companyId) {
                        $dispositionQuery
                            ->whereNull('company_id')
                            ->orWhere('company_id', $companyId);
                    })
                    ->exists();

                if ($validDisposition) {
                    $query->where(function (Builder $scope) use (
                        $dispositionId,
                        $assignmentBoundarySql
                    ) {
                        $scope
                            ->where(function (Builder $assigned) use (
                                $dispositionId,
                                $assignmentBoundarySql
                            ) {
                                $assigned
                                    ->whereNotNull('leads.assigned_to')
                                    ->whereExists(function ($subQuery) use (
                                        $dispositionId,
                                        $assignmentBoundarySql
                                    ) {
                                        $subQuery
                                            ->selectRaw('1')
                                            ->from('call_logs as cl')
                                            ->whereColumn('cl.lead_id', 'leads.id')
                                            ->whereColumn('cl.user_id', 'leads.assigned_to')
                                            ->whereRaw("cl.created_at >= {$assignmentBoundarySql}")
                                            ->where('cl.call_disposition_id', $dispositionId)
                                            ->whereRaw(
                                                'cl.id = (SELECT MAX(cl2.id) FROM call_logs cl2 '
                                                . 'WHERE cl2.lead_id = leads.id '
                                                . 'AND cl2.user_id = leads.assigned_to '
                                                . "AND cl2.created_at >= {$assignmentBoundarySql})"
                                            );
                                    });
                            })
                            ->orWhere(function (Builder $unassigned) use ($dispositionId) {
                                $unassigned
                                    ->whereNull('leads.assigned_to')
                                    ->whereHas('calls', function (Builder $calls) use ($dispositionId) {
                                        $calls
                                            ->where('call_disposition_id', $dispositionId)
                                            ->whereRaw(
                                                'call_logs.id = (SELECT MAX(cl2.id) FROM call_logs cl2 '
                                                . 'WHERE cl2.lead_id = leads.id)'
                                            );
                                    });
                            });
                    });
                }
            }
        }

        $demoKey = $section . '_demo_status';
        if ($request->filled($demoKey)) {
            $demoStatus = (string) $request->input($demoKey);

            if ($demoStatus === 'sent') {
                $query->where('leads.demo_send', true);
            } elseif ($demoStatus === 'not_sent') {
                $query->where(function (Builder $demoQuery) {
                    $demoQuery
                        ->where('leads.demo_send', false)
                        ->orWhereNull('leads.demo_send');
                });
            }
        }

        $labelKey = $section . '_label_id';
        if ($request->filled($labelKey)) {
            $labelId = (int) $request->input($labelKey);

            $validLabel = LeadLabel::query()
                ->whereKey($labelId)
                ->where('company_id', $companyId)
                ->exists();

            if ($validLabel) {
                $query->whereHas('labels', function (Builder $labelQuery) use ($labelId) {
                    $labelQuery->where('lead_labels.id', $labelId);
                });
            }
        }

        return $query;
    };

    /*
    |--------------------------------------------------------------------------
    | Quick Metric Filter - web same
    |--------------------------------------------------------------------------
    */
    $applyQuickMetricFilter = function (
        Builder $query,
        string $metric,
        string $section
    ): Builder {
        if ($metric === '') {
            return $query;
        }

        switch ($metric) {
            case 'calls_today':
                $query->whereHas('calls', function (Builder $calls) {
                    $calls->whereDate('call_logs.created_at', today());
                });
                break;

            case 'connected_today':
                if ($section !== 'connected') {
                    $query->whereRaw('1 = 0');
                    break;
                }
                $query->whereHas('calls', function (Builder $calls) {
                    $calls->whereDate('call_logs.created_at', today());
                });
                break;

            case 'employee_total_calls':
                if ($section !== 'dialed') {
                    $query->whereRaw('1 = 0');
                }
                break;

            case 'unique_connected':
                if ($section !== 'connected') {
                    $query->whereRaw('1 = 0');
                }
                break;

            case 'follow_up':
                $query->whereNotNull('leads.next_follow_up_at');
                break;

            case 'demo_today':
                $query
                    ->where('leads.demo_send', true)
                    ->whereNotNull('leads.demo_sent_at')
                    ->whereDate('leads.demo_sent_at', today());
                break;

            case 'total_demo':
                $query->where('leads.demo_send', true);
                break;
        }

        return $query;
    };

    /*
    |--------------------------------------------------------------------------
    | NEW / DIALED / CONNECTED - web same order of operations
    |--------------------------------------------------------------------------
    */
    $newQuery = clone $baseQuery;
    $applyCurrentAssignmentCallState($newQuery, 'new');
    $applySectionFilters($newQuery, 'new');
    $applyQuickMetricFilter($newQuery, $quickMetric, 'new');

    $dialedQuery = clone $baseQuery;
    $applyCurrentAssignmentCallState($dialedQuery, 'dialed');
    $applySectionFilters($dialedQuery, 'dialed');
    $applyQuickMetricFilter($dialedQuery, $quickMetric, 'dialed');

    $connectedQuery = clone $baseQuery;
    $applyCurrentAssignmentCallState($connectedQuery, 'connected');
    $applySectionFilters($connectedQuery, 'connected');
    $applyQuickMetricFilter($connectedQuery, $quickMetric, 'connected');

    $newCount = (clone $newQuery)->count();
    $dialedCount = (clone $dialedQuery)->count();
    $connectedCount = (clone $connectedQuery)->count();
    $totalCount = (clone $baseQuery)->count();

    /*
    |--------------------------------------------------------------------------
    | Pagination / Sorting - EXACT WEB SAME
    |--------------------------------------------------------------------------
    |
    | Web me fixed 10 records/page hain.
    | NEW: leads.id DESC
    | DIALED/CONNECTED: latest_call_id DESC, leads.id DESC
    |
    */
    $boardLimit = 10;

    $newLeads = $prepareQuery(clone $newQuery)
        ->orderByDesc('leads.id')
        ->paginate(
            $boardLimit,
            ['*'],
            'new_page'
        )
        ->withQueryString();

    $dialedLeads = $prepareQuery(clone $dialedQuery)
        ->orderByDesc('latest_call_id')
        ->orderByDesc('leads.id')
        ->paginate(
            $boardLimit,
            ['*'],
            'dialed_page'
        )
        ->withQueryString();

    $connectedLeads = $prepareQuery(clone $connectedQuery)
        ->orderByDesc('latest_call_id')
        ->orderByDesc('leads.id')
        ->paginate(
            $boardLimit,
            ['*'],
            'connected_page'
        )
        ->withQueryString();

    return $this->success([
        'counts' => [
            'new' => $newCount,
            'dialed' => $dialedCount,
            'connected' => $connectedCount,
            'total' => $totalCount,
        ],

        'new' => [
            'count' => $newCount,
            'leads' => $newLeads,
        ],

        'dialed' => [
            'count' => $dialedCount,
            'leads' => $dialedLeads,
        ],

        'connected' => [
            'count' => $connectedCount,
            'leads' => $connectedLeads,
        ],
    ], 'Leads fetched successfully.');
}







    public function options(Request $request): JsonResponse
    {
        $companyId = $this->companyId($request);
        $hasFullAccess = $this->hasFullAccess($request);
        $leaderTeamIds = $this->leaderTeamIds($request);

        $users = User::query()
            ->where('company_id', $companyId)
            ->where('is_active', true)
            ->when(!$hasFullAccess, function (Builder $query) use ($request, $leaderTeamIds) {
                $query->where(function (Builder $q) use ($request, $leaderTeamIds) {
                    $q->whereKey($request->user()->id);
                    if ($leaderTeamIds !== []) {
                        $q->orWhereIn('team_id', $leaderTeamIds);
                    }
                });
            })
            ->orderBy('name')
            ->get(['id', 'name', 'email', 'employee_code', 'team_id']);

        $teams = Team::query()
            ->where('company_id', $companyId)
            ->when(!$hasFullAccess && $leaderTeamIds !== [], fn(Builder $q) => $q->whereIn('id', $leaderTeamIds))
            ->when(!$hasFullAccess && $leaderTeamIds === [], fn(Builder $q) => $q->whereRaw('1 = 0'))
            ->orderBy('name')->get(['id', 'name']);

        $companyOrGlobal = fn(Builder $q) => $q->where(fn(Builder $x) => $x->whereNull('company_id')->orWhere('company_id', $companyId));

        return $this->success([
            'sources' => LeadSource::query()->where($companyOrGlobal)->where('is_active', true)->orderBy('name')->get(),
            'statuses' => LeadStatus::query()->where($companyOrGlobal)->where('is_active', true)->orderBy('sort_order')->orderBy('name')->get(),
            'dispositions' => CallDisposition::query()->where($companyOrGlobal)->where('is_active', true)->orderBy('name')->get(),
            'users' => $users,
            'teams' => $teams,
            'stages' => PipelineStage::query()->whereHas('pipeline', fn(Builder $q) => $q->where('company_id', $companyId))->orderBy('sort_order')->get(),
            'labels' => LeadLabel::query()->where('company_id', $companyId)->withCount('leads')->orderBy('name')->get(),
            'categories' => Lead::query()->where('company_id', $companyId)->whereNotNull('category')->where('category', '<>', '')->distinct()->orderBy('category')->pluck('category'),
            'access' => [
                'full_access' => $hasFullAccess,
                'team_leader' => !$hasFullAccess && $leaderTeamIds !== [],
                'can_assign' => $hasFullAccess,
            ],
        ], 'Lead form data fetched successfully.');
    }

    public function store(Request $request): JsonResponse
    {
        $companyId = $this->companyId($request);
        $validated = $this->validateData($request);

        if (!$this->hasFullAccess($request)) {
            $validated['assigned_to'] = (int) $request->user()->id;
        }

        $validated['pipeline_stage_id'] ??= $this->defaultPipelineStageId($companyId);
        $validated['company_id'] = $companyId;
        $validated['created_by'] = (int) $request->user()->id;
        $validated['priority'] ??= 'normal';
        $validated['temperature'] ??= 'cold';

        $lead = DB::transaction(function () use ($validated, $request, $companyId) {
            $lead = Lead::create($validated);
            if (!empty($validated['assigned_to'])) {
                $this->createAssignmentHistory($lead, null, (int) $validated['assigned_to'], (int) $request->user()->id, 'Lead assigned during creation', $companyId);
            }
            return $lead;
        });

        return $this->success($this->loadLead($lead), 'Lead created successfully.', 201);
    }

    public function show(Request $request, Lead $lead): JsonResponse
    {
        $this->guard($request, $lead);
        return $this->success($this->loadLead($lead), 'Lead fetched successfully.');
    }

    public function update(Request $request, Lead $lead): JsonResponse
    {
        $this->guard($request, $lead);

        if ($request->boolean('demo_send_only')) {
            $data = $request->validate(['demo_send' => ['required', 'boolean']]);
            $enabled = (bool) $data['demo_send'];
            $lead->update([
                'demo_send' => $enabled,
                'demo_sent_at' => $enabled ? ($lead->demo_sent_at ?? now()) : null,
            ]);
            return $this->success($this->loadLead($lead->fresh()), $enabled ? 'Lead marked as Demo Send.' : 'Demo Send mark removed.');
        }

        $validated = $this->validateData($request, $lead);
        if (!$this->hasFullAccess($request)) {
            $validated['assigned_to'] = $lead->assigned_to;
        }

        $oldUserId = $lead->assigned_to ? (int) $lead->assigned_to : null;
        $newUserId = !empty($validated['assigned_to']) ? (int) $validated['assigned_to'] : null;

        DB::transaction(function () use ($lead, $validated, $oldUserId, $newUserId, $request) {
            $lead->update($validated);
            if ($this->hasFullAccess($request) && $oldUserId !== $newUserId && $newUserId !== null) {
                $this->createAssignmentHistory($lead, $oldUserId, $newUserId, (int) $request->user()->id, 'Lead owner changed from API', $this->companyId($request));
            }
        });

        return $this->success($this->loadLead($lead->fresh()), 'Lead updated successfully.');
    }

    public function destroy(Request $request, Lead $lead): JsonResponse
    {
        $this->ensureFullAccess($request);
        $this->guardCompany($request, $lead);
        $lead->delete();
        return $this->success(null, 'Lead moved to trash.');
    }

    public function assign(Request $request, Lead $lead): JsonResponse
    {
        $this->ensureFullAccess($request);
        $this->guardCompany($request, $lead);
        $companyId = $this->companyId($request);
        $validated = $request->validate([
            'assigned_to' => ['required', 'integer', Rule::exists('users', 'id')->where(fn($q) => $q->where('company_id', $companyId)->where('is_active', true))],
            'reason' => ['required', 'string', 'max:500'],
        ]);

        $old = $lead->assigned_to ? (int) $lead->assigned_to : null;
        $new = (int) $validated['assigned_to'];
        if ($old === $new) {
            return $this->error('Lead is already assigned to this employee.', 422);
        }

        DB::transaction(function () use ($lead, $old, $new, $validated, $request, $companyId) {
            $lead->update(['assigned_to' => $new]);
            $this->createAssignmentHistory($lead, $old, $new, (int) $request->user()->id, $validated['reason'], $companyId);
        });

        return $this->success($this->loadLead($lead->fresh()), 'Lead assigned successfully.');
    }

    public function bulkAssign(Request $request): JsonResponse
    {
        $this->ensureFullAccess($request);
        $companyId = $this->companyId($request);
        $validated = $request->validate([
            'lead_ids' => ['required', 'array', 'min:1'],
            'lead_ids.*' => ['integer', Rule::exists('leads', 'id')->where(fn($q) => $q->where('company_id', $companyId)->whereNull('deleted_at'))],
            'action' => ['required', Rule::in(['assign', 'unassign'])],
            'assigned_to' => ['nullable', 'required_if:action,assign', 'integer', Rule::exists('users', 'id')->where(fn($q) => $q->where('company_id', $companyId)->where('is_active', true))],
            'reason' => ['required', 'string', 'max:500'],
        ]);

        $leads = Lead::query()->where('company_id', $companyId)->whereIn('id', $validated['lead_ids'])->get();
        $updated = 0;
        $skipped = 0;

        DB::transaction(function () use ($leads, $validated, $request, $companyId, &$updated, &$skipped) {
            foreach ($leads as $lead) {
                $old = $lead->assigned_to ? (int) $lead->assigned_to : null;
                if ($validated['action'] === 'unassign') {
                    if ($old === null) {
                        $skipped++;
                        continue;
                    }
                    $lead->update(['assigned_to' => null]);
                    $updated++;
                    continue;
                }
                $new = (int) $validated['assigned_to'];
                if ($old === $new) {
                    $skipped++;
                    continue;
                }
                $lead->update(['assigned_to' => $new]);
                $this->createAssignmentHistory($lead, $old, $new, (int) $request->user()->id, $validated['reason'], $companyId);
                $updated++;
            }
        });

        return $this->success(['updated_count' => $updated, 'skipped_count' => $skipped], 'Bulk action completed successfully.');
    }

    public function addNote(Request $request, Lead $lead): JsonResponse
    {
        $this->guard($request, $lead);
        $validated = $request->validate(['body' => ['required', 'string', 'max:3000']]);
        $note = Note::create(['lead_id' => $lead->id, 'user_id' => $request->user()->id, 'body' => trim($validated['body'])]);
        $note->load('user:id,name,email');
        return $this->success($note, 'Note added successfully.', 201);
    }

    public function storeLabel(Request $request): JsonResponse
    {
        $companyId = $this->companyId($request);
        $validated = $request->validate([
            'name' => ['required', 'string', 'max:100', Rule::unique('lead_labels', 'name')->where(fn($q) => $q->where('company_id', $companyId))],
            'color' => ['required', 'regex:/^#[0-9A-Fa-f]{6}$/'],
        ]);
        $label = LeadLabel::create(['company_id' => $companyId, 'name' => trim($validated['name']), 'color' => strtoupper($validated['color']), 'created_by' => $request->user()->id]);
        return $this->success($label, 'Label created successfully.', 201);
    }

    public function addLabel(Request $request, Lead $lead): JsonResponse
    {
        $this->guard($request, $lead);
        $companyId = $this->companyId($request);
        $validated = $request->validate(['label_id' => ['required', 'integer', Rule::exists('lead_labels', 'id')->where(fn($q) => $q->where('company_id', $companyId))]]);
        $lead->labels()->syncWithoutDetaching([(int) $validated['label_id']]);
        return $this->success($lead->labels()->get(), 'Label added to lead successfully.');
    }

    public function removeLabel(Request $request, Lead $lead, LeadLabel $label): JsonResponse
    {
        $this->guard($request, $lead);
        abort_unless((int) $label->company_id === $this->companyId($request), 403);
        $lead->labels()->detach($label->id);
        return $this->success(null, 'Label removed from lead.');
    }

    public function destroyLabel(Request $request, LeadLabel $label): JsonResponse
    {
        $this->ensureFullAccess($request);
        abort_unless((int) $label->company_id === $this->companyId($request), 403);
        $label->delete();
        return $this->success(null, 'Label deleted successfully.');
    }

    private function filteredLeadQuery(Request $request): Builder
    {
        $companyId = $this->companyId($request);
        $user = $request->user();
        $full = $this->hasFullAccess($request);
        $leaderTeamIds = $full ? [] : $this->leaderTeamIds($request);
        $query = Lead::query()->where('company_id', $companyId);

        if (!$full) {
            $query->where(function (Builder $q) use ($user, $companyId, $leaderTeamIds) {
                $q->where('assigned_to', $user->id);
                if ($leaderTeamIds !== []) {
                    $q->orWhereIn('assigned_to', User::query()->select('id')->where('company_id', $companyId)->whereIn('team_id', $leaderTeamIds));
                }
            });
        }

        if ($request->filled('search')) {
            $search = trim((string) $request->search);
            $query->where(fn(Builder $q) => $q->where('name', 'like', "%{$search}%")
                ->orWhere('mobile', 'like', "%{$search}%")->orWhere('alternate_mobile', 'like', "%{$search}%")
                ->orWhere('whatsapp_number', 'like', "%{$search}%")->orWhere('company_name', 'like', "%{$search}%")
                ->orWhere('email', 'like', "%{$search}%")->orWhere('city', 'like', "%{$search}%")->orWhere('category', 'like', "%{$search}%"));
        }

        $query->when($request->filled('status'), fn(Builder $q) => $q->where('lead_status_id', $request->status));
        $query->when($request->filled('source'), fn(Builder $q) => $q->where('lead_source_id', $request->source));
        $query->when($request->filled('category'), fn(Builder $q) => $q->where('category', trim((string) $request->category)));

        if (($full || $leaderTeamIds !== []) && $request->filled('assigned_to')) {
            $assigned = (string) $request->assigned_to;
            if ($assigned === 'unassigned' && $full) $query->whereNull('assigned_to');
            elseif (ctype_digit($assigned)) $query->where('assigned_to', (int) $assigned);
            else $query->whereRaw('1 = 0');
        }

        if ($request->filled('team_id')) {
            $teamId = (int) $request->team_id;
            $query->where(fn(Builder $q) => $q->where('team_id', $teamId)->orWhereIn('assigned_to', User::query()->select('id')->where('company_id', $companyId)->where('team_id', $teamId)));
        }

        $query->when($request->filled('priority'), fn(Builder $q) => $q->where('priority', $request->priority));
        $query->when($request->filled('temperature'), fn(Builder $q) => $q->where('temperature', $request->temperature));
        $query->when($request->filled('label_id'), fn(Builder $q) => $q->whereHas('labels', fn(Builder $x) => $x->where('lead_labels.id', (int) $request->label_id)));

        if ($request->filled('call_disposition')) {
            $value = (string) $request->call_disposition;
            if ($value === 'no_call') $query->whereDoesntHave('calls');
            elseif (ctype_digit($value)) {
                $id = (int) $value;
                $query->whereHas('calls', fn(Builder $q) => $q->where('call_disposition_id', $id)->whereRaw('call_logs.id = (SELECT MAX(c.id) FROM call_logs c WHERE c.lead_id = leads.id)'));
            } else $query->whereRaw('1 = 0');
        }

        if ($request->has('demo_send')) $query->where('demo_send', $request->boolean('demo_send'));
        if ($request->lead_send === 'today') $query->where('demo_send', true)->whereDate('demo_sent_at', today());
        elseif ($request->lead_send === 'all') $query->where('demo_send', true);
        if ($request->created_filter === 'today') $query->whereDate('created_at', today());
        $query->when($request->filled('date_from'), fn(Builder $q) => $q->whereDate('created_at', '>=', $request->date_from));
        $query->when($request->filled('date_to'), fn(Builder $q) => $q->whereDate('created_at', '<=', $request->date_to));
        return $query;
    }

    private function validateData(Request $request, ?Lead $lead = null): array
    {
        $companyId = $this->companyId($request);
        return $request->validate([
            'name' => ['required', 'string', 'max:255'],
            'mobile' => ['required', 'string', 'max:20', Rule::unique('leads', 'mobile')->where(fn($q) => $q->where('company_id', $companyId))->ignore($lead?->id)],
            'alternate_mobile' => ['nullable', 'string', 'max:20'],
            'whatsapp_number' => ['nullable', 'string', 'max:20'],
            'email' => ['nullable', 'email', 'max:255'],
            'company_name' => ['nullable', 'string', 'max:255'],
            'category' => ['nullable', 'string', 'max:255'],
            'lead_source_id' => ['required', 'integer', Rule::exists('lead_sources', 'id')->where(fn($q) => $q->whereNull('company_id')->orWhere('company_id', $companyId))],
            'lead_status_id' => ['required', 'integer', Rule::exists('lead_statuses', 'id')->where(fn($q) => $q->whereNull('company_id')->orWhere('company_id', $companyId))],
            'assigned_to' => ['nullable', 'integer', Rule::exists('users', 'id')->where(fn($q) => $q->where('company_id', $companyId)->where('is_active', true))],
            'team_id' => ['nullable', 'integer', Rule::exists('teams', 'id')->where(fn($q) => $q->where('company_id', $companyId))],
            'pipeline_stage_id' => ['nullable', 'integer', Rule::exists('pipeline_stages', 'id')->where(fn($q) => $q->whereIn('pipeline_id', Pipeline::query()->select('id')->where('company_id', $companyId)))],
            'priority' => ['sometimes', Rule::in(['low', 'normal', 'high', 'urgent', 'hot'])],
            'temperature' => ['sometimes', Rule::in(['cold', 'warm', 'hot'])],
            'preferred_language' => ['nullable', 'string', 'max:50'],
            'address' => ['nullable', 'string', 'max:5000'],
            'city' => ['nullable', 'string', 'max:100'],
            'district' => ['nullable', 'string', 'max:100'],
            'state' => ['nullable', 'string', 'max:100'],
            'pincode' => ['nullable', 'string', 'max:10'],
            'required_product' => ['nullable', 'string', 'max:255'],
            'estimated_budget' => ['nullable', 'numeric', 'min:0'],
            'expected_deal_value' => ['nullable', 'numeric', 'min:0'],
            'expected_closing_date' => ['nullable', 'date'],
            'next_follow_up_at' => ['nullable', 'date'],
        ]);
    }

    private function loadLead(Lead $lead): Lead
    {
        return $lead->load(['assignedUser', 'source', 'status', 'stage', 'team', 'labels', 'calls.user', 'calls.disposition', 'followUps.assignedUser', 'notes.user', 'assignments']);
    }

    private function defaultPipelineStageId(int $companyId): ?int
    {
        $pipeline = Pipeline::query()->where('company_id', $companyId)->orderByDesc('is_default')->orderBy('id')->first();
        return $pipeline ? PipelineStage::query()->where('pipeline_id', $pipeline->id)->orderBy('sort_order')->orderBy('id')->value('id') : null;
    }

    private function createAssignmentHistory(Lead $lead, ?int $previousUserId, int $newUserId, int $assignedBy, string $reason, int $companyId): void
    {
        LeadAssignment::create(['company_id' => $companyId, 'lead_id' => $lead->id, 'previous_user_id' => $previousUserId, 'new_user_id' => $newUserId, 'assigned_by' => $assignedBy, 'reason' => $reason, 'assigned_at' => now()]);
    }

    private function companyId(Request $request): int
    {
        $companyId = (int) $request->user()->company_id;
        abort_if($companyId < 1, 403, 'No company is assigned to this user.');
        return $companyId;
    }

    private function leaderTeamIds(Request $request): array
    {
        return Team::query()->where('company_id', $this->companyId($request))->where('leader_id', $request->user()->id)->pluck('id')->map(fn($id) => (int) $id)->all();
    }

    private function hasFullAccess(Request $request): bool
    {
        return $request->user()->hasAnyRole($this->fullAccessRoles);
    }

    private function ensureFullAccess(Request $request): void
    {
        abort_unless($this->hasFullAccess($request), 403, 'You do not have permission to manage leads.');
    }

    private function guardCompany(Request $request, Lead $lead): void
    {
        abort_unless((int) $lead->company_id === $this->companyId($request), 403, 'Unauthorized company lead access.');
    }

    private function guard(Request $request, Lead $lead): void
    {
        $this->guardCompany($request, $lead);
        if ($this->hasFullAccess($request) || (int) $lead->assigned_to === (int) $request->user()->id) return;
        $allowed = User::query()->where('company_id', $this->companyId($request))->whereKey($lead->assigned_to)->whereIn('team_id', $this->leaderTeamIds($request))->exists();
        abort_unless($allowed, 403, 'This lead is not assigned to you or your team.');
    }

    private function success(mixed $data, string $message, int $code = 200): JsonResponse
    {
        return response()->json(['status' => true, 'message' => $message, 'data' => $data], $code);
    }

    private function error(string $message, int $code): JsonResponse
    {
        return response()->json(['status' => false, 'message' => $message, 'data' => null], $code);
    }




    /*
|--------------------------------------------------------------------------
| Lead Complete Communication History
|--------------------------------------------------------------------------
|
| Is API se lead ke:
| - Saare notes
| - Saare call logs
| - Call remarks
| - Call dispositions
| - Kis user ne baat/note add kiya
| - Combined timeline
|
| mil jayegi.
|
*/

public function communicationHistory(
    Request $request,
    Lead $lead
): JsonResponse {
    /*
    |--------------------------------------------------------------------------
    | Lead Access Security
    |--------------------------------------------------------------------------
    |
    | Admin/Super Admin    : company ki lead
    | Team Leader          : apni team ki lead
    | Employee             : khud assigned lead
    |
    */

    $this->guard($request, $lead);

    /*
    |--------------------------------------------------------------------------
    | Request Validation
    |--------------------------------------------------------------------------
    */

    $validated = $request->validate([
        'per_page' => [
            'nullable',
            'integer',
            'min:1',
            'max:100',
        ],

        'type' => [
            'nullable',
            Rule::in([
                'all',
                'calls',
                'notes',
            ]),
        ],
    ]);

    $perPage = (int) ($validated['per_page'] ?? 50);
    $historyType = $validated['type'] ?? 'all';

    /*
    |--------------------------------------------------------------------------
    | Basic Lead Details
    |--------------------------------------------------------------------------
    */

    $lead->load([
        'assignedUser:id,name,email,employee_code',
        'source:id,name',
        'status:id,name,color',
        'team:id,name',
        'stage:id,name,color',
    ]);

    /*
    |--------------------------------------------------------------------------
    | Notes
    |--------------------------------------------------------------------------
    */

    $notes = collect();

    if (
        $historyType === 'all'
        || $historyType === 'notes'
    ) {
        $notes = Note::query()
            ->where('lead_id', $lead->id)
            ->with([
                'user:id,name,email,employee_code',
            ])
            ->latest('id')
            ->get()
            ->map(function (Note $note) {
                return [
                    'id' => $note->id,

                    'type' => 'note',

                    'lead_id' => $note->lead_id,

                    'body' => $note->body,

                    'user_id' => $note->user_id,

                    'user' => $note->user
                        ? [
                            'id' => $note->user->id,
                            'name' => $note->user->name,
                            'email' => $note->user->email,
                            'employee_code' =>
                                $note->user->employee_code,
                        ]
                        : null,

                    'created_at' => $note->created_at,

                    'updated_at' => $note->updated_at,

                    /*
                     * Combined timeline ko sort karne ke liye.
                     */
                    'activity_at' => $note->created_at,
                ];
            });
    }

    /*
    |--------------------------------------------------------------------------
    | Call Logs and Remarks
    |--------------------------------------------------------------------------
    */

    $calls = collect();

    if (
        $historyType === 'all'
        || $historyType === 'calls'
    ) {
        $calls = $lead->calls()
            ->with([
                'user:id,name,email,employee_code',
                'disposition:id,name',
            ])
            ->latest('id')
            ->get()
            ->map(function ($call) {
                /*
                |--------------------------------------------------------------------------
                | Remark Column Compatibility
                |--------------------------------------------------------------------------
                |
                | Alag projects me column ka naam:
                |
                | remarks
                | remark
                | notes
                | call_remark
                |
                | ho sakta hai. Jo available hoga wahi response me jayega.
                |
                */

                $remark =
                    $call->remarks
                    ?? $call->remark
                    ?? $call->call_remark
                    ?? $call->notes
                    ?? null;

                /*
                |--------------------------------------------------------------------------
                | Call Date Compatibility
                |--------------------------------------------------------------------------
                */

                $calledAt =
                    $call->called_at
                    ?? $call->started_at
                    ?? $call->call_started_at
                    ?? $call->created_at;

                /*
                |--------------------------------------------------------------------------
                | Call Duration Compatibility
                |--------------------------------------------------------------------------
                */

                $duration =
                    $call->duration_seconds
                    ?? $call->duration
                    ?? $call->call_duration
                    ?? 0;

                /*
                |--------------------------------------------------------------------------
                | Recording Compatibility
                |--------------------------------------------------------------------------
                */

                $recording =
                    $call->recording_url
                    ?? $call->recording_path
                    ?? $call->audio_url
                    ?? null;

                return [
                    'id' => $call->id,

                    'type' => 'call',

                    'lead_id' => $call->lead_id,

                    'user_id' => $call->user_id,

                    'call_disposition_id' =>
                        $call->call_disposition_id,

                    'disposition' => $call->disposition
                        ? [
                            'id' => $call->disposition->id,
                            'name' => $call->disposition->name,
                        ]
                        : null,

                    'call_type' =>
                        $call->call_type
                        ?? $call->direction
                        ?? null,

                    'phone_number' =>
                        $call->phone_number
                        ?? $call->mobile
                        ?? null,

                    'remark' => $remark,

                    'duration_seconds' => (int) $duration,

                    'called_at' => $calledAt,

                    'recording_url' => $recording,

                    'user' => $call->user
                        ? [
                            'id' => $call->user->id,
                            'name' => $call->user->name,
                            'email' => $call->user->email,
                            'employee_code' =>
                                $call->user->employee_code,
                        ]
                        : null,

                    'created_at' => $call->created_at,

                    'updated_at' => $call->updated_at,

                    /*
                     * Combined timeline ko sort karne ke liye.
                     */
                    'activity_at' => $calledAt,
                ];
            });
    }

    /*
    |--------------------------------------------------------------------------
    | Combined Timeline
    |--------------------------------------------------------------------------
    |
    | Notes aur calls ko ek saath date/time ke hisaab se latest first.
    |
    */

    $timeline = $notes
        ->concat($calls)
        ->sortByDesc(function (array $history) {
            return optional(
                \Illuminate\Support\Carbon::parse(
                    $history['activity_at']
                )
            )->timestamp;
        })
        ->values();

    /*
    |--------------------------------------------------------------------------
    | Manual Pagination
    |--------------------------------------------------------------------------
    */

    $currentPage = max(
        1,
        (int) $request->input('page', 1)
    );

    $total = $timeline->count();

    $paginatedTimeline = $timeline
        ->forPage(
            $currentPage,
            $perPage
        )
        ->values();

    $lastPage = max(
        1,
        (int) ceil($total / $perPage)
    );

    /*
    |--------------------------------------------------------------------------
    | Final Response
    |--------------------------------------------------------------------------
    */

    return response()->json([
        'status' => true,

        'message' =>
            'Lead communication history fetched successfully.',

        'data' => [
            'lead' => [
                'id' => $lead->id,
                'name' => $lead->name,
                'company_name' => $lead->company_name,
                'mobile' => $lead->mobile,
                'alternate_mobile' =>
                    $lead->alternate_mobile,
                'whatsapp_number' =>
                    $lead->whatsapp_number,
                'email' => $lead->email,

                'assigned_user' =>
                    $lead->assignedUser,

                'source' => $lead->source,

                'status' => $lead->status,

                'team' => $lead->team,

                'stage' => $lead->stage,
            ],

            'summary' => [
                'total_calls' =>
                    $lead->calls()->count(),

                'total_notes' =>
                    $lead->notes()->count(),

                'total_communications' =>
                    $lead->calls()->count()
                    + $lead->notes()->count(),

                'last_call_at' =>
                    $lead->calls()
                        ->latest('id')
                        ->value('created_at'),

                'last_note_at' =>
                    $lead->notes()
                        ->latest('id')
                        ->value('created_at'),
            ],

            'timeline' => [
                'current_page' => $currentPage,
                'last_page' => $lastPage,
                'per_page' => $perPage,
                'total' => $total,
                'data' => $paginatedTimeline,
            ],
        ],
    ]);




}





// public function saveCallResult(
//     Request $request,
//     Lead $lead
// ): JsonResponse {
//     $this->guard($request, $lead);

//     $companyId = $this->companyId($request);
//     $userId = (int) $request->user()->id;

//     /*
//      * Flutter compatibility:
//      * दोनों field names स्वीकार किए जाएंगे।
//      */
//     if (
//         !$request->filled('call_disposition_id')
//         && $request->filled('disposition_id')
//     ) {
//         $request->merge([
//             'call_disposition_id' =>
//                 $request->input('disposition_id'),
//         ]);
//     }

//     if (
//         !$request->filled('follow_up_at')
//         && $request->filled('next_follow_up_at')
//     ) {
//         $request->merge([
//             'follow_up_at' =>
//                 $request->input('next_follow_up_at'),
//         ]);
//     }

//     $request->validate([
//         'call_disposition_id' => [
//             'required',
//             'integer',
//         ],
//     ]);

//     /*
//      * केवल global या current company disposition allow करें।
//      */
//     $disposition = CallDisposition::query()
//         ->whereKey(
//             (int) $request->input(
//                 'call_disposition_id'
//             )
//         )
//         ->where('is_active', true)
//         ->where(function (Builder $query) use ($companyId) {
//             $query
//                 ->whereNull('company_id')
//                 ->orWhere('company_id', $companyId);
//         })
//         ->firstOrFail();

//     $validated = $request->validate([
//         'call_disposition_id' => [
//             'required',
//             'integer',
//         ],

//         'remarks' => [
//             $disposition->requires_remarks
//                 ? 'required'
//                 : 'nullable',
//             'string',
//             'max:3000',
//         ],

//         'follow_up_at' => [
//             $disposition->requires_follow_up
//                 ? 'required'
//                 : 'nullable',
//             'nullable',
//             'date',
//             'after:now',
//         ],

//         'duration_seconds' => [
//             'nullable',
//             'integer',
//             'min:0',
//         ],
//     ], [
//         'remarks.required' =>
//             "Remarks are required for {$disposition->name}.",

//         'follow_up_at.required' =>
//             "Follow-up date and time are required for {$disposition->name}.",

//         'follow_up_at.after' =>
//             'Follow-up date and time must be in the future.',
//     ]);

//     $remarks = trim(
//         (string) ($validated['remarks'] ?? '')
//     );

//     $followUpAt =
//         $validated['follow_up_at'] ?? null;

//     $durationSeconds = (int) (
//         $validated['duration_seconds'] ?? 0
//     );

//     $result = DB::transaction(function () use (
//         $lead,
//         $companyId,
//         $userId,
//         $disposition,
//         $remarks,
//         $followUpAt,
//         $durationSeconds
//     ) {
//         /*
//          * Call log save करें।
//          */
//         $callLog = CallLog::create([
//             'company_id' => $companyId,
//             'lead_id' => $lead->id,
//             'user_id' => $userId,

//             'call_disposition_id' =>
//                 $disposition->id,

//             'direction' => 'outgoing',

//             'started_at' => now()->subSeconds(
//                 $durationSeconds
//             ),

//             'ended_at' => now(),

//             'duration_seconds' =>
//                 $durationSeconds,

//             'remarks' =>
//                 $remarks !== '' ? $remarks : null,
//         ]);

//         $followUp = null;

//         /*
//          * Date/time आया है तो follow_ups table में record बनाएँ।
//          */
//         if (!empty($followUpAt)) {
//             $assignedTo = $lead->assigned_to
//                 ? (int) $lead->assigned_to
//                 : $userId;

//             $followUp = FollowUp::create([
//                 'company_id' => $companyId,
//                 'lead_id' => $lead->id,
//                 'assigned_to' => $assignedTo,
//                 'created_by' => $userId,

//                 'type' => 'phone',

//                 'scheduled_at' => $followUpAt,

//                 'reminder_notified_at' => null,

//                 'priority' => 'normal',
//                 'status' => 'pending',

//                 'notes' => $remarks !== ''
//                     ? $remarks
//                     : "Follow-up created from {$disposition->name} call disposition.",
//             ]);

//             /*
//              * Lead पर next follow-up भी update करें।
//              */
//             $lead->update([
//                 'last_contact_at' => now(),
//                 'next_follow_up_at' => $followUpAt,
//             ]);
//         } else {
//             $lead->update([
//                 'last_contact_at' => now(),
//             ]);
//         }

//         return [
//             'call_log' => $callLog->fresh([
//                 'disposition',
//                 'user',
//             ]),

//             'follow_up' => $followUp?->fresh([
//                 'assignedUser',
//                 'lead',
//             ]),

//             'lead' => $lead->fresh(),
//         ];
//     });

//     return $this->success(
//         $result,
//         $result['follow_up']
//             ? 'Call result and follow-up saved successfully.'
//             : 'Call result saved successfully.',
//         201
//     );
// }


public function saveCallResult(
    Request $request,
    Lead $lead
): JsonResponse {

    $this->guard(
        $request,
        $lead
    );

    $companyId =
        $this->companyId(
            $request
        );

    $userId =
        (int) $request
            ->user()
            ->id;


    /*
    |--------------------------------------------------------------------------
    | Flutter Compatibility
    |--------------------------------------------------------------------------
    |
    | Dono field names accept karenge.
    |
    */

    if (
        !$request->filled(
            'call_disposition_id'
        )
        &&
        $request->filled(
            'disposition_id'
        )
    ) {

        $request->merge([

            'call_disposition_id' =>
                $request->input(
                    'disposition_id'
                ),

        ]);
    }


    if (
        !$request->filled(
            'follow_up_at'
        )
        &&
        $request->filled(
            'next_follow_up_at'
        )
    ) {

        $request->merge([

            'follow_up_at' =>
                $request->input(
                    'next_follow_up_at'
                ),

        ]);
    }


    /*
    |--------------------------------------------------------------------------
    | Basic Disposition Validation
    |--------------------------------------------------------------------------
    */

    $request->validate([

        'call_disposition_id' => [
            'required',
            'integer',
        ],

    ]);


    /*
    |--------------------------------------------------------------------------
    | Load Disposition
    |--------------------------------------------------------------------------
    |
    | Sirf:
    | - Global disposition
    | - Current company disposition
    |
    | allow hoga.
    |
    */

    $disposition =
        CallDisposition::query()

            ->whereKey(
                (int) $request->input(
                    'call_disposition_id'
                )
            )

            ->where(
                'is_active',
                true
            )

            ->where(
                function (
                    Builder $query
                ) use (
                    $companyId
                ) {

                    $query
                        ->whereNull(
                            'company_id'
                        )
                        ->orWhere(
                            'company_id',
                            $companyId
                        );
                }
            )

            ->firstOrFail();


    /*
    |--------------------------------------------------------------------------
    | Dynamic Validation
    |--------------------------------------------------------------------------
    */

    $validated =
        $request->validate([

            'call_disposition_id' => [
                'required',
                'integer',
            ],

            'remarks' => [

                $disposition
                    ->requires_remarks
                        ? 'required'
                        : 'nullable',

                'string',
                'max:3000',
            ],

            'follow_up_at' => [

                $disposition
                    ->requires_follow_up
                        ? 'required'
                        : 'nullable',

                'nullable',
                'date',
                'after:now',
            ],

            'duration_seconds' => [
                'nullable',
                'integer',
                'min:0',
            ],

        ], [

            'remarks.required' =>
                "Remarks are required for {$disposition->name}.",

            'follow_up_at.required' =>
                "Follow-up date and time are required for {$disposition->name}.",

            'follow_up_at.after' =>
                'Follow-up date and time must be in the future.',

        ]);


    /*
    |--------------------------------------------------------------------------
    | Normalize Remarks
    |--------------------------------------------------------------------------
    */

    $remarks =
        trim(
            (string) (
                $validated[
                    'remarks'
                ] ?? ''
            )
        );


    /*
    |--------------------------------------------------------------------------
    | Normalize Follow-up
    |--------------------------------------------------------------------------
    */

    $followUpAt =
        $validated[
            'follow_up_at'
        ] ?? null;


    /*
    |--------------------------------------------------------------------------
    | Duration
    |--------------------------------------------------------------------------
    */

    $durationSeconds =
        max(
            0,
            (int) (
                $validated[
                    'duration_seconds'
                ] ?? 0
            )
        );


    /*
    |--------------------------------------------------------------------------
    | Database Transaction
    |--------------------------------------------------------------------------
    */

    $result =
        DB::transaction(
            function () use (
                $lead,
                $companyId,
                $userId,
                $disposition,
                $remarks,
                $followUpAt,
                $durationSeconds
            ) {


                /*
                |--------------------------------------------------------------------------
                | Create Call Log
                |--------------------------------------------------------------------------
                |
                | Har call result ke liye naya call log create hoga.
                |
                */

                $callLog =
                    CallLog::create([

                        'company_id' =>
                            $companyId,

                        'lead_id' =>
                            $lead->id,

                        'user_id' =>
                            $userId,

                        'call_disposition_id' =>
                            $disposition->id,

                        'direction' =>
                            'outgoing',

                        'started_at' =>
                            now()
                                ->subSeconds(
                                    $durationSeconds
                                ),

                        'ended_at' =>
                            now(),

                        'duration_seconds' =>
                            $durationSeconds,

                        'remarks' =>
                            $remarks !== ''
                                ? $remarks
                                : null,

                    ]);


                /*
                |--------------------------------------------------------------------------
                | Follow-up
                |--------------------------------------------------------------------------
                |
                | Follow-up time aaya hai:
                |
                | 1. Same lead ka pending follow-up already hai
                |    => usi ko UPDATE karo.
                |
                | 2. Pending follow-up nahi hai
                |    => naya follow-up CREATE karo.
                |
                */

                $followUp = null;


                if (
                    !empty(
                        $followUpAt
                    )
                ) {

                    $assignedTo =
                        $lead->assigned_to
                            ? (int) $lead->assigned_to
                            : $userId;


                    /*
                    |--------------------------------------------------------------------------
                    | Find Existing Pending Follow-up
                    |--------------------------------------------------------------------------
                    */

                    $existingFollowUp =
                        FollowUp::query()

                            ->where(
                                'company_id',
                                $companyId
                            )

                            ->where(
                                'lead_id',
                                $lead->id
                            )

                            ->where(
                                'status',
                                'pending'
                            )

                            ->latest(
                                'id'
                            )

                            ->first();


                    /*
                    |--------------------------------------------------------------------------
                    | Existing Pending Follow-up Found
                    |--------------------------------------------------------------------------
                    */

                    if (
                        $existingFollowUp
                    ) {

                        $existingFollowUp
                            ->update([

                                'assigned_to' =>
                                    $assignedTo,

                                'type' =>
                                    'phone',

                                'scheduled_at' =>
                                    $followUpAt,

                                /*
                                 * Time change hua hai,
                                 * isliye reminder dobara eligible hona chahiye.
                                 */

                                'reminder_notified_at' =>
                                    null,

                                'priority' =>
                                    'normal',

                                'status' =>
                                    'pending',

                                'notes' =>
                                    $remarks !== ''
                                        ? $remarks
                                        : "Follow-up updated from {$disposition->name} call disposition.",

                            ]);


                        $followUp =
                            $existingFollowUp
                                ->fresh();


                    /*
                    |--------------------------------------------------------------------------
                    | No Pending Follow-up
                    |--------------------------------------------------------------------------
                    */

                    } else {

                        $followUp =
                            FollowUp::create([

                                'company_id' =>
                                    $companyId,

                                'lead_id' =>
                                    $lead->id,

                                'assigned_to' =>
                                    $assignedTo,

                                'created_by' =>
                                    $userId,

                                'type' =>
                                    'phone',

                                'scheduled_at' =>
                                    $followUpAt,

                                'reminder_notified_at' =>
                                    null,

                                'priority' =>
                                    'normal',

                                'status' =>
                                    'pending',

                                'notes' =>
                                    $remarks !== ''
                                        ? $remarks
                                        : "Follow-up created from {$disposition->name} call disposition.",

                            ]);
                    }


                    /*
                    |--------------------------------------------------------------------------
                    | Update Lead Follow-up Time
                    |--------------------------------------------------------------------------
                    */

                    $lead->update([

                        'last_contact_at' =>
                            now(),

                        'next_follow_up_at' =>
                            $followUpAt,

                    ]);


                /*
                |--------------------------------------------------------------------------
                | No Follow-up
                |--------------------------------------------------------------------------
                */

                } else {

                    $lead->update([

                        'last_contact_at' =>
                            now(),

                    ]);
                }


                /*
                |--------------------------------------------------------------------------
                | Response Data
                |--------------------------------------------------------------------------
                */

                return [

                    'call_log' =>
                        $callLog->fresh([
                            'disposition',
                            'user',
                        ]),

                    'follow_up' =>
                        $followUp
                            ?->fresh([
                                'assignedUser',
                                'lead',
                            ]),

                    'lead' =>
                        $lead->fresh(),

                ];
            }
        );


    /*
    |--------------------------------------------------------------------------
    | Success Response
    |--------------------------------------------------------------------------
    */

    return $this->success(

        $result,

        $result[
            'follow_up'
        ]
            ? 'Call result and follow-up saved successfully.'
            : 'Call result saved successfully.',

        201
    );
}


}
