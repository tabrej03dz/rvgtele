<?php

namespace App\Providers;

use Carbon\CarbonImmutable;
use Illuminate\Support\Facades\Date;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Gate;
use Illuminate\Support\ServiceProvider;
use Illuminate\Validation\Rules\Password;

class AppServiceProvider extends ServiceProvider
{
    public function register(): void
    {
        //
    }

    public function boot(): void
    {
        $this->configureDefaults();

        /*
        |--------------------------------------------------------------------------
        | Super Admin Full Access
        |--------------------------------------------------------------------------
        */

        Gate::before(
            function (
                $user,
                string $ability
            ) {

                return $user->hasRole(
                    'super_admin'
                )
                    ? true
                    : null;
            }
        );

       
    }

    protected function configureDefaults(): void
    {
        Date::use(
            CarbonImmutable::class
        );

        DB::prohibitDestructiveCommands(
            app()->isProduction(),
        );

        Password::defaults(
            fn (): ?Password =>
                app()->isProduction()
                    ? Password::min(12)
                        ->mixedCase()
                        ->letters()
                        ->numbers()
                        ->symbols()
                        ->uncompromised()
                    : null,
        );
    }
}